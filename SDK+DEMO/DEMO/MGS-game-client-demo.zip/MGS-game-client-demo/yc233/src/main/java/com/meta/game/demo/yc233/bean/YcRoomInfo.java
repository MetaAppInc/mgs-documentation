package com.meta.game.demo.yc233.bean;

import java.util.List;

/**
 * 勇闯房间信息
 *
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class YcRoomInfo {
    /**
     * 房间是否满员
     */
    public boolean full;
    /**
     * 房间号
     */
    public String roomId;
    /**
     * 房间成员容量
     */
    public int roomLimit;
    /**
     * 房间名称
     */
    public String roomName;
    /**
     * 房间状态
     */
    public int roomState;
    /**
     * 房间类型
     */
    public int roomType;

    public List<String> roomTagList;
    /**
     * 是否是有密码
     */
    public boolean hasPassword;
    /**
     * 密码
     */
    public String password;

    /**
     * 是否允许房间聊天
     */
    public boolean canRoomChat = true;
    /**
     * 是否允许开麦
     */
    public boolean canVoice = true;

    /**
     * MGS房间号
     */
    public String roomShowNum;

    /**
     * 房主
     */
    public String roomOwner;

    @Override
    public String toString() {
        return "YcRoomInfo{" +
                "full=" + full +
                ", roomId='" + roomId + '\'' +
                ", roomLimit=" + roomLimit +
                ", roomName='" + roomName + '\'' +
                ", roomState=" + roomState +
                ", roomType=" + roomType +
                ", roomTagList=" + roomTagList +
                ", hasPassword=" + hasPassword +
                ", password='" + password + '\'' +
                ", roomShowNum='" + roomShowNum + '\'' +
                ", roomOwner='" + roomOwner + '\'' +
                '}';
    }
}
