package com.meta.game.demo.yc233.view;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.utils.DisplayUtils;
import com.meta.game.demo.yc233.utils.ToastUtils;

/**
 * 创建房间页面
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/22
 */
public class RoomPasswordDialog extends AlertDialog {

    private OnRoomPasswordListener listener;
     private EditText etRoomPassword;

    public RoomPasswordDialog(@NonNull Context context, OnRoomPasswordListener listener) {
        super(context);
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_room_password);
        Button positiveBtn = findViewById(R.id.btn_positive);
        Button cancelBtn = findViewById(R.id.btn_cancel);

        etRoomPassword = findViewById(R.id.et_room_password);
        this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);

        positiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String roomPassword = etRoomPassword.getText().toString();
                if (TextUtils.isEmpty(roomPassword)) {
                    ToastUtils.showToast(getContext(), "请输入密码");
                    return;
                }
                if (listener != null) {
                    listener.onRoomPasswordResult(roomPassword.trim());
                }
                dismiss();
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        WindowManager.LayoutParams  lp= getWindow().getAttributes();
        lp.width = DisplayUtils.dp2px(getContext(), 320);
         lp.height = DisplayUtils.dp2px(getContext(), 260);
        getWindow().setAttributes(lp);
    }


    interface OnRoomPasswordListener {
        void onRoomPasswordResult(String password);
    }
}
