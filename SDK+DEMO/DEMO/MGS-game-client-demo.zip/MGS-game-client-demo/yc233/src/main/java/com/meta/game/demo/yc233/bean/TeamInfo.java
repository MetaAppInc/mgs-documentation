package com.meta.game.demo.yc233.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/18
 */
public class TeamInfo {
    public String teamId;
    public int roomLimit;
    public List<String> playerList = new ArrayList<>();

    @Override
    public String toString() {
        return "TeamInfo{" +
                "teamId='" + teamId + '\'' +
                ", roomLimit=" + roomLimit +
                ", playerList=" + playerList +
                '}';
    }
}
