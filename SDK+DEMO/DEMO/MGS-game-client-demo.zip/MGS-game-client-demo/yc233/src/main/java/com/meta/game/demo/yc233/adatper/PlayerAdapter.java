package com.meta.game.demo.yc233.adatper;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.bean.PlayerInfo;
import com.meta.game.demo.yc233.view.PlayerView;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/11
 */
public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder> {

    private List<PlayerInfo> dataList = new ArrayList<>();
    /**
     * 房主
     */
    private String roomOwner ="";
    private int defaultPlayerIcon;

    private LayoutInflater layoutInflater;
    public PlayerAdapter(Context context) {
        layoutInflater = LayoutInflater.from(context);
    }

    /**
     * 刷新当前用户信息
     * @param playerInfoList
     */
    public void refresh(List<PlayerInfo> playerInfoList, String roomOwner, int defaultPlayerIcon) {
        this.roomOwner = roomOwner;
        this.defaultPlayerIcon = defaultPlayerIcon;
        dataList.clear();
        dataList.addAll(playerInfoList);
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public PlayerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = layoutInflater.inflate(R.layout.list_item_player, viewGroup,false);
        PlayerViewHolder viewHolder = new PlayerViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull PlayerViewHolder viewHolder, int i) {

        PlayerInfo player = dataList.get(i);
        viewHolder.playerView.setUserInfo(player.userInfo, roomOwner,defaultPlayerIcon);

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    static class PlayerViewHolder extends RecyclerView.ViewHolder {
        PlayerView playerView;

        public PlayerViewHolder(@NonNull View itemView) {
            super(itemView);
            playerView = itemView.findViewById(R.id.view_player);
        }
    }
}
