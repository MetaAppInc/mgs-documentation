package com.meta.game.demo.yc233.data;

import com.meta.game.demo.yc233.bean.TokenInfo;
import com.meta.game.demo.yc233.bean.UserInfo;
import com.meta.game.demo.yc233.bean.UserResp;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/22
 */
public class YcUserManager {

    private static YcUserManager sInstance;

    private UserResp userResp;

    public static YcUserManager getInstance() {
        if (sInstance == null) {
            sInstance = new YcUserManager();
        }
        return sInstance;
    }

    public void saveUserResp(UserResp userResp) {
        this.userResp = userResp;
    }

    public UserInfo getUserInfo() {
        if (userResp != null) {
            return userResp.userInfo;
        }
        return null;
    }

    /**
     * 获取openId
     * @return
     */
    public String getOpenId() {
        if (userResp != null && userResp.userInfo != null) {
            return userResp.userInfo.openId;
        }
        return "";
    }

    public TokenInfo getTokenInfo() {
        if (userResp != null) {
            return userResp.tokenInfo;
        }
        return null;
    }

    public String getToken(){
        TokenInfo tokenInfo = getTokenInfo();
        if (tokenInfo != null) {
            return tokenInfo.token;
        }
        return "";
    }

    public void clear(){
        userResp = null;
        sInstance =null;
    }


}
