package com.meta.game.demo.yc233.view;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.utils.DisplayUtils;
import com.meta.game.demo.yc233.utils.ToastUtils;

/**
 * 创建房间页面
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/22
 */
public class GameRoomCreateDialog extends AlertDialog {

    private OnCreateRoomListener listener;
    private EditText etRoomName;
    private EditText etRoomPassword;
    private RadioGroup tagsRadioGroup;
    private String roomTag = "休闲模式";
    public GameRoomCreateDialog(@NonNull Context context, OnCreateRoomListener listener) {
        super(context);
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_create_room);
        Button positiveBtn = findViewById(R.id.btn_create_new_rom);
        Button cancelBtn = findViewById(R.id.btn_cancel);
        tagsRadioGroup = findViewById(R.id.rg_room_tags);

        etRoomName = findViewById(R.id.et_room_name);
        etRoomPassword = findViewById(R.id.et_room_password);
        this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);

        tagsRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb_tag_1) {
                    roomTag = "休闲模式";
                } else {
                    roomTag = "战役模式";
                }
            }
        });

        positiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String roomName = etRoomName.getText().toString();
                if (TextUtils.isEmpty(roomName)) {
                    ToastUtils.showToast(getContext(), "请输入房间名称");
                    return;
                }

                if (roomName.length() > 12) {
                    ToastUtils.showToast(getContext(), "房间名称最多只允许12个字");
                    return;
                }

                String roomPassword = etRoomPassword.getText().toString();

                if (listener != null) {
                    listener.onCreateRoomNameResult(roomName, roomTag, roomPassword.trim());
                }
                dismiss();
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        WindowManager.LayoutParams  lp= getWindow().getAttributes();
        lp.width = DisplayUtils.dp2px(getContext(), 320);
        //lp.height = DisplayUtils.dp2px(getContext(), 260);
        getWindow().setAttributes(lp);
    }


    interface OnCreateRoomListener {
        void onCreateRoomNameResult(String name, String tag, String password);
    }
}
