package com.meta.game.demo.yc233.event;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/05/08
 */
public class RefreshBalanceEvent {
}
