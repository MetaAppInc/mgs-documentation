package com.meta.game.demo.yc233.data;

import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class ApiListResponse<T> extends ApiResponse<List<T>> {
}
