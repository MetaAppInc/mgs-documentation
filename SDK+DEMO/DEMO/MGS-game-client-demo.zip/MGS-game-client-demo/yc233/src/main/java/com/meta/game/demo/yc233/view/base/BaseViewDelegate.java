package com.meta.game.demo.yc233.view.base;

/**
 * 逻辑处理代理类
 * @author zhiwei.xu@appshahe.com
 * @date 2021/05/08
 */
public abstract class BaseViewDelegate {

    public abstract void onCreated();

    public void onDestroyed() {

    }
}
