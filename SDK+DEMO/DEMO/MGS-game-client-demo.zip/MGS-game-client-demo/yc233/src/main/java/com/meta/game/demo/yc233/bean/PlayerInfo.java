package com.meta.game.demo.yc233.bean;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class PlayerInfo {
    /**
     * 玩家信息
     */
    public UserInfo userInfo;
    /**
     * 玩家状态
     */
    public int userState;
}
