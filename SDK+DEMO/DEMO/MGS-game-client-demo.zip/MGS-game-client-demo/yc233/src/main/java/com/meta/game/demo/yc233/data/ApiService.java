package com.meta.game.demo.yc233.data;

import com.meta.game.demo.yc233.bean.BalanceInfo;
import com.meta.game.demo.yc233.bean.OrderInfo;
import com.meta.game.demo.yc233.bean.RoomPlayerListResp;
import com.meta.game.demo.yc233.bean.RoomResp;
import com.meta.game.demo.yc233.bean.UserResp;
import com.meta.game.demo.yc233.config.GameConfigHelper;
import com.meta.game.demo.yc233.data.http.OkHttpUtils;
import com.meta.game.demo.yc233.data.http.ResponseCallback;

import java.util.HashMap;
import java.util.Map;

/**
 * 勇闯游戏api服务
 *
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class ApiService {

    /**
     * 登录接口
     */
    public static final String URL_LOGIN = buildUrl("/game/server/user/login");
    /**
     * 创建房间接口
     */
    public static final String URL_ROOM_CREATE = buildUrl("/game/server/room/create");
    /**
     * 加入房间
     * */
    public static final String URL_ROOM_JOIN = buildUrl("/game/server/room/join");
    /**
     * 离开房间
     */
    public static final String URL_ROOM_LEAVE = buildUrl("/game/server/room/leaveRoomAndFanout");
    /**
     * 获取玩家列表
     */
    public static final String URL_ROOM_QUERY_USER_LIST = buildUrl("/game/server/room/query");
    /**
     * 更新房间名称
     */
    public static final String URL_ROOM_UPDATE_ROOM_NAME = buildUrl("/game/server/room/updateRoomName");
    public static final String URL_BATCH_CHECK_FRIEND = buildUrl("/game/server/room/batchCheckFriend");

    /**
     * 道具-余额
     */
    public static final String URL_GET_BALANCE = buildUrl("/game/server/prop/getBalance");
    /**
     * 下单接口
     */
    public static final String URL_PLACE_ORDER = buildUrl("/game/server/prop/placeOrder");

    /**
     * 根据订单号查询订单状态
     */
    public static final String URL_GET_ORDER = buildUrl("/game/server/prop/getOrder");

    private static String buildUrl(String path){
        return GameConfigHelper.getInstance().getBaseUrl() + path;
    }


    public static void login(String openId, String openCode, ResponseCallback<ApiResponse<UserResp>> callback) {

        Map<String, Object> params = new HashMap<>(2);
        params.put("openId", openId);
        params.put("openCode", openCode);

        OkHttpUtils.getInstance().postJson(URL_LOGIN, params, new ResponseCallback<ApiResponse<UserResp>>() {
            @Override
            public void onSuccess(ApiResponse<UserResp> response) {

                if (response.isSuccess()) {
                    //缓存用户信息
                    YcUserManager.getInstance().saveUserResp(response.data);
                }

                if (callback != null) {
                    callback.onSuccess(response);
                }
            }

            @Override
            public void onFailure(String error) {
                if (callback != null) {
                    callback.onFailure(error);
                }
            }
        });
    }

    /**
     * 创建房间
     * @param roomType 房间类型即可，后台自动生成房间名
     */
    public static void createRoom(int roomType, ResponseCallback<ApiResponse<RoomResp>> callback) {
        Map<String, Object> params = new HashMap<>(2);
        params.put("roomType", roomType);
        OkHttpUtils.getInstance().postJson(URL_ROOM_CREATE, params, callback);
    }


    /**
     * 加入房间
     * @param roomId 房间号
     */
    public static void joinRoom(String roomId, int roomType, ResponseCallback<ApiResponse<RoomResp>> callback) {
        Map<String, Object> params = new HashMap<>(1);
        params.put("roomId", roomId == null ? "" : roomId);
        if(roomType != 0) {
            params.put("roomType", roomType);
        }

        OkHttpUtils.getInstance().postJson(URL_ROOM_JOIN, params, callback);
    }

    /**
     * 离开房间
     * @param roomId 房间号
     */
    public static void leaveRoom(String roomId, ResponseCallback<ApiResponse<Boolean>> callback) {
        Map<String, Object> params = new HashMap<>(1);
        params.put("roomId", roomId);

        OkHttpUtils.getInstance().postJson(URL_ROOM_LEAVE, params, callback);
    }


    /**
     * 获取玩家列表信息
     * @param roomId
     */
    public static void queryPlayerList(String roomId, ResponseCallback<ApiResponse<RoomPlayerListResp>> callback){
        Map<String, Object> params = new HashMap<>(1);
        params.put("roomId", roomId);

        OkHttpUtils.getInstance().postJson(URL_ROOM_QUERY_USER_LIST, params, callback);
    }

    /**
     * 获取玩家列表信息
     * @param roomId
     */
    public static void checkBatchFriendship(String roomId, ResponseCallback<ApiResponse<Map<String, Boolean>>> callback){
        Map<String, Object> params = new HashMap<>(1);
        params.put("roomId", roomId);

        OkHttpUtils.getInstance().postJson(URL_BATCH_CHECK_FRIEND, params, callback);
    }

    /**
     * 修改房间名称
     * @param roomId
     * @param roomName
     */
    public static void updateRoomName(String roomId, String roomName, ResponseCallback<ApiResponse<Boolean>> callback) {
        Map<String, Object> params = new HashMap<>(2);
        params.put("roomId", roomId);
        params.put("roomName", roomName);

        OkHttpUtils.getInstance().postJson(URL_ROOM_UPDATE_ROOM_NAME, params, callback);
    }


    /**
     * 下单
     * @param productCode 道具id
     * @param callback
     */
    public static void placeOrder(String productCode, ResponseCallback<ApiResponse<OrderInfo>> callback) {
        Map<String, Object> params = new HashMap<>(2);
        params.put("propCode", productCode);
        params.put("propNumber", 1);
        OkHttpUtils.getInstance().postJson(URL_PLACE_ORDER, params, callback);
    }

    /**
     * 获取余额
     */
    public static void getBalance(ResponseCallback<ApiResponse<BalanceInfo>> callback) {
        Map<String, Object> params = new HashMap<>();
        OkHttpUtils.getInstance().postJson(URL_GET_BALANCE, params, callback);
    }

    /**
     * 查询订单状态
     * @param orderId
     * @param callback
     */
    public static void queryOrderStatus(String orderId, ResponseCallback<ApiResponse<OrderInfo>> callback) {
        Map<String, Object> params = new HashMap<>(2);
        params.put("orderId", orderId);
        OkHttpUtils.getInstance().postJson(URL_GET_ORDER, params, callback);
    }
}
