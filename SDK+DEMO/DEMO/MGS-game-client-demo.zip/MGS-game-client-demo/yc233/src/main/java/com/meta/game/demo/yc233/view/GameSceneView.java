package com.meta.game.demo.yc233.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.adatper.PlayerAdapter;
import com.meta.game.demo.yc233.bean.PlayerInfo;
import com.meta.game.demo.yc233.bean.RoomPlayerListResp;
import com.meta.game.demo.yc233.bean.RoomResp;
import com.meta.game.demo.yc233.bean.TeamPlayerListResp;
import com.meta.game.demo.yc233.bean.YcRoomInfo;
import com.meta.game.demo.yc233.constants.GameConstants;
import com.meta.game.demo.yc233.data.YcRoomManager;
import com.meta.game.demo.yc233.data.websocket.WebSocketManager;
import com.meta.game.demo.yc233.event.AddFriendEvent;
import com.meta.game.demo.yc233.event.SwitchRoomEvent;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.utils.YcCommonUtils;
import com.meta.game.demo.yc233.view.base.AbstractBaseView;
import com.meta.game.demo.yc233.widget.CustomDialog;
import com.meta.game.demo.yc233.widget.StrokeTextView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;
import java.util.Map;

import static com.meta.game.demo.yc233.constants.GameConstants.GAME_MODE_5V5;
import static com.meta.game.demo.yc233.constants.GameConstants.GAME_STATE_END;
import static com.meta.game.demo.yc233.constants.GameConstants.GAME_STATE_PREPARE;
import static com.meta.game.demo.yc233.constants.GameConstants.GAME_STATE_PROGRESSING;

/**
 * 游戏(房间)业务基础view
 *
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/22
 */
public class GameSceneView extends AbstractBaseView<GameSceneViewDelegate> {

    private static final String TAG = "GameSceneView";

    private LinearLayout llButtons;
    private StrokeTextView startGameBtn;
    private StrokeTextView leaveBtn;
    private StrokeTextView switchRoomBtn;
    private TextView       titleTv;
    private TextView       gameStateTv;
    private StrokeTextView btnJoinAudio;
    private StrokeTextView btnLeaveAudio;
    private StrokeTextView btnAudioMute;
    private StrokeTextView btnAudioUnMute;


    protected LinearLayout  playerContainersLayout;
    protected RecyclerView  topRecyclerView;
    protected RecyclerView  bottomRecyclerView;
    protected View          vsView;
    protected PlayerAdapter topRecyclerViewAdapter;
    protected PlayerAdapter bottomRecyclerViewAdapter;

    protected RoomResp              roomResp;

    /**
     * 房间信息
     */
    protected YcRoomInfo roomInfo;

    /**
     * MGS的房间号
     */
    private String roomShowNumber;

    /**
     * 当前队伍的ID
     */
    protected String currentTeamId;

    public GameSceneView(@NonNull Context context) {
        super(context, R.layout.game_scene_room);
    }

    @Override
    protected void init(Context context) {

        llButtons = findViewById(R.id.ll_buttons);
        leaveBtn = findViewById(R.id.btn_leave_room);
        startGameBtn = findViewById(R.id.btn_room_game_start);
        switchRoomBtn = findViewById(R.id.btn_switch_room);
        btnJoinAudio = findViewById(R.id.btn_join_audio);
        btnLeaveAudio = findViewById(R.id.btn_leave_audio);
        btnAudioMute = findViewById(R.id.btn_audio_mute);
        btnAudioUnMute = findViewById(R.id.btn_audio_unmute);

        titleTv = findViewById(R.id.tv_room_title);
        gameStateTv = findViewById(R.id.tv_room_state);
        playerContainersLayout = findViewById(R.id.ll_player_container);
        playerContainersLayout.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);

        topRecyclerView = findViewById(R.id.rv_room_players_top);
        bottomRecyclerView = findViewById(R.id.rv_room_players_bottom);
        vsView = findViewById(R.id.view_room_players_vs);

        topRecyclerViewAdapter = new PlayerAdapter(getContext());
        setRecyclerViewConfig(topRecyclerView, topRecyclerViewAdapter);

        bottomRecyclerViewAdapter = new PlayerAdapter(getContext());
        setRecyclerViewConfig(bottomRecyclerView, bottomRecyclerViewAdapter);

        //离开房间事件
        leaveBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (roomInfo.roomState == GAME_STATE_PROGRESSING) {
                    ToastUtils.showToast(getContext(), "游戏进行中,暂时不能离开房间");
                    return;
                }
                //显示退出房间提示框
                showLeaveRoomDialog();
            }
        });

        //开始游戏事件
        startGameBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                //房间状态
                switch (roomInfo.roomState) {
                    case GAME_STATE_PREPARE:
                        //准备游戏
                        viewDelegate.sendStartGameAction();
                        break;
                    case GAME_STATE_PROGRESSING:
                        //游戏进行中
                        viewDelegate.sendEndGameAction();
                        break;
                    case GAME_STATE_END:
                        //游戏准备
                        viewDelegate.sendPrepareGameAction();

                        break;
                    default:
                        break;
                }

            }
        });

        switchRoomBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (roomInfo.roomState == GAME_STATE_PROGRESSING) {
                    ToastUtils.showToast(getContext(), "游戏进行中,暂时不能离开房间");
                    return;
                }
                //显示切换房间提示框
                showSwitchRoomDialog();
            }
        });

        btnAudioMute.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                audioMute();
            }
        });

        btnAudioUnMute.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                unMuteAudio();
            }
        });

        btnJoinAudio.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                joinAudio();
            }
        });

        btnLeaveAudio.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                leaveAudio();
            }
        });

    }

    private void unMuteAudio() {
        MgsSdkBridgeHelper.getInstance().unmuteAudio(new MgsFeatureListener() {
            @Override
            public void onSuccess(int i, String s) {
                ToastUtils.showToast(getContext(), "打开麦克风");
            }

            @Override
            public void onFail(int i, int i1, String s) {

            }
        });
    }

    private void audioMute() {
        MgsSdkBridgeHelper.getInstance().muteAudio(new MgsFeatureListener() {
            @Override
            public void onSuccess(int i, String s) {
                ToastUtils.showToast(getContext(), "关闭麦克风");
            }

            @Override
            public void onFail(int i, int i1, String s) {

            }
        });
    }

    private void leaveAudio() {
        MgsSdkBridgeHelper.getInstance().leaveAudio(new MgsFeatureListener() {
            @Override
            public void onSuccess(int i, String s) {
                ToastUtils.showToast(getContext(), "离开频道成功");
            }

            @Override
            public void onFail(int i, int i1, String s) {

            }
        });
    }

    private void joinAudio() {
        MgsSdkBridgeHelper.getInstance().joinAudio(new MgsFeatureListener() {
            @Override
            public void onSuccess(int i, String s) {
                ToastUtils.showToast(getContext(), "加入频道成功");
            }

            @Override
            public void onFail(int i, int i1, String s) {

            }
        });

    }

    /**
     * 配置recyclerView
     *
     * @param recyclerView
     * @param adapter
     */
    protected void setRecyclerViewConfig(RecyclerView recyclerView, PlayerAdapter adapter) {
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getContext(),
                DividerItemDecoration.HORIZONTAL);
        itemDecoration.setDrawable(getResources().getDrawable(R.drawable.space_5));
        recyclerView.addItemDecoration(itemDecoration);
        recyclerView.setLayoutManager(getLayoutManager());
        recyclerView.setAdapter(adapter);
    }

    protected RecyclerView.LayoutManager getLayoutManager() {
        return new GridLayoutManager(getContext(), 4);
    }


    /**
     * 设置房间信息
     */
    public void setRoomInfo(RoomResp roomResp, YcRoomInfo roomInfo, String roomNumber) {
        this.roomResp = roomResp;
        this.roomInfo = roomResp.roomInfo;
        this.roomShowNumber = roomNumber;
        this.currentTeamId = roomResp.currentTeamId;
        //设置当前房间信息
        YcRoomManager.getInstance().setCurrentRoom(this, roomInfo);
    }

    /**
     * 是否是5v5类型
     *
     * @return
     */
    public boolean is5V5() {
        return roomInfo.roomType == GAME_MODE_5V5;
    }


    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        Log.i(TAG, "--onAttachedToWindow--");
        refreshRoomState(roomInfo);
    }

    @Override
    protected GameSceneViewDelegate createViewDelegate() {
        return new GameSceneViewDelegate(this, roomInfo.roomId);
    }

    @Override
    protected boolean isNeedEventBus() {
        return true;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyRefreshPlayerEvent(AddFriendEvent event) {
        Log.i(TAG, "---响应事件-onNotifyRefreshPlayerEvent--");
        refreshPlayerAdapters();
    }



    /**
     * 显示游戏进行中的UI
     */
    void showStartBattleUI() {
        Log.i(TAG, "show game start team battle UI =" + roomInfo.roomState);
    }


    /**
     * 显示结束游戏UI
     */
    void showEndBattleUI() {
    }

    /**
     * 分配队伍
     */
    void doArrangedTeam(Map<String, String> arrangedTeamInfo) {
    }


    /**
     * 刷新teamView的视图
     *
     * @param response
     */
    void refreshTeamView(List<TeamPlayerListResp> response) {
    }

    /**
     * 切换队伍成功
     */
    void switchTeamSuccess() {
    }

    /**
     * 离开房间确认框
     */
    protected void showSwitchRoomDialog() {

        CustomDialog dialog = new CustomDialog.Builder(getContext())
                .setMessage("确认要切换房间吗?")
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        viewDelegate.sendSwitchRoomAction(roomInfo.roomId);
                    }
                })
                .create();
        dialog.show();
    }

    void switchRoom(RoomResp roomResp) {
        Log.i(TAG, "切换房间" + roomResp.toString());

        YcRoomManager.getInstance().switchRoom(roomResp, new YcRoomManager.OnSwitchRoomListener() {
            @Override
            public void onCompleted(boolean success, RoomResp targetRoomInfo, String resultJson) {
                if (success) {
                    WebSocketManager.getInstance().disconnect();
                    EventBus.getDefault().post(new SwitchRoomEvent(targetRoomInfo, resultJson));
                }
            }
        });
    }


    /**
     * 刷新房间信息
     *
     * @param roomPlayerListResp
     */
    void refreshRoomInfo(RoomPlayerListResp roomPlayerListResp) {
        Log.i(TAG, "刷新房间数据" + roomPlayerListResp);
        //设置房间信息
        roomInfo = roomPlayerListResp.roomInfo;

        //重新设置房间信息
        YcRoomManager.getInstance().setCurrentRoom(GameSceneView.this, roomInfo);

        //刷新房间状态
        refreshRoomState(roomInfo);

        if (!is5V5()) {
            //刷新房间玩家信息
            refreshPlayerAdapter(topRecyclerViewAdapter, roomPlayerListResp.playerList, roomInfo.roomLimit, R.drawable.icon_player_prepared_green);
        }

    }

    /**
     * 刷新玩家列表
     */
    public void refreshPlayerAdapters() {
        if (topRecyclerViewAdapter != null) {
            topRecyclerViewAdapter.notifyDataSetChanged();
        }

        if (bottomRecyclerViewAdapter != null) {
            bottomRecyclerViewAdapter.notifyDataSetChanged();
        }
    }

    /**
     * 刷新玩家列表
     */
    protected void refreshPlayerAdapter(PlayerAdapter adapter, List<PlayerInfo> currentPlayers,
                                        int limitPlayer, int playerIconRes) {

        //当前房间玩家数量
        int playerSize = currentPlayers.size();
        //判断玩家数量是否达到上限,如果是就不需要补空位
        if (playerSize < limitPlayer) {
            int diff = limitPlayer - playerSize;
            for (int i = 0; i < diff; i++) {
                currentPlayers.add(new PlayerInfo());
            }
        }
        //刷新界面
        adapter.refresh(currentPlayers, roomInfo.roomOwner, playerIconRes);
    }

    /**
     * 刷新房间状态
     *
     * @param info
     */
    @SuppressLint("SetTextI18n")
    protected void refreshRoomState(YcRoomInfo info) {
        if (info == null) {
            return;
        }

        String titleFormat = String.format("%s - 房间号:%s,MGS房间号:%s,房间名称：%s, %s",
                GameConstants.GAME_MODE_MAP.get(info.roomType),
                info.roomId,
                roomShowNumber,
                roomInfo.roomName,
                (TextUtils.isEmpty(currentTeamId) ? "" : "所在队伍:" + currentTeamId));

        titleTv.setText(titleFormat);

        //房间状态
        switch (roomInfo.roomState) {
            case GAME_STATE_PREPARE:
                gameStateTv.setText(String.format("游戏未开始,准备中..."));
                startGameBtn.setText("开始游戏");
                YcCommonUtils.setViewVisible(switchRoomBtn, true);
                break;
            case GAME_STATE_PROGRESSING:
                gameStateTv.setText("游戏进行中...房主可手动结束本局");
                startGameBtn.setText("结束游戏");
                YcCommonUtils.setViewVisible(switchRoomBtn, false);
                break;
            case GAME_STATE_END:
                gameStateTv.setText("游戏已结束,等待一局");
                startGameBtn.setText("准备开始");
                YcCommonUtils.setViewVisible(switchRoomBtn, true);
                break;
            default:
                break;
        }

        //room模式，判断是否是房主,只有房主才显示开始按钮
        YcCommonUtils.setViewVisible(startGameBtn, YcRoomManager.getInstance().isRoomOwner());
    }


    /**
     * 离开房间确认框
     */
    protected void showLeaveRoomDialog() {

        CustomDialog dialog = new CustomDialog.Builder(getContext())
                .setMessage("确认要退出房间吗?")
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        callMgsLeaveRoom();
                    }
                })
                .create();
        dialog.show();
    }

    /**
     * 调用mgs的离开房间
     */
    public void callMgsLeaveRoom() {
        //先调用mgs的离开房间
        YcRoomManager.getInstance().leaveRoom(new YcRoomManager.OnLeaveRoomListener() {
            @Override
            public void onCompleted(boolean success) {
                if (success) {
                    //离开房间，销毁websocket
                    WebSocketManager.getInstance().disconnect();
                }
            }
        });
    }

    public void leaveRoomIfNeeded(String message) {
        ToastUtils.showToast(getContext(), message);
        callMgsLeaveRoom();
    }

    public void hideAllButton() {
        llButtons.setVisibility(GONE);
    }

}
