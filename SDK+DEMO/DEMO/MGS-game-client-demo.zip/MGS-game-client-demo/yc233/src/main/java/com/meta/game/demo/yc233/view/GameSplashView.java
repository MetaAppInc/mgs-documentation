package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.bean.UserResp;
import com.meta.game.demo.yc233.data.ApiResponse;
import com.meta.game.demo.yc233.data.ApiService;
import com.meta.game.demo.yc233.data.http.ResponseCallback;
import com.meta.game.demo.yc233.listener.OnCompletedListener;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.view.base.DefaultBaseView;
import com.meta.game.demo.yc233.widget.StrokeTextView;

import java.util.Map;

/**
 * 游戏启动页
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/03
 */
public class GameSplashView extends DefaultBaseView implements View.OnClickListener {
    private static final String TAG = "GameSplashView";
    private OnCompletedListener listener;
    private StrokeTextView      loginButton;

    public GameSplashView(@NonNull Context context) {
        super(context, R.layout.game_splash);
    }

    @Override
    protected void init(Context context){
        loginButton = findViewById(R.id.btn_login);
        loginButton.setVisibility(View.GONE);
        loginButton.setOnClickListener(this);
    }

    public void showLoginButton(){

        if (loginButton != null) {
            loginButton.setVisibility(View.VISIBLE);
        }

        callMgsLogin();
    }


    public void setOnCompletedListener(OnCompletedListener listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        callMgsLogin();
    }

    private void callMgsLogin() {

        showProgress();
        //invoke SDK login method
        MgsSdkBridgeHelper.getInstance().login(new MgsFeatureListener() {
            @Override
            public void onSuccess(int requestCode, String resultJson) {
                //返回值{"openId":"玩家openId","openCode":"玩家openCode","avatar":"头像地址","nickname":"昵称"}
                Log.i(TAG, "Mgs login success callback :" + resultJson);

                //json格式转换,这里使用Gson进行转换，游戏可能就自身需求使用不同的转换工具进行转换
                Map<String, String> result = new Gson().fromJson(resultJson,
                        new TypeToken<Map<String, String>>() {}.getType());
                //玩家openId
                String openId = result.get("openId");
                //玩家openCode
                String openCode = result.get("openCode");
                //玩家昵称
                String nickname = result.get("nickname");
                //玩家头像
                String avatar = result.get("avatar");

                //通知服务端登录结果
                requestLoginResultToServer(openId, openCode);

                dismissProgress();
            }

            @Override
            public void onFail(int requestCode, int code, String message) {
                ToastUtils.showToast(getContext(), "Mgs login fail callback "+message);
                dismissProgress();
            }
        });
    }

    /**
     * 请求服务端登录结果
     * @param openId
     * @param code
     */
    private void requestLoginResultToServer(String openId, String code){
        ApiService.login(openId, code, new ResponseCallback<ApiResponse<UserResp>>() {
            @Override
            public void onSuccess(ApiResponse<UserResp> response) {
                dismissProgress();
                Log.i(TAG, "login success=" + response);
                if (response.isSuccess()) {
                    ToastUtils.showToast(getContext(), "登陆成功");
                    //开始登录操作
                    if (listener != null) {
                        listener.onCompleted();
                    }
                } else {
                    onFailure(response.message);
                }

            }

            @Override
            public void onFailure(String error) {
                Log.e(TAG, "login fail=" + error);
                ToastUtils.showToast(getContext(), "登录失败!message:" + error);
               dismissProgress();
            }
        });

    }

}
