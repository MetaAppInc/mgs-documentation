package com.meta.game.demo.yc233.widget;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.meta.game.demo.yc233.R;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/29
 */
public class CustomDialog extends Dialog {

    private TextView titleTv;
    private TextView messageTv;
    private Button negativeButton;
    private Button positiveButton;

    private OnClickListener negativeClickListener;
    private OnClickListener positiveClickListener;

    private String title;
    private String message;
    private String negativeButtonText;
    private String positiveButtonText;

    public CustomDialog(@NonNull Context context) {
        super(context, R.style.CustomDialog);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_custom);

        titleTv = findViewById(R.id.tv_dialog_title);
        messageTv = findViewById(R.id.tv_dialog_message);
        negativeButton = findViewById(R.id.btn_negative);
        positiveButton = findViewById(R.id.btn_positive);

        negativeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (negativeClickListener != null) {
                    negativeClickListener.onClick(CustomDialog.this, 0);
                }
                dismiss();
            }
        });

        positiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (positiveClickListener != null) {
                    positiveClickListener.onClick(CustomDialog.this, 1);
                }
            }
        });

        initView();

    }

    private void initView() {
        if (TextUtils.isEmpty(title)) {
            titleTv.setVisibility(View.GONE);
        } else {
            titleTv.setVisibility(View.VISIBLE);
            setTitle(title);
        }

        setMessage(this.message);

        if (negativeClickListener != null) {
            negativeButton.setText(negativeButtonText);
            negativeButton.setVisibility(View.VISIBLE);
        } else {
            negativeButton.setVisibility(View.GONE);
        }

        if (positiveClickListener != null) {
            positiveButton.setText(positiveButtonText);
            positiveButton.setVisibility(View.VISIBLE);
        } else {
            positiveButton.setVisibility(View.GONE);
        }
    }


    /**
     * 设置标题
     * @param title
     */
    public void setTitle(String title) {
        if (!TextUtils.isEmpty(title)) {
            titleTv.setText(title);
        }
    }

    /**
     * 设置标题
     * @param message
     */
    public void setMessage(String message) {
        if (!TextUtils.isEmpty(message)) {
            messageTv.setText(message);
        }
    }


    public static class Builder {
        private Context mContext;
        private String title;
        private String message;
        private String negativeButtonText;
        private String positiveButtonText;
        private OnClickListener negativeClickListener;
        private OnClickListener positiveClickListener;

        public Builder(Context context) {
            this.mContext = context;
        }

        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }

        public Builder setMessage(String message) {
            this.message = message;
            return this;
        }

        public Builder setNegativeButton(String text, OnClickListener dialogListener) {
            this.negativeButtonText = text;
            this.negativeClickListener = dialogListener;
            return this;
        }

        public Builder setPositiveButton(String text, OnClickListener dialogListener) {
            this.positiveButtonText = text;
            this.positiveClickListener = dialogListener;
            return this;
        }

        public CustomDialog create(){
            CustomDialog dialog = new CustomDialog(mContext);
            dialog.title = title;
            dialog.message = message;
            dialog.negativeButtonText = negativeButtonText;
            dialog.negativeClickListener = negativeClickListener;
            dialog.positiveButtonText = positiveButtonText;
            dialog.positiveClickListener = positiveClickListener;
            return dialog;
        }
    }



}
