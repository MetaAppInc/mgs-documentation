package com.meta.game.demo.yc233.utils;

import android.content.Context;
import android.widget.Toast;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/20
 */
public class ToastUtils {
    public static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
