package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.adatper.PlayerAdapter;
import com.meta.game.demo.yc233.bean.PlayerInfo;
import com.meta.game.demo.yc233.bean.TeamInfo;
import com.meta.game.demo.yc233.bean.TeamPlayerListResp;
import com.meta.game.demo.yc233.data.YcRoomManager;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.view.base.DefaultBaseView;
import com.meta.game.demo.yc233.widget.StrokeTextView;

import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/18
 */
public class GameBattleView extends DefaultBaseView {

    /**
     * 左侧玩家列表
     */
    private RecyclerView leftRecyclerView;
    /**
     * 右侧玩家列表
     */
    private RecyclerView rightRecyclerView;

    private PlayerAdapter leftPlayerAdapter;
    private PlayerAdapter rightPlayerAdapter;

    List<TeamPlayerListResp> response;

    private StrokeTextView btnJoinAudio;
    private StrokeTextView btnLeaveAudio;
    private StrokeTextView btnAudioMute;
    private StrokeTextView btnAudioUnMute;

    public GameBattleView(@NonNull Context context) {
        super(context, R.layout.game_battle);
    }

    @Override
    protected void init(Context context) {
        leftRecyclerView = findViewById(R.id.rv_team_players_left);
        rightRecyclerView = findViewById(R.id.rv_team_players_right);

        btnJoinAudio = findViewById(R.id.btn_join_audio);
        btnLeaveAudio = findViewById(R.id.btn_leave_audio);
        btnAudioMute = findViewById(R.id.btn_audio_mute);
        btnAudioUnMute = findViewById(R.id.btn_audio_unmute);

        leftPlayerAdapter = new PlayerAdapter(getContext());
        rightPlayerAdapter = new PlayerAdapter(getContext());
        //配置左侧recycleview
        setRecyclerViewConfig(leftRecyclerView, leftPlayerAdapter);
        //配置右侧recycleview
        setRecyclerViewConfig(rightRecyclerView, rightPlayerAdapter);

        btnAudioMute.setOnClickListener(v -> audioMute());

        btnAudioUnMute.setOnClickListener(v -> unMuteAudio());

        btnJoinAudio.setOnClickListener(v -> joinAudio());

        btnLeaveAudio.setOnClickListener(v -> leaveAudio());
    }

    /**
     * 配置recyclerView
     * @param recyclerView
     * @param adapter
     */
    private void setRecyclerViewConfig(RecyclerView recyclerView, PlayerAdapter adapter) {
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getContext(),
                DividerItemDecoration.HORIZONTAL);
        itemDecoration.setDrawable(getResources().getDrawable(R.drawable.space_5));
        recyclerView.addItemDecoration(itemDecoration);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),4));
        recyclerView.setAdapter(adapter);
    }

    public void refreshBattleView(String currentTeam,
                                  List<TeamPlayerListResp> response) {

        TeamPlayerListResp leftTeam = null;
        TeamPlayerListResp rightTeam = null;
        for (TeamPlayerListResp resp : response) {
            TeamInfo teamInfo = resp.teamInfo;
            if (currentTeam.equals(teamInfo.teamId)) {
                leftTeam = resp;
            } else {
                rightTeam = resp;
            }
        }

        if (leftTeam != null) {
             refreshPlayerAdapter(leftPlayerAdapter, leftTeam.playerList, leftTeam.teamInfo.roomLimit,
                     R.drawable.icon_player_prepared_green);
        }

        if (rightTeam != null) {
             refreshPlayerAdapter(rightPlayerAdapter, rightTeam.playerList, rightTeam.teamInfo.roomLimit,
                     R.drawable.icon_player_prepared_yellow);
        }

    }


    /**
     * 刷新玩家列表
     */
    private void refreshPlayerAdapter(PlayerAdapter adapter,List<PlayerInfo> currentPlayers, int limitPlayer, int playerIconRes) {

        //当前房间玩家数量
        int playerSize = currentPlayers.size();
        //判断玩家数量是否达到上限,如果是就不需要补空位
        if (playerSize < limitPlayer) {
            int diff = limitPlayer - playerSize;
            for (int i = 0; i < diff; i ++) {
                currentPlayers.add(new PlayerInfo());
            }
        }

        adapter.refresh(currentPlayers, YcRoomManager.getInstance().getRoomInfo().roomOwner,playerIconRes);
    }

    private void unMuteAudio() {
        MgsSdkBridgeHelper.getInstance().unmuteAudio(new MgsFeatureListener() {
            @Override
            public void onSuccess(int i, String s) {
                ToastUtils.showToast(getContext(), "打开麦克风");
            }

            @Override
            public void onFail(int i, int i1, String s) {

            }
        });
    }

    private void audioMute() {
        MgsSdkBridgeHelper.getInstance().muteAudio(new MgsFeatureListener() {
            @Override
            public void onSuccess(int i, String s) {
                ToastUtils.showToast(getContext(), "关闭麦克风");
            }

            @Override
            public void onFail(int i, int i1, String s) {

            }
        });
    }

    private void leaveAudio() {
        MgsSdkBridgeHelper.getInstance().leaveAudio(new MgsFeatureListener() {
            @Override
            public void onSuccess(int i, String s) {
                ToastUtils.showToast(getContext(), "离开频道成功");
            }

            @Override
            public void onFail(int i, int i1, String s) {

            }
        });
    }

    private void joinAudio() {
        MgsSdkBridgeHelper.getInstance().joinAudio(new MgsFeatureListener() {
            @Override
            public void onSuccess(int i, String s) {
                ToastUtils.showToast(getContext(), "加入频道成功");
            }

            @Override
            public void onFail(int i, int i1, String s) {

            }
        });
    }

}
