package com.meta.game.demo.yc233.data.websocket;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.meta.game.demo.yc233.config.GameConfigHelper;
import com.meta.game.demo.yc233.data.YcUserManager;
import com.meta.game.demo.yc233.utils.HandlerUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

/**
 * websocket管理类
 *
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/09
 */
public class WebSocketManager {
    public static final  String           TAG          = "WebSocketHandler";
    private static       WebSocketManager sInstance;

    private static OkHttpClient sOkHttpClient = new OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .writeTimeout(5, TimeUnit.SECONDS)
            .pingInterval(5, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();

    private WebSocket mSocket;
    /**
     * 是否手动关闭
     */
    private boolean isManualClose = false;
    /**
     * 重连次数
     */
    private int              reconnectNumber    = 0;

    private final static int RECONNECT_INTERVAL = 5 * 1000;
    /**
     * 最大重连的间隔时间
     */
    private final static long RECONNECT_MAX_TIME = 60 * 1000;

    private static Handler   sHandler           = new Handler(Looper.myLooper());



    public static WebSocketManager getInstance() {
        if (sInstance == null) {
            sInstance = new WebSocketManager();
        }
        return sInstance;
    }


    private WsListener wsListener;

    private WebSocketListener webSocketListener = new WebSocketListener() {
        @Override
        public void onOpen(WebSocket webSocket, Response response) {
            super.onOpen(webSocket, response);
            mSocket = webSocket;
            Log.i(TAG, "web socket is connected");
            //socket连接成功，取消重连
            cancelReconnect();

            HandlerUtils.runOnUIThread(new Runnable() {
                @Override
                public void run() {
                    if (wsListener != null) {
                        wsListener.onWsConnected();
                    }
                }
            });


        }

        @Override
        public void onMessage(WebSocket webSocket, String text) {
            super.onMessage(webSocket, text);
            Log.i(TAG, "receive message=" + text);

            HandlerUtils.runOnUIThread(new Runnable() {
                @Override
                public void run() {
                    if (wsListener != null) {
                        wsListener.onWsMessage(text);
                    }
                }
            });
        }

        @Override
        public void onMessage(WebSocket webSocket, ByteString bytes) {
            super.onMessage(webSocket, bytes);
            Log.i(TAG, "web socket onMessage bytes=" + bytes);
        }

        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
            super.onClosing(webSocket, code, reason);
            Log.e(TAG, "web socket onClosing, code = " + code + ", reason = " + reason);
        }

        @Override
        public void onClosed(WebSocket webSocket, int code, String reason) {
            super.onClosed(webSocket, code, reason);
            Log.e(TAG, "web socket onClosed, code = " + code + ", reason = " + reason);
            HandlerUtils.runOnUIThread(new Runnable() {
                @Override
                public void run() {
                    if (wsListener != null) {
                        wsListener.onWsClosed(code, reason);
                    }
                }
            });
        }

        @Override
        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
            super.onFailure(webSocket, t, response);
            Log.e(TAG, "web socket onFailure" ,t );
            mSocket = null;

            tryReconnect();
            HandlerUtils.runOnUIThread(new Runnable() {
                @Override
                public void run() {
                    if (wsListener != null) {
                        wsListener.onWsDisconnected();
                    }
                }
            });
        }
    };

    private String webSocketUrl;

    /**
     * 开始链接
     * @param webSocketUrl
     * @param listener
     */
    public void startSocketConnection(String webSocketUrl, WsListener listener){
        this.webSocketUrl = webSocketUrl;
        this.wsListener = listener;
        isManualClose = false;
        connectToSocketServer();
    }

    /**
     * 连接socket服务
     */
    private void connectToSocketServer(){

        String originToken = YcUserManager.getInstance().getToken();
        String gameToken;
        try {

            gameToken = URLEncoder.encode(originToken,"UTF-8");
        } catch (UnsupportedEncodingException e) {
            Log.e(TAG, "token编码错误", e);
            gameToken = URLEncoder.encode(originToken);
        }

        Request request = new Request.Builder()
                .addHeader("gameToken", gameToken)
                .addHeader("appKey",  GameConfigHelper.getInstance().getAppKey())
                .url(webSocketUrl)
                .build();

        if (mSocket != null) {
            mSocket.cancel();
        }

        mSocket = sOkHttpClient.newWebSocket(request, webSocketListener);
    }

    /**
     * 重连服务
     */
    private Runnable reconnectRunnable = new Runnable() {
        @Override
        public void run() {
            Log.i(TAG,String.format("服务已断开,正在尝试第%d次重连", reconnectNumber));
            connectToSocketServer();
        }
    };

    /**
     * 尝试重连
     */
    private void tryReconnect() {

        if (isManualClose) {
            //手动关闭连接无需重连
            return;
        }
        long delay = reconnectNumber * RECONNECT_INTERVAL;
        sHandler.postDelayed(reconnectRunnable, Math.min(delay, RECONNECT_MAX_TIME));
        reconnectNumber ++;
    }

    /**
     * 取消重连
     */
    private void cancelReconnect(){
        sHandler.removeCallbacks(reconnectRunnable);
        reconnectNumber = 0;
    }

    /**
     * 发送字符串消息
     * @param text
     */
    public void sendMessage(String text) {
        if (mSocket != null) {
            Log.i(TAG,"send message=" + text);
            mSocket.send(text);
        }
    }

    /**
     * 手动断开连接
     */
    public void disconnect(){
        Log.i(TAG, "手动断开连接...");
        //手动关闭连接
        isManualClose = true;
        //取消重连
        cancelReconnect();
        //取消所有连接
        sOkHttpClient.dispatcher().cancelAll();
        if (mSocket != null) {
            mSocket.cancel();
            mSocket = null;
        }
    }

    /**
     * socket监听
     */
    public interface WsListener {
        void onWsConnected();
        void onWsMessage(String message);
        void onWsClosed(int code, String reason);
        void onWsDisconnected();
    }
}
