package com.meta.game.demo.yc233.event;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/28
 */
public class AddFriendEvent {
}
