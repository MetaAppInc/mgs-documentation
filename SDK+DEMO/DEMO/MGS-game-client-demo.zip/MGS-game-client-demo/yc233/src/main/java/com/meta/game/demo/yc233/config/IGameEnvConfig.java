package com.meta.game.demo.yc233.config;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/28
 */
public interface IGameEnvConfig {
    public String getAppKey();
    public String getBaseUrl();
    public String getWsUrl();
}
