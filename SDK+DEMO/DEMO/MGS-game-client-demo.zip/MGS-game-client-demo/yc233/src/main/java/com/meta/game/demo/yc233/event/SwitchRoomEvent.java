package com.meta.game.demo.yc233.event;


import com.meta.game.demo.yc233.bean.RoomResp;
import com.meta.game.demo.yc233.bean.YcRoomInfo;

public class SwitchRoomEvent {

    private RoomResp roomResp;
    private String   resultJson;

    public SwitchRoomEvent(RoomResp roomResp, String resultJson) {
        this.roomResp = roomResp;
        this.resultJson = resultJson;
    }

    public RoomResp getRoomResp() {
        return roomResp;
    }

    public String getResultJson() {
        return resultJson;
    }
}
