package com.meta.game.demo.yc233.data;

import com.meta.game.demo.yc233.bean.ProductInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/04/15
 */
public class YcMallManager {

    public static List<ProductInfo> getProductData(){
       List<ProductInfo> productInfoList = new ArrayList<ProductInfo>();

        productInfoList.add(new ProductInfo("yc233_product_1","10钻石",1));
        productInfoList.add(new ProductInfo("yc233_product_2","60钻石",6));
        productInfoList.add(new ProductInfo("yc233_product_3","120钻石",12));

        return productInfoList;
    }
}
