package com.meta.game.demo.yc233.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.TextView;

import com.meta.game.demo.yc233.R;

public class StrokeTextView extends AppCompatTextView {
    private TextView outlineTextView = null;
    private int      mStrokeColor    = Color.WHITE;
    private float    mStrokeWidth    = 0;

    public StrokeTextView(Context context) {
        super(context);
        init(context, null, 0);
    }

    public StrokeTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs, 0);
    }

    public StrokeTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context, attrs, defStyle);
    }

    public void init(Context context, AttributeSet attrs, int defStyle) {
        if (attrs != null) {
            TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.StrokeTextView);
            mStrokeColor = typedArray.getColor(R.styleable.StrokeTextView_textStrokeColor, Color.WHITE);
            mStrokeWidth = typedArray.getDimension(R.styleable.StrokeTextView_textStrokeWidth, 0f);
            typedArray.recycle();
        }
        outlineTextView = new TextView(context, attrs, defStyle);
        TextPaint paint = outlineTextView.getPaint();
        paint.setStrokeWidth(mStrokeWidth);// 描边宽度
        paint.setStyle(Paint.Style.STROKE);
        paint.setAntiAlias(true);
        outlineTextView.setTextColor(mStrokeColor);// 描边颜色
        outlineTextView.setGravity(getGravity());
    }

    @Override
    public void setLayoutParams(ViewGroup.LayoutParams params) {
        super.setLayoutParams(params);
        outlineTextView.setLayoutParams(params);
    }



    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        CharSequence tt = outlineTextView.getText();

        // 两个TextView上的内容必须一致
        if (tt == null || !tt.equals(this.getText())) {
            outlineTextView.setText(getText());
            this.postInvalidate();
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        outlineTextView.measure(widthMeasureSpec, heightMeasureSpec);
    }


    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        outlineTextView.layout(left, top, right, bottom);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        outlineTextView.draw(canvas);
        super.onDraw(canvas);
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        super.setText(text, type);
        if (outlineTextView != null) {
            outlineTextView.setText(text);
        }
    }

}