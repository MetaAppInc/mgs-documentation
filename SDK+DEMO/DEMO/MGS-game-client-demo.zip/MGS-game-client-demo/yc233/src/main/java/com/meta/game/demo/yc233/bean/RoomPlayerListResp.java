package com.meta.game.demo.yc233.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/24
 */
public class RoomPlayerListResp {
    public List<PlayerInfo> playerList = new ArrayList<>();
    public YcRoomInfo       roomInfo;

    @Override
    public String toString() {
        return "RoomPlayerResp{" +
                "playerList=" + playerList +
                ", roomInfo=" + roomInfo +
                '}';
    }
}
