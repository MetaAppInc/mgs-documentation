package com.meta.game.demo.yc233.view;

import android.annotation.SuppressLint;
import android.util.Log;

import com.meta.game.demo.yc233.bean.BalanceInfo;
import com.meta.game.demo.yc233.data.ApiResponse;
import com.meta.game.demo.yc233.data.ApiService;
import com.meta.game.demo.yc233.data.http.ResponseCallback;
import com.meta.game.demo.yc233.view.base.BaseViewDelegate;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/05/08
 */
public class GameMainViewDelegate extends BaseViewDelegate {
    private static final String TAG = "GameMainViewDelegate";
    private GameMainView mView;

    public GameMainViewDelegate(GameMainView view) {
        mView = view;
    }

    @Override
    public void onCreated() {
        //刷新余额
        refreshBalance();
    }

    /**
     * 刷新余额
     */
    public void refreshBalance() {
        ApiService.getBalance(new ResponseCallback<ApiResponse<BalanceInfo>>() {
            @SuppressLint("DefaultLocale")
            @Override
            public void onSuccess(ApiResponse<BalanceInfo> response) {
                if (response.isSuccess()) {
                    BalanceInfo balanceInfo = response.data;
                    mView.vipTv.setText(String.format("%d钻石", balanceInfo.balance));
                } else {
                    onFailure(response.message);
                }
            }

            @Override
            public void onFailure(String error) {
                Log.i(TAG, "获取余额失败:" + error);
            }
        });
    }
}
