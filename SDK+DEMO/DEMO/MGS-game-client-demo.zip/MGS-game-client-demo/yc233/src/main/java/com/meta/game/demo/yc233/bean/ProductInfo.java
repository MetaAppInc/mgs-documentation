package com.meta.game.demo.yc233.bean;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/04/15
 */
public class ProductInfo {

    public String productCode;
    public String productName;
    public int price;

    public ProductInfo() {
    }

    public ProductInfo(String productCode, String productName, int price) {
        this.productCode = productCode;
        this.productName = productName;
        this.price = price;
    }

    @Override
    public String toString() {
        return "ProductInfo{" +
                "productCode='" + productCode + '\'' +
                ", productName='" + productName + '\'' +
                ", price=" + price +
                '}';
    }
}
