package com.meta.game.demo.yc233.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/04
 */
public class GameConstants {

    /**
     * 游戏模式-room 1v7
     */
    public static final int GAME_MODE_1V7 = 3;

    /**
     * 游戏模式-组队101
     */
    public static final int GAME_MODE_5V5 = 101;
    /**
     * 游戏模式-组队102 躲猫猫
     */
    public static final int GAME_MODE_DMM = 102;

    public static final Map<Integer, String> GAME_MODE_MAP = new HashMap<Integer, String>(){
        {
            put(GAME_MODE_1V7, "大乱斗");
            put(GAME_MODE_5V5, "5v5");
            put(GAME_MODE_DMM, "捉迷藏");
        }
    };


    /**
     * 游戏准备中
     */
    public static final int GAME_STATE_PREPARE = 0;
    /**
     * 游戏中
     */
    public static final int GAME_STATE_PROGRESSING = 1;
    /**
     * 游戏结束
     */
    public static final int GAME_STATE_END = 2;
}
