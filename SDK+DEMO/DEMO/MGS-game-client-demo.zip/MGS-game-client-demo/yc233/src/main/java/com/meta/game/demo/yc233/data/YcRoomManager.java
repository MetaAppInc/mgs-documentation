package com.meta.game.demo.yc233.data;

import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.bean.RoomResp;
import com.meta.game.demo.yc233.bean.YcRoomInfo;
import com.meta.game.demo.yc233.data.http.ResponseCallback;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.view.GameSceneView;

import java.util.Map;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/24
 */
public class YcRoomManager {
    private static final String        TAG = "YcRoomManager";
    private static       YcRoomManager sInstance;

    private GameSceneView        sceneView;
    private YcRoomInfo           currentRoomInfo;
    private OnLeaveRoomListener  clearRoomListener;
    private OnSwitchRoomListener switchRoomListener;

    public static YcRoomManager getInstance() {
        if (sInstance == null) {
            sInstance = new YcRoomManager();
        }

        return sInstance;
    }

    /**
     * 设置当前的房间信息
     *
     * @param currentRoomInfo
     */
    public void setCurrentRoom(GameSceneView sceneView, YcRoomInfo currentRoomInfo) {
        this.sceneView = sceneView;
        this.currentRoomInfo = currentRoomInfo;
    }

    /**
     * 离开房间
     *
     * @param listener
     */
    public void leaveRoom(OnLeaveRoomListener listener) {
        this.clearRoomListener = listener;

        if (listener != null && currentRoomInfo == null) {
            sendCallback(true);
            return;
        }

        callMgsLeaveRoom();
    }

    public void switchRoom(RoomResp target, OnSwitchRoomListener listener) {
        this.switchRoomListener = listener;
        if (listener != null && currentRoomInfo == null) {
            sendSwitchCallback(false, null, "");
            return;
        }

        MgsSdkBridgeHelper.getInstance().switchRoom(currentRoomInfo.roomId, target.roomInfo.roomId, new MgsFeatureListener() {
            @Override
            public void onSuccess(int requestCode, String resultJson) {
                Log.i(TAG, "switch room success= " + resultJson);
                if (TextUtils.isEmpty(resultJson)) {
                    ToastUtils.showToast(sceneView.getContext(), "MGS返回房间信息为空,MGS可能未创建或无法加入");
                    return;
                }

                hideAllBtn();
                clearAllViews();
                sendSwitchCallback(true, target, resultJson);
            }

            @Override
            public void onFail(int requestCode, int code, String message) {
                String error = "mgs-离开房间失败:" + message;
                Log.e(TAG, error);
            }
        });
    }

    public YcRoomInfo getRoomInfo() {
        return currentRoomInfo;
    }


    /**
     * 调用mgs离开房间接口
     */
    private void callMgsLeaveRoom() {
        MgsSdkBridgeHelper.getInstance().leaveRoom(currentRoomInfo.roomId, new MgsFeatureListener() {
            @Override
            public void onSuccess(int requestCode, String resultJson) {

                Log.i(TAG, "leave room success= " + resultJson);
                requestLeaveRoomToServer();
            }

            @Override
            public void onFail(int requestCode, int code, String message) {
                String error = "mgs-离开房间失败:" + message;
                Log.e(TAG, error);

                if (code == 80001) {
                    //房间不存在,请求服务端离开房间
                    requestLeaveRoomToServer();
                }
            }
        });
    }

    /**
     * 通知服务端要离开房间
     */
    private void requestLeaveRoomToServer() {

        if (currentRoomInfo == null) {
            Log.e(TAG, "requestLeaveRoomToServer currentRoomInfo is null");
            return;
        }
        ApiService.leaveRoom(currentRoomInfo.roomId, new ResponseCallback<ApiResponse<Boolean>>() {
            @Override
            public void onSuccess(ApiResponse<Boolean> response) {
                if (response.isSuccess() && response.data) {
                    sendCallback(true);
                    clearAllViews();
                } else {
                    onFailure("离开房间失败");
                }
            }

            @Override
            public void onFailure(String error) {
                if (sceneView != null) {
                    ToastUtils.showToast(sceneView.getContext(), error);
                }

                sendCallback(false);
            }
        });
    }


    /**
     * 判断当前用户是不是房主
     *
     * @return
     */
    public boolean isRoomOwner() {
        if (currentRoomInfo == null) {
            return false;
        }
        String currentOpenId = YcUserManager.getInstance().getOpenId();
        String roomOwnerId = currentRoomInfo.roomOwner;
        Log.i(TAG, "currentOpenId=" + currentOpenId + ", roomOwnerId=" + roomOwnerId);
        return currentOpenId.equals(roomOwnerId);
    }


    private void sendCallback(boolean flag) {
        if (clearRoomListener != null) {
            clearRoomListener.onCompleted(flag);
            clearRoomListener = null;
        }
    }

    private void sendSwitchCallback(boolean flag, RoomResp targetRoomInfo, String resultJson) {
        if (switchRoomListener != null) {
            switchRoomListener.onCompleted(flag, targetRoomInfo, resultJson);
            switchRoomListener = null;
        }
    }

    private void clearAllViews() {
        if (sceneView != null) {
            sceneView.removeFromParent();
            sceneView = null;
        }
        currentRoomInfo = null;
    }

    private void hideAllBtn() {
        if (sceneView != null) {
            sceneView.hideAllButton();
        }
    }

    public interface OnLeaveRoomListener {
        void onCompleted(boolean success);
    }

    public interface OnSwitchRoomListener {
        void onCompleted(boolean flag, RoomResp targetRoomInfo, String resultJson);
    }
}
