package com.meta.game.demo.yc233.bean;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class UserInfo {

    /**
     * 开发者平台的用户id
     */
    public String openId = "";
    /**
     * 开发者平台的用户code
     */
    public String openCode = "";
    /**
     * 昵称
     */
    public String nickname = "";
    /**
     * 头像
     */
    public String avatar = "";

    @Override
    public String toString() {
        return "UserInfo{" +
                "openId='" + openId + '\'' +
                ", openCode='" + openCode + '\'' +
                ", nickname='" + nickname + '\'' +
                ", avatar='" + avatar + '\'' +
                '}';
    }
}
