package com.meta.game.demo.yc233.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.bean.OrderInfo;
import com.meta.game.demo.yc233.bean.ProductInfo;
import com.meta.game.demo.yc233.data.ApiResponse;
import com.meta.game.demo.yc233.data.ApiService;
import com.meta.game.demo.yc233.data.YcMallManager;
import com.meta.game.demo.yc233.data.http.ResponseCallback;
import com.meta.game.demo.yc233.event.RefreshBalanceEvent;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.view.base.DefaultBaseView;

import org.greenrobot.eventbus.EventBus;

/**
 * 游戏商城界面
 * @author zhiwei.xu@appshahe.com
 * @date 2021/04/15
 */
public class GameMallView extends DefaultBaseView implements View.OnClickListener {
    private static final String TAG = "GameMallView";

    private int              pollingTime = 0;
    private static final int INTERVAL    = 1_000;

    private static Handler sHandler = new Handler();

    /**
     * 是否正在支付中
     */
    private boolean isPaying = false;
    private String currentOrderId = "";

    public GameMallView(@NonNull Context context) {
        super(context, R.layout.game_mall);
    }

    @Override
    protected void init(Context context) {
        ImageButton closeBtn = findViewById(R.id.btn_close);
        closeBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                stopOrderPolling();
                EventBus.getDefault().post(new RefreshBalanceEvent());
                removeFromParent();
            }
        });

        ImageView leftImageView = findViewById(R.id.iv_mall_product_item_left);
        ImageView centerImageView = findViewById(R.id.iv_mall_product_item_center);
        ImageView rightImageView = findViewById(R.id.iv_mall_product_item_right);

        leftImageView.setOnClickListener(this);
        centerImageView.setOnClickListener(this);
        rightImageView.setOnClickListener(this);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {

        if (isPaying) {
            ToastUtils.showToast(getContext(),"正在支付中,请稍后...");
            return;
        }

        int index = 0;
        switch (v.getId()) {
            case R.id.iv_mall_product_item_left:
                index = 0;
            break;
            case R.id.iv_mall_product_item_center:
                index = 1;
                break;
            case R.id.iv_mall_product_item_right:
                index = 2;
                break;
            default:
                break;
        }

        ProductInfo productInfo = YcMallManager.getProductData().get(index);
        placeOrderFromServer(productInfo);

    }


    /**
     * 服务端下单
     * @param productInfo
     */
    public void placeOrderFromServer(ProductInfo productInfo) {
        isPaying = true;
        showProgress("正在下单...");
        ApiService.placeOrder(productInfo.productCode, new ResponseCallback<ApiResponse<OrderInfo>>() {
            @Override
            public void onSuccess(ApiResponse<OrderInfo> response) {
                dismissProgress();
                if (response.isSuccess()) {
                    OrderInfo orderInfo = response.data;
                    currentOrderId = orderInfo.orderId;
                    startMgsPay(orderInfo.extra, productInfo);
                } else {
                     onFailure(response.message);
                }
            }

            @Override
            public void onFailure(String error) {
                currentOrderId = "";
                //下单失败，重置支付状态
                isPaying = false;
                dismissProgress();
                ToastUtils.showToast(getContext(), "服务端下单失败:"+error);
            }
        });
    }


    /**
     * 调用mgs的支付
     * @param productInfo
     */
    public void startMgsPay(String extra, ProductInfo productInfo) {
        //商品价格，单位是分
        int price = productInfo.price * 100;

        MgsSdkBridgeHelper.getInstance().pay(currentOrderId, productInfo.productCode,
                productInfo.productName, price, extra, new MgsFeatureListener() {
            @Override
            public void onSuccess(int requestCode, String resultData) {
                Log.i(TAG, "支付成功回调=" + resultData);
                ToastUtils.showToast(getContext(), "支付成功：" + resultData);
                queryOrderStatus();
                isPaying = false;

            }

            @Override
            public void onFail(int requestCode, int code, String message) {
                ToastUtils.showToast(getContext(), "支付失败:" + message);
                Log.i(TAG, "支付失败回调=" + message);
                queryOrderStatus();
                isPaying = false;
            }
        });

    }

    private void queryOrderStatus(){
        showProgress("查询订单状态...");
        queryOrderStatusFromServer();
        startOrderPolling();
    }

    private void queryOrderStatusFromServer() {
        //正常需要轮询一会儿
        ApiService.queryOrderStatus(currentOrderId, new ResponseCallback<ApiResponse<OrderInfo>>() {
            @Override
            public void onSuccess(ApiResponse<OrderInfo> response) {
                dismissProgress();
                if (response.isSuccess()) {
                     Log.i(TAG, "订单状态查询结果=" + response);
                    if (response.data.orderStatus == 2 ||  response.data.orderStatus == -1) {
                        //到账后，停止心跳
                        stopOrderPolling();
                    }

                    EventBus.getDefault().post(new RefreshBalanceEvent());
                } else {
                    onFailure(response.message);
                }

            }

            @Override
            public void onFailure(String error) {
                Log.i(TAG, "订单状态查询失败=" + error);
                dismissProgress();
                EventBus.getDefault().post(new RefreshBalanceEvent());
            }
        });
    }

    /**
     * 重连服务
     */
    private Runnable pollingRunnable = new Runnable() {
        @Override
        public void run() {
            Log.i(TAG,String.format("发起%s次订单轮询请求", pollingTime));
            queryOrderStatusFromServer();
        }
    };

    /**
     * 尝试重连
     */
    private void startOrderPolling() {

        Log.i(TAG, "开始订单轮询");
        long delay = pollingTime * INTERVAL;
        if (pollingTime > 5) {
            stopOrderPolling();
            return;
        }
        sHandler.postDelayed(pollingRunnable, delay);
        pollingTime++;
    }

    /**
     * 取消重连
     */
    private void stopOrderPolling(){
        sHandler.removeCallbacks(pollingRunnable);
        pollingTime = 0;
        Log.i(TAG, "结束订单轮询");
    }

}
