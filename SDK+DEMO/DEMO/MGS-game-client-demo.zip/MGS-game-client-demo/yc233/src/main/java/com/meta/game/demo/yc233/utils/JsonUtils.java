package com.meta.game.demo.yc233.utils;

import android.text.TextUtils;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/14
 */
public class JsonUtils {

    public static JSONObject createJsonObject(String json) throws JSONException {
        return new JSONObject(TextUtils.isEmpty(json) ? "{}" : json);
    }

    public static int getInt(JSONObject jsonObject, String key, int defaultValue) throws JSONException {
        return (jsonObject != null && jsonObject.has(key)) ? jsonObject.getInt(key) : defaultValue;
    }

    public static String getString(JSONObject jsonObject, String key) throws JSONException {
        return (jsonObject != null && jsonObject.has(key)) ? jsonObject.getString(key) : "";
    }

    public static boolean getBoolean(JSONObject jsonObject, String key) throws JSONException {
        return (jsonObject != null && jsonObject.has(key)) && jsonObject.getBoolean(key);
    }
}
