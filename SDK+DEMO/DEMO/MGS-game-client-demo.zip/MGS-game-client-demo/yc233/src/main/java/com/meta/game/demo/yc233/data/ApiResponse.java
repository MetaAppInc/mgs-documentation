package com.meta.game.demo.yc233.data;

import java.io.Serializable;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class ApiResponse<T> implements Serializable {

    private static final int CODE_OK = 200;

    public int code;
    public String message;

    public T data;

    /**
     * 根据code判断是否成功
     * @return
     */
    public boolean isSuccess() {
        return code == CODE_OK;
    }

    @Override
    public String toString() {
        return "ApiResponse{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}
