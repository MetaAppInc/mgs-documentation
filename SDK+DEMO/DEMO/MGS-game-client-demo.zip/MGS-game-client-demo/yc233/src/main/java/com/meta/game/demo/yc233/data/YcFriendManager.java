package com.meta.game.demo.yc233.data;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/22
 */
public class YcFriendManager {

    private static volatile YcFriendManager sInstance;

    private Map<String, Boolean> friendshipMap = new HashMap<>();

    public static YcFriendManager getInstance() {
        if (sInstance == null) {
            sInstance = new YcFriendManager();
        }
        return sInstance;
    }

    /**
     * 好友数据填充
     * @param map
     */
    public void putFriendship(Map<String, Boolean> map){
        friendshipMap.putAll(map);
    }

    public void clearFriendship() {
        friendshipMap.clear();
    }

    public boolean isMyFriend(String openId) {
        return friendshipMap.containsKey(openId) ? friendshipMap.get(openId) : false;
    }

}
