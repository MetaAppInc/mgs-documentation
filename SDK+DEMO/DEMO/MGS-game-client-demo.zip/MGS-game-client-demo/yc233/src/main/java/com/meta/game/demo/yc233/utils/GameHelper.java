package com.meta.game.demo.yc233.utils;

import com.meta.game.demo.yc233.constants.GameConstants;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/18
 */
public class GameHelper {
    /**
     * 是否是team模式
     * @return
     */
    public static boolean isTeamMode(int roomType) {
        return roomType == GameConstants.GAME_MODE_5V5
                || roomType == GameConstants.GAME_MODE_DMM;
    }
}
