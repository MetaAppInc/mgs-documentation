package com.meta.game.demo.yc233.bean;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/05/08
 */
public class BalanceInfo {
    /**
     * 余额
     */
    public int balance;
    public String openId;
    /**
     * 货币类型
     */
    public int currencyType;
}
