package com.meta.game.demo.yc233.event;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/05/07
 */
public class ChangeOrientationEvent {
}
