package com.meta.game.demo.yc233.bean;

/**
 * 订单信息
 * @author zhiwei.xu@appshahe.com
 * @date 2021/05/08
 */
public class OrderInfo {
    public String openId;
    public String orderId;
    public int orderStatus;
    public String propCode;
    public String propNumber;
    public String extra;

    @Override
    public String toString() {
        return "OrderInfo{" +
                "openId='" + openId + '\'' +
                ", orderId='" + orderId + '\'' +
                ", orderStatus=" + orderStatus +
                ", propCode='" + propCode + '\'' +
                ", propNumber='" + propNumber + '\'' +
                ", extra='" + extra + '\'' +
                '}';
    }
}
