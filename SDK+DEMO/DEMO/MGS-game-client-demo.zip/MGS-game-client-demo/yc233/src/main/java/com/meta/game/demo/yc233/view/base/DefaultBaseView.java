package com.meta.game.demo.yc233.view.base;

import android.content.Context;
import android.support.annotation.NonNull;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/05/08
 */
public abstract class DefaultBaseView extends AbstractBaseView {

    public DefaultBaseView(@NonNull Context context, int layoutId) {
        super(context, layoutId);
    }

    @Override
    protected BaseViewDelegate createViewDelegate() {
        return new BaseViewDelegate() {
            @Override
            public void onCreated() {

            }
        };
    }

}
