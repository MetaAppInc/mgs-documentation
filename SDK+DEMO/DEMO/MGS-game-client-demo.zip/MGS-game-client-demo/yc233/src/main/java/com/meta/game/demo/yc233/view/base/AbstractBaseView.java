package com.meta.game.demo.yc233.view.base;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.listener.OnBackClickListener;

import org.greenrobot.eventbus.EventBus;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/03
 */
public abstract class AbstractBaseView<T extends BaseViewDelegate> extends FrameLayout {
    private static final String TAG = "AbstractBaseView";
    protected OnBackClickListener onBackClickListener;
    private   View progressView;
    protected T      viewDelegate;

    public AbstractBaseView(@NonNull Context context, @LayoutRes int layoutId) {
        super(context);
        inflate(context, layoutId, this);
        init(context);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (isNeedEventBus()) {
            //注册事件监听
            EventBus.getDefault().register(this);
        }


        if (viewDelegate == null) {
            viewDelegate = createViewDelegate();
        }
        if (viewDelegate != null) {
            viewDelegate.onCreated();
        }

    }

    protected boolean isNeedEventBus(){
        return false;
    }

    /**
     * 创建代理
     * @return
     */
    protected abstract T createViewDelegate();

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (isNeedEventBus()) {
            //反注册事件监听
            EventBus.getDefault().unregister(this);
        }

        if (viewDelegate != null) {
            viewDelegate.onDestroyed();
        }


    }

    public void showProgress() {
        showProgress("正在处理中,请稍后...");
    }

    /**
     * 显示进度条
     * @param message
     */
    public void showProgress(String message) {

        Log.i(TAG, "显示加载条 - at " + getClass().getSimpleName());

        if (progressView == null) {
            progressView = LayoutInflater.from(getContext()).inflate(R.layout.game_progress, null);
            progressView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                 //   dismissProgress();
                }
            });
            addView(progressView);
        }
        TextView messageTextView = findViewById(R.id.tv_progress_message);
        messageTextView.setText(message);

    }

    public void dismissProgress() {
        Log.i(TAG, "移除加载条 - at " + getClass().getSimpleName());
        if (progressView != null) {
           removeView(progressView);
           progressView = null;
        }
    }


    public void setOnBackClickListener(OnBackClickListener onBackClickListener) {
        this.onBackClickListener = onBackClickListener;
    }

    protected abstract void init(Context context);

    /**
     * 移除自身
     */
    public void removeFromParent(){
        ViewParent parent = getParent();
        if (parent != null) {
            ((ViewGroup)parent).removeView(this);
        }
    }

}
