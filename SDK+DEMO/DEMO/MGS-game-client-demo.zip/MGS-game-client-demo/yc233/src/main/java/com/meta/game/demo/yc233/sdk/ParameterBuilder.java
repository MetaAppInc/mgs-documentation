package com.meta.game.demo.yc233.sdk;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * map构建模式封装
 *
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/04
 */
public class ParameterBuilder<T> {

    private final Builder<T> builder;

    private ParameterBuilder(Builder<T> builder) {
        this.builder = builder;
    }

    public Map<String, T> map() {
        return builder.map;
    }

    /**
     * 获取json格式字符串
     * @return
     */
    public String toJson(){
        JSONObject jsonObject = new JSONObject(builder.map);
        return jsonObject.toString();
    }


    public static class Builder<T> {
        public Map<String, T> map;

        public Builder() {
            map = new HashMap<>();
        }

        public Builder<T> put(String key, T value) {
            map.put(key, value);
            return this;
        }

        public ParameterBuilder<T> build() {
            return new ParameterBuilder<T>(this);
        }
    }
}
