package com.meta.game.demo.yc233.data.http;

import android.util.Log;

import com.google.gson.Gson;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public abstract class ResponseCallback<T> {

    private static final Gson GSON = new Gson();

    public T parseResponse(String response) {

        Log.i("http-callback", "response-->" + response);

         Type type = ((ParameterizedType) getClass()
                .getGenericSuperclass()).getActualTypeArguments()[0];

        T result = GSON.fromJson(response, type);

        if (result != null) {
            onSuccess(result);
        } else {
            onFailure("parse error!");
        }

        return result;
    }

    /**
     * 成功回调
     * @param response
     */
    public abstract void onSuccess(T response);

    /**
     * 失败回调
     * @param error
     */
    public abstract void onFailure(String error);
}
