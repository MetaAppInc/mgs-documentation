package com.meta.game.demo.yc233.data;

import com.meta.game.demo.yc233.bean.RoomPlayerListResp;
import com.meta.game.demo.yc233.bean.UserResp;
import com.meta.game.demo.yc233.data.http.ResponseCallback;

import org.junit.Before;
import org.junit.Test;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class ApiServiceTest {


    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void login() {
        ApiService.login("1221212", "322323233223", new ResponseCallback<ApiResponse<UserResp>>() {
            @Override
            public void onSuccess(ApiResponse<UserResp> response) {
                System.out.println("-->"+response);
            }

            @Override
            public void onFailure(String error) {
                System.out.println("--> onFailure ");

            }
        });
    }

    @Test
    public void createRoom() {

    }

    @Test
    public void joinRoom() {

    }

    @Test
    public void leaveRoom() {
        ApiService.leaveRoom("1212", new ResponseCallback<ApiResponse<Boolean>>() {
            @Override
            public void onSuccess(ApiResponse<Boolean> response) {
                System.out.println("-->"+response);
            }

            @Override
            public void onFailure(String error) {
                System.out.println("--> onFailure ");
            }
        });
    }

    @Test
    public void queryPlayerList() {
        ApiService.queryPlayerList("1212", new ResponseCallback<ApiResponse<RoomPlayerListResp>>() {
            @Override
            public void onSuccess(ApiResponse<RoomPlayerListResp> response) {
                System.out.println("-->"+response);
            }

            @Override
            public void onFailure(String error) {
                System.out.println("--> onFailure ");
            }
        });
    }

}