package com.meta.game.demo.yc233.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.view.View;

import com.meta.game.demo.yc233.BuildConfig;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/14
 */
public class YcCommonUtils {

    /**
     * 设置view是否可见
     * @param view
     * @param isVisible
     */
    public static void setViewVisible(View view, boolean isVisible) {
        if (view != null) {
            view.setVisibility(isVisible ? View.VISIBLE : View.GONE);
        }
    }

    /**
     * 获取版本号
     */
    public static String getVersionName(Context context) {
        String localVersion = "";
        try {
            PackageInfo packageInfo = context.getApplicationContext()
                    .getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            localVersion = packageInfo.versionName;

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            localVersion = BuildConfig.VERSION_NAME;
        }
        return localVersion;
    }
}
