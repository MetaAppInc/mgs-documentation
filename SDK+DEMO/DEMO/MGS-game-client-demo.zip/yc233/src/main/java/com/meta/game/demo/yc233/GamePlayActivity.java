package com.meta.game.demo.yc233;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.meta.android.mgs.MgsApi;
import com.meta.android.mgs.listener.MgsEventListener;
import com.meta.android.mgs.listener.MgsInitListener;
import com.meta.game.demo.yc233.config.GameConfigHelper;
import com.meta.game.demo.yc233.data.YcFriendManager;
import com.meta.game.demo.yc233.data.YcRoomManager;
import com.meta.game.demo.yc233.listener.OnCompletedListener;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.DisplayUtils;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.utils.YcCommonUtils;
import com.meta.game.demo.yc233.view.GameMainView;
import com.meta.game.demo.yc233.view.GameSplashView;

/**
 * 游戏主Activity
 */
public class GamePlayActivity extends Activity {

    private static final String TAG = "GamePlayActivity";

    private GameSplashView splashView;
    private GameMainView   mainView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //去标题全屏显示
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //初始化环境配置
        GameConfigHelper.getInstance().initConfig(this);

        //游戏开屏
        splashView = new GameSplashView(this);
        setContentView(splashView);

        //开启MGS日志,正式发布版本是请关闭
        MgsApi.getInstance().setDebugLog(true);
        //SDK初始化，尽可能早的初始化
        MgsSdkBridgeHelper.getInstance().initSdk(this, GameConfigHelper.getInstance().getAppKey(), new MgsInitListener() {
            @Override
            public void onSuccess() {
                 Log.i(TAG, "SDK初始化成功");
                //注册主动通知事件
                registerMgsEvent();

                if (mainView != null) {
                    mainView.dismissProgress();
                    return;
                }
                if (splashView != null) {
                    splashView.showLoginButton();
                }

            }

            @Override
            public void onFail(int code, String message) {
                Log.e(TAG, "SDK初始化失败=" + message);
            }
        });


        splashView.setOnCompletedListener(new OnCompletedListener() {
            @Override
            public void onCompleted() {
                mainView = new GameMainView(GamePlayActivity.this);
                //登录成功跳转到游戏首页
                setContentView(mainView);
                splashView = null;
            }
        });

    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);

        if (view instanceof FrameLayout) {
            showCurrentEnvironment((FrameLayout) view);
        }
    }

    private void showCurrentEnvironment(FrameLayout parent) {

         TextView textView = new TextView(this);
        textView.setText("当前环境:" + GameConfigHelper.getInstance().getCurrentEnvName()
                + ",version=" + YcCommonUtils.getVersionName(this));
        textView.setTextColor(getResources().getColor(R.color.white));
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        layoutParams.rightMargin = DisplayUtils.dp2px(this, 50);
        parent.addView(textView,layoutParams);
    }

    /**
     * 注册mgs主动通知事件
     */
    private void registerMgsEvent() {
        //监听退出游戏事件
        MgsApi.getInstance().registerMgsEventListener("exitGameEvent", new MgsEventListener() {
            @Override
            public void onMgsEventHandle(String jsonData) {
                //退出游戏逻辑处理
                Log.i(TAG, "退出游戏事件处理回调");

                //清理游戏相关信息，如清理房间信息等操作
                YcRoomManager.getInstance().leaveRoom(new YcRoomManager.OnLeaveRoomListener() {
                    @Override
                    public void onCompleted(boolean success) {
                        if (success) {
                            Log.i(TAG, "退出房间成功");
                        } else {
                            //退出房间失败
                            ToastUtils.showToast(GamePlayActivity.this, "退出房间失败");
                            Log.i(TAG, "退出房间失败");

                        }

                        //清空好友关系缓存
                        YcFriendManager.getInstance().clearFriendship();
                        GamePlayActivity.this.finish();
                    }
                });

            }
        });
    }


    @Override
    public void onBackPressed() {

        Log.i(TAG, "点击了返回按钮");
        if (MgsSdkBridgeHelper.getInstance().isSdkInitialized()) {
            Log.i(TAG, "点击了返回按钮，进入mgs=---》");
            //调用显示游戏退出确认框
            MgsSdkBridgeHelper.getInstance().showExitGameDialog();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();


        //游戏退出完成，请销毁SDK
        MgsSdkBridgeHelper.getInstance().destroyMgsSdk();
        Log.i(TAG, "game destroy");
    }
}