package com.meta.game.demo.yc233.data.http;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.gson.Gson;
import com.meta.game.demo.yc233.config.GameConfigHelper;
import com.meta.game.demo.yc233.data.YcUserManager;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class OkHttpUtils {

    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static final MediaType APPLICATION_JSON = MediaType.parse("application/json; charset=utf-8");
    private static final Gson GSON = new Gson();

    private static OkHttpUtils sInstance;

    private final OkHttpClient okHttpClient;

    private OkHttpUtils() {
        okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .writeTimeout(5, TimeUnit.SECONDS)
                .build();
    }

    public static OkHttpUtils getInstance() {
        if (sInstance == null) {
            sInstance = new OkHttpUtils();
        }
        return sInstance;
    }


    /**
     * post请求
     * @param url
     * @param params
     * @param callback
     */
    public <T> void postJson(String url, Map<String, Object> params, ResponseCallback<T> callback) {

        String jsonParams = GSON.toJson(params);
        Log.i("http-request", String.format("request url : %s \n request params : %s", url, jsonParams));
        RequestBody requestBody = RequestBody.create(APPLICATION_JSON, jsonParams);
        Request request = new Request.Builder()
                .url(url)
                .addHeader("gameToken", YcUserManager.getInstance().getToken())
                .addHeader("appKey",  GameConfigHelper.getInstance().getAppKey())
                .post(requestBody)
                .build();

        okHttpClient.newCall(request)
                .enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        MAIN_HANDLER.post(new Runnable() {
                            @Override
                            public void run() {
                                sendFailCallback(e);
                            }
                        });
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        String jsonString = response.body().string();
                        MAIN_HANDLER.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null) {
                                     //回调成功
                                    callback.parseResponse(jsonString);
                                }
                            }
                        });
                    }

                    private void sendFailCallback(Exception e) {
                        MAIN_HANDLER.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null) {
                                    callback.onFailure(e.getMessage());
                                }
                            }
                        });
                    }
                });
    }

}
