package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;

import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.constants.GameConstants;

/**
 * 场景选择界面
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/04
 */
public class GameSceneChooseView extends BaseView implements View.OnClickListener {

    private OnChooseSceneListener listener;

    public GameSceneChooseView(@NonNull Context context) {
        super(context, R.layout.game_scene_choose_view);
    }

    @Override
    protected void init(Context context) {
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                removeFromParent();
            }
        });

        findViewById(R.id.btn_cancel).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                removeFromParent();
            }
        });

        findViewById(R.id.tv_mode_room_8).setOnClickListener(this);
        findViewById(R.id.tv_mode_5v5).setOnClickListener(this);
        findViewById(R.id.tv_mode_dmm).setOnClickListener(this);

    }

    public void setOnChooseModeListener(OnChooseSceneListener listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_mode_room_8:
                callback(GameConstants.GAME_MODE_1V7);
                break;
            case R.id.tv_mode_5v5:
                callback(GameConstants.GAME_MODE_5V5);
                break;
            case R.id.tv_mode_dmm:
                callback(GameConstants.GAME_MODE_DMM);
                break;
            default:
                break;
        }

        removeFromParent();
    }

    private void callback(int mode){
        if (listener != null) {
            listener.onGameSceneClick(mode);
        }
    }

    interface OnChooseSceneListener {
        /**
         * 场景选择回调
         * @param mode
         */
        void onGameSceneClick(int mode);
    }
}
