package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.meta.game.demo.yc233.bean.RoomPlayerListResp;
import com.meta.game.demo.yc233.bean.TeamPlayerListResp;
import com.meta.game.demo.yc233.config.GameConfigHelper;
import com.meta.game.demo.yc233.constants.GameConstants;
import com.meta.game.demo.yc233.data.ApiResponse;
import com.meta.game.demo.yc233.data.YcFriendManager;
import com.meta.game.demo.yc233.data.websocket.WebSocketManager;
import com.meta.game.demo.yc233.utils.JsonUtils;
import com.meta.game.demo.yc233.utils.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import static com.meta.game.demo.yc233.constants.GameConstants.GAME_STATE_END;
import static com.meta.game.demo.yc233.constants.GameConstants.GAME_STATE_PREPARE;
import static com.meta.game.demo.yc233.constants.GameConstants.GAME_STATE_PROGRESSING;

/**
 * 游戏场景逻辑处理
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/12
 */
public class GameSceneDelegate {
    private static final String TAG = "GameSceneDelegate";
    private static final String KEY_ACTION = "action";
    private static final String KEY_REQUEST_CODE = "requestCode";
    private static final String KEY_RESPONSE = "response";
    private static final String KEY_PARAM = "param";
    /**
     * 查询房间的状态
     */
    private static final String ACTION_QUERY_ROOM = "queryRoom";
    /**
     * team查询
     */
    private static final String ACTION_QUERY_TEAM = "queryTeam";
    private static final String ACTION_SYNC_ROOM = "syncRoom";
    private static final String ACTION_SWITCH_TEAM = "switchTeam";

    private static final String ACTION_BATCH_CHECK_FRIEND = "batchCheckFriend";

    /**
     * 同步房间状态状态
     */
    private static final String ACTION_SYNC_STATE = "syncState";
    private static final String ACTION_RANDOM_JOIN_TEAM = "randomJoinTeam";
    private static final String ACTION_UPDATE_ROOM_NAME = "updateRoomName";
    private static final String ACTION_CONNECTION_NOT_ALLOWED = "connectionNotAllowed";

    private GameSceneView gameSceneView;

    /**
     * 房间id
     */
    private String roomId;

    public GameSceneDelegate(GameSceneView gameSceneView) {
        this.gameSceneView = gameSceneView;
    }

    /**
     * 开启socket长连接
     * @param roomId
     */
    public void startSocketConnection(String roomId) {
        if (TextUtils.isEmpty(roomId)) {
            ToastUtils.showToast(getContext(), "roomId不能为空");
            return;
        }

        this.roomId = roomId;
        String webSocketUrl = GameConfigHelper.getInstance().getWsUrl() + "/connectServer/" + roomId;

        WebSocketManager.getInstance().startSocketConnection(webSocketUrl,
                new WebSocketManager.WsListener() {
                    @Override
                    public void onWsConnected() {
                        Log.i(TAG,"==onWsConnected==");
                    }

                    @Override
                    public void onWsMessage(String message) {

                        try {
                            JSONObject jsonObject = new JSONObject(message);
                            String action = JsonUtils.getString(jsonObject, KEY_ACTION);
                            int requestCode = JsonUtils.getInt(jsonObject, KEY_REQUEST_CODE, -1);
                            String response = JsonUtils.getString(jsonObject, KEY_RESPONSE);

                            if (ACTION_QUERY_ROOM.equals(action)) {
                                //查询房间状态的动作响应
                                doRefreshRoomPlayers(response);
                            } else if (ACTION_SYNC_ROOM.equals(action)) {
                                //房主同步房间状态的动作响应
                                doSyncRoomResp(response);
                            } else if (ACTION_SYNC_STATE.equals(action)) {
                                //其他成员接收到同步房间状态的动作响应
                                doSyncGameStateResp(response);
                            } else if (ACTION_UPDATE_ROOM_NAME.equals(action)) {
                                doChangeRoomNameResp(response);
                            } else if (ACTION_QUERY_TEAM.equals(action)) {
                                //查询玩家信息
                                doRefreshTeamPlayers(response);
                            } else if (ACTION_RANDOM_JOIN_TEAM.equals(action) && requestCode == -1) {
                                doRandJoinTeamResp(response);
                            } else if (ACTION_BATCH_CHECK_FRIEND.equals(action)) {
                                //批量检测好友
                                doBatchCheckFriend(response);
                            } else if (ACTION_SWITCH_TEAM.equals(action)) {
                                doSwitchTeamResp(response);
                            } else if (ACTION_CONNECTION_NOT_ALLOWED.equals(action)) {
                                //连接不被允许,可能房间被销毁了
                                doConnectionNotAllowedResp(response);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onWsClosed(int code, String reason) {
                        Log.i(TAG,"==onWsDisconnected==");
                    }

                    @Override
                    public void onWsDisconnected() {
                        Log.i(TAG,"==onWsDisconnected==");
                    }
                });
    }



    private Context getContext(){
        return gameSceneView.getContext();
    }


    /**
     * 同步MGS修改房间房间名到服务端
     * @param roomIdFromCp
     * @param roomName
     */
    private void syncChangeRoomNameToServer(String roomIdFromCp, String roomName){
        //同步MGS的房间名称至游戏服务端
        try{
            //参数
            JSONObject paramsJson = new JSONObject();
            paramsJson.put("roomId", roomId);
            paramsJson.put("roomName", roomName);

            sendWsAction("updateRoomName", paramsJson);
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * 房间过期或者不允许连接操作时，需要离开房间操作
     * @param resp
     */
    private void doConnectionNotAllowedResp(String resp) {
        //连接断开
        WebSocketManager.getInstance().disconnect();
        ApiResponse apiResponse = new Gson().fromJson(resp, ApiResponse.class);
        if (gameSceneView != null) {
            gameSceneView.leaveRoomIfNeeded(apiResponse.message);
        }
    }

    private void doSwitchTeamResp(String resp) {
        ApiResponse apiResponse = new Gson().fromJson(resp, ApiResponse.class);
        if (apiResponse.isSuccess()) {
            gameSceneView.switchTeamSuccess();
        } else {
            ToastUtils.showToast(getContext(), apiResponse.message);
        }
    }


    /**
     * 同步MGS修改房间房间名到服务端服务端响应
     * @param response
     */
    private void doChangeRoomNameResp(String response) {
        Type type = new TypeToken<ApiResponse<Boolean>>(){}.getType();
        ApiResponse<Boolean> result = new Gson().fromJson(response, type);
        if (result.isSuccess() && result.data) {
            ToastUtils.showToast(getContext(), "名称修改同步成功!");
        } else {
            ToastUtils.showToast(getContext(), "名称修改同步失败");
        }
    }

    private void doBatchCheckFriend(String resp) {
        Type type = new TypeToken<ApiResponse<Map<String,Boolean>>>(){}.getType();
        ApiResponse<Map<String,Boolean>> apiResponse = new Gson().fromJson(resp, type);

        if (apiResponse.isSuccess()) {
            Map<String, Boolean> data = apiResponse.data;
            YcFriendManager.getInstance().putFriendship(data);
            gameSceneView.refreshPlayerAdapters();

        } else {
            Log.e(TAG,"批量检测好友关系失败");
        }

    }


    /**
     * 刷新room玩家列表
     * @param playerListResp
     */
    private void doRefreshRoomPlayers(String playerListResp) {
        Type type = new TypeToken<ApiResponse<RoomPlayerListResp>>(){}.getType();
        ApiResponse<RoomPlayerListResp> playerResponse = new Gson().fromJson(playerListResp, type);
        if (playerResponse.isSuccess()) {
            gameSceneView.refreshRoomInfo(playerResponse.data);
        } else {
            ToastUtils.showToast(getContext(),playerResponse.message);
        }

    }

    /**
     * 刷新team玩家列表
     * @param playerListResp
     */
    private void doRefreshTeamPlayers(String playerListResp) {
        Type type = new TypeToken<ApiResponse<List<TeamPlayerListResp>>>(){}.getType();
        ApiResponse<List<TeamPlayerListResp>> playerResponse = new Gson().fromJson(playerListResp, type);

        if (playerResponse.isSuccess()) {
            gameSceneView.refreshTeamView(playerResponse.data);
        } else {
            ToastUtils.showToast(getContext(),playerResponse.message);
        }

    }

    /**
     * 房间状态动作响应 -  房主会收到
     * @param syncRoomResp
     */
    private void doSyncRoomResp(String syncRoomResp) {

        Type type = new TypeToken<ApiResponse<Boolean>>(){}.getType();
        ApiResponse<Boolean> apiResponse = new Gson().fromJson(syncRoomResp, type);
        Log.i(TAG,"房主：doSyncRoomResp = " + syncRoomResp);
        if (!apiResponse.isSuccess()) {
            ToastUtils.showToast(getContext(), apiResponse.message);
            return;
        }

        //游戏界面开始-结束交给 doSyncGameStateResp处理了
    }

    /**
     * 同步游戏状态
     * @param resp
     */
    private void doSyncGameStateResp(String resp) {
        Type type = new TypeToken<ApiResponse<Integer>>(){}.getType();
        ApiResponse<Integer> apiResponse = new Gson().fromJson(resp, type);
        Log.i(TAG,"房间内所有成员: doSyncGameStateResp= " + resp);

        if (apiResponse.isSuccess()) {
            switch (apiResponse.data) {
                case GAME_STATE_PREPARE:

                    break;
                case GAME_STATE_PROGRESSING:
                    gameSceneView.showStartBattleUI();
                    break;
                case GAME_STATE_END:
                    gameSceneView.showEndBattleUI();
                    break;
                default:
                    break;
            }

        }
    }

    /**
     * 游戏准备中
     */
    public void sendPrepareGameAction() {
        syncRoomState(GameConstants.GAME_STATE_PREPARE);
    }

    /**
     * 开始游戏
     */
    public void sendStartGameAction() {
        syncRoomState(GameConstants.GAME_STATE_PROGRESSING);
    }

    /**
     * 游戏结束
     */
    public void sendEndGameAction() {
        syncRoomState(GAME_STATE_END);
    }


    /**
     * 同步房间状态
     * @param gameState 0准备中, 1游戏中, 2游戏结束
     */
    private void syncRoomState(int gameState) {

        try{
            //参数
            JSONObject paramsJson = new JSONObject();
            paramsJson.put("roomId", roomId);
            paramsJson.put("state", gameState);
            sendWsAction("syncRoom",gameState, paramsJson);

        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void doRandJoinTeamResp(String response) {

        Type type = new TypeToken<ApiResponse<Map<String,String>>>(){}.getType();
        ApiResponse<Map<String,String>> apiResponse = new Gson().fromJson(response, type);
        if (apiResponse.isSuccess()) {
            gameSceneView.doArrangedTeam(apiResponse.data);
        }
    }

    /**
     * 切换队伍的action
     */
    public void sendSwitchTeamAction(String teamId) {
        try{
            //action json
            JSONObject actionJson = new JSONObject();
            actionJson.put(KEY_ACTION, ACTION_SWITCH_TEAM);
            actionJson.put(KEY_REQUEST_CODE, 101);
            actionJson.put(KEY_PARAM, teamId);

            WebSocketManager.getInstance().sendMessage(actionJson.toString());

        }catch (JSONException e) {
            e.printStackTrace();
        }
    }


    /**
     * 向server端发送指令
     * @param action
     * @param params
     */
    private void sendWsAction(String action, JSONObject params) {
        sendWsAction(action, -1, params);
    }


    /**
     * 向websocket server端发送指令
     * @param action  动作
     * @param requestCode 请求码
     * @param params 参数
     */
    private void sendWsAction(String action, int requestCode, JSONObject params) {
        try{
            //action json
            JSONObject actionJson = new JSONObject();
            actionJson.put(KEY_ACTION, action);
            actionJson.put(KEY_REQUEST_CODE, requestCode);
            actionJson.put(KEY_PARAM, params);

            WebSocketManager.getInstance().sendMessage(actionJson.toString());

        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
