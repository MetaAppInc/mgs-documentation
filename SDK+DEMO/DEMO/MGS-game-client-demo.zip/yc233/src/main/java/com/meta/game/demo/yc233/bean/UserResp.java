package com.meta.game.demo.yc233.bean;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class UserResp {
    public UserInfo userInfo;
    public TokenInfo tokenInfo;

    @Override
    public String toString() {
        return "UserResp{" +
                "userInfo=" + userInfo +
                ", tokenInfo=" + tokenInfo +
                '}';
    }
}
