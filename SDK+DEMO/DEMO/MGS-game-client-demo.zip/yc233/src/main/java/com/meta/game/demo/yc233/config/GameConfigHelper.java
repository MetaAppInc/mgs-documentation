package com.meta.game.demo.yc233.config;

import android.content.Context;
import android.util.Log;

import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/19
 */
public class GameConfigHelper implements IGameEnvConfig {
    private static final String                       TAG     = "GameConfigHelper";
    private static final int ENV_DEV = 0;
    private static final int ENV_PRE = 1;
    private static final int ENV_ONLINE = 2;
    private static final Map<Integer, String> ENV_MAP = new HashMap<Integer, String>(){
        {
            put(ENV_DEV, "开发环境");
            put(ENV_PRE, "预发环境");
            put(ENV_ONLINE, "线上环境");
        }
    };

    private static GameConfigHelper sInstance;

    private Context appContext;
    private IGameEnvConfig config;

    /**
     * 当前环境的code
     */
    private int currentEnvCode = 2;


    public static GameConfigHelper getInstance() {
        if (sInstance == null) {
            sInstance = new GameConfigHelper();
        }
        return sInstance;
    }

    /**
     *
     * @return
     */
    public String getCurrentEnvName() {
        return ENV_MAP.get(currentEnvCode);
    }

    /**
     * 环境初始化
     * @param context
     */
    public void initConfig(Context context) {
        appContext = context.getApplicationContext();

        //获取233乐园的环境
        currentEnvCode = MgsSdkBridgeHelper.getInstance().getCurrentEnvironment(appContext);

        switch (currentEnvCode) {
            case ENV_DEV:
                config = new GameDevelopEnv();
                break;
            case ENV_PRE:
                config = new GamePreEnv();
                break;
            case ENV_ONLINE:
            default:
                config = new GameOnlineConfig();
                break;
        }

        Log.i(TAG, "当前乐园的环境:" + currentEnvCode);
    }

    private IGameEnvConfig getGameEnvConfig(){
        if(config == null) {
            config = new GameOnlineConfig();
        }
        return config;
    }

    @Override
    public String getAppKey() {
        return getGameEnvConfig().getAppKey();
    }

    @Override
    public String getBaseUrl() {
        return getGameEnvConfig().getBaseUrl();
    }

    @Override
    public String getWsUrl() {
        return getGameEnvConfig().getWsUrl();
    }
}
