package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.bean.UserInfo;
import com.meta.game.demo.yc233.data.ApiResponse;
import com.meta.game.demo.yc233.data.ApiService;
import com.meta.game.demo.yc233.data.YcFriendManager;
import com.meta.game.demo.yc233.data.YcRoomManager;
import com.meta.game.demo.yc233.data.YcUserManager;
import com.meta.game.demo.yc233.data.http.ResponseCallback;
import com.meta.game.demo.yc233.event.AddFriendEvent;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.utils.YcCommonUtils;
import com.meta.game.demo.yc233.widget.StrokeTextView;

import org.greenrobot.eventbus.EventBus;

import java.util.Map;

import jp.wasabeef.glide.transformations.MaskTransformation;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/03
 */
public class PlayerView extends LinearLayout {

    private static final String TAG = "PlayerView";
    private UserInfo userInfo;

    private ImageView      avatarView;
    private StrokeTextView nameTextView;
    private ImageView      userStateView;
    private TextView       btnAddFriend;

    public PlayerView(Context context) {
        this(context, null);
    }

    public PlayerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        inflate(context, R.layout.player_view, this);
        avatarView = findViewById(R.id.iv_player_avatar);
        nameTextView = findViewById(R.id.tv_player_name);
        userStateView = findViewById(R.id.tv_player_state);
        btnAddFriend = findViewById(R.id.btn_player_add_friends);
        this.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if (userInfo != null) {
                    //检测是不是自己
                    if (!isPlayerSelf(userInfo)) {
                        //查看233玩家资料卡
                        MgsSdkBridgeHelper.getInstance()
                                .showPlayerProfile(userInfo.openId);
                    } else {
                        ToastUtils.showToast(getContext(), "点击自己的头像了");
                    }
                } else {
                    //邀请好友，调起悬浮球
                    MgsSdkBridgeHelper.getInstance().showFloatingLayer(1);
                }
            }
        });
        //添加好友监听
        btnAddFriend.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //检测点击的玩家和自己是否好友关系
                MgsSdkBridgeHelper.getInstance().isFriendShip(userInfo.openId,
                        new MgsFeatureListener() {
                            @Override
                            public void onSuccess(int requestCode, String resultJson) {

                                Log.i(TAG, "查看是否好友关系成功:" + resultJson);
                                boolean result = Boolean.parseBoolean(resultJson);
                                if (!result) {
                                    ToastUtils.showToast(getContext(), "已发送好友申请");
                                    //不是好友关系则调用添加好友接口
                                    addFriend(userInfo.openId);
                                } else {
                                    ToastUtils.showToast(getContext(), "已经互为好友");
                                }
                            }

                            @Override
                            public void onFail(int requestCode, int code, String message) {
                                Log.i(TAG, "查看是否好友关系失败:" + message);
                            }
                        });
            }
        });
    }

    /**
     * 添加好友
     * @param openId
     */
    private void addFriend(String openId) {
        //MGS添加好友接口
        MgsSdkBridgeHelper.getInstance().addFriend(openId, new MgsFeatureListener() {
            @Override
            public void onSuccess(int requestCode, String resultJson) {
                Log.i(TAG, "添加好友成功：" + resultJson);
                //游戏服务器检测好友关系
                ApiService.checkBatchFriendship(YcRoomManager.getInstance().getRoomInfo().roomId,
                        new ResponseCallback<ApiResponse<Map<String,Boolean>>>() {
                            @Override
                            public void onSuccess(ApiResponse<Map<String,Boolean>> response) {
                                Log.i(TAG, "批量检查好友关系请求完成=="+response);
                                if (response.isSuccess()) {
                                    YcFriendManager.getInstance().putFriendship(response.data);
                                    EventBus.getDefault().post(new AddFriendEvent());
                                }

                            }

                            @Override
                            public void onFailure(String error) {
                                Log.i(TAG, "批量检查好友关系请求失败==");
                            }
                        });
            }

            @Override
            public void onFail(int requestCode, int code, String message) {
                ToastUtils.showToast(getContext(), "添加好友失败=" + message);
                Log.i(TAG, "添加好友失败:" + message);
            }
        });
    }

    /**
     * 是否是玩家自己
     * @return
     */
    private boolean isPlayerSelf(UserInfo userInfo) {
        UserInfo cacheUser = YcUserManager.getInstance().getUserInfo();
        return cacheUser != null && cacheUser.openId.equals(userInfo.openId);
    }

    /**
     * 设置玩家信息
     * @param userInfo
     */
    public void setUserInfo(UserInfo userInfo,String roomOwner, int preparedIconRes){
        this.userInfo = userInfo;
        String avatar = "";
        String nickName = "";
        int iconRes = R.drawable.icon_player_prepared_green;
        if (userInfo != null) {
            Log.i(TAG,"setUserInfo openId="+ userInfo.openId +",roomOwner==" + roomOwner);

            avatar = userInfo.avatar;
            nickName = userInfo.nickname;

            if (userInfo.openId.equals(roomOwner)) {
                iconRes = R.drawable.icon_player_avatar_owner;
            } else {
                iconRes = preparedIconRes;
            }

            //自己或者好友不显示加好友按钮
            if (isPlayerSelf(userInfo)) {
                YcCommonUtils.setViewVisible(btnAddFriend, false);
            } else {
                boolean isVisible = !YcFriendManager.getInstance().isMyFriend(userInfo.openId);
                //是否是自身，自身不需要显示按钮
                YcCommonUtils.setViewVisible(btnAddFriend, isVisible);
            }
            YcCommonUtils.setViewVisible(userStateView, true);
        } else {
            YcCommonUtils.setViewVisible(btnAddFriend, false);
            YcCommonUtils.setViewVisible(userStateView, false);
        }


        MaskTransformation maskTransformation = new MaskTransformation(R.drawable.icon_player_avatar_top);
        RequestOptions requestOptions = RequestOptions
                .bitmapTransform(maskTransformation)
                .placeholder(R.drawable.icon_player_avatar_top);

        Glide.with(this)
                .load(avatar)
                .apply(requestOptions)
                .into(avatarView);
        nameTextView.setText(nickName);
        userStateView.setBackgroundResource(iconRes);

    }
}
