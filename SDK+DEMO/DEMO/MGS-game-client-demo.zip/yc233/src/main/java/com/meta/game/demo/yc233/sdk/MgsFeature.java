package com.meta.game.demo.yc233.sdk;

/**
 * MGS 接口功能常量类
 *
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/02
 */
public final class MgsFeature {
    /**
     * 登录
     */
    static final String FEATURE_LOGIN = "login";

    /**
     * 创建并加入房间
     */
    static final String FEATURE_CREATE_AND_JOIN_ROOM = "createAndJoinRoom";
    /**
     * 加入房间
     */
    static final String FEATURE_JOIN_ROOM            = "joinRoom";
    /**
     * 离开房间
     */
    static final String FEATURE_LEAVE_ROOM  = "leaveRoom";

    /**
     * 加入team
     */
    static final String FEATURE_JOIN_TEAM  = "joinTeam";
    /**
     * 离开team
     */
    static final String FEATURE_LEAVE_TEAM  = "leaveTeam";

    /**
     * 显示玩家资料卡
     */
    static final String FEATURE_USER_PROFILE  = "showUserProfile";

    /**
     * 查询玩家进入游戏时在233所选的动作
     */
    static final String FEATURE_QUERY_PLAYER_ACTION  = "queryPlayerAction";

    /**
     * 是否好友关系
     */
    static final String FEATURE_IS_FRIENDSHIP  = "isFriendShip";

    /**
     * 添加好友
     */
    static final String FEATURE_ADD_FRIEND  = "addFriend";
}
