package com.meta.game.demo.yc233.config;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/28
 */
public class GamePreEnv implements IGameEnvConfig{
    @Override
    public String getAppKey() {
        return "开发者平台申请的appkey";
    }

    @Override
    public String getBaseUrl() {
        return "http://pre-game.mgsapi.net";
    }

    @Override
    public String getWsUrl() {
        return "ws://pre-game.mgsapi.net";
    }
}
