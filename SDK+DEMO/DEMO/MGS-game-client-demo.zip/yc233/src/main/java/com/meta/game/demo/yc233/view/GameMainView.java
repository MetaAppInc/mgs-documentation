package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.meta.android.mgs.MgsApi;
import com.meta.android.mgs.listener.MgsEventListener;
import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.BuildConfig;
import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.bean.RoomResp;
import com.meta.game.demo.yc233.bean.UserInfo;
import com.meta.game.demo.yc233.constants.GameConstants;
import com.meta.game.demo.yc233.data.ApiResponse;
import com.meta.game.demo.yc233.data.ApiService;
import com.meta.game.demo.yc233.data.YcRoomManager;
import com.meta.game.demo.yc233.data.YcUserManager;
import com.meta.game.demo.yc233.data.http.ResponseCallback;
import com.meta.game.demo.yc233.data.websocket.WebSocketManager;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.JsonUtils;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.widget.CustomDialog;
import com.meta.game.demo.yc233.widget.StrokeTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

/**
 * 游戏主界面
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/03
 */
public class GameMainView extends BaseView implements View.OnClickListener {
    private static final String TAG = "GameMainView";
    /**
     * 加入房间
     */
    public static final int ACTION_ROOM_JOIN = 0;
    /**
     * 创建房间
     */
    public static final int ACTION_ROOM_CREATE = 1;
    /**
     * 快速加入房间
     */
    public static final int ACTION_ROOM_QUICK_JOIN = 2;

    private GameSceneChooseView gameSceneChooseView;
    private EditText searchEt;

    public GameMainView(@NonNull Context context) {
        super(context, R.layout.game_main);
    }

    @Override
    protected void init(Context context){

        LinearLayout playerProfileLayout = findViewById(R.id.ll_player_profile);
        playerProfileLayout.setOnClickListener(this);

        ImageView playerAvatarView = findViewById(R.id.iv_player_avatar);
        TextView playerTextView = findViewById(R.id.tv_player_name);

        UserInfo userInfo = YcUserManager.getInstance().getUserInfo();

        if (userInfo != null) {
            Glide.with(this).load(userInfo.avatar).into(playerAvatarView);
            //设置用户昵称
            playerTextView.setText(YcUserManager.getInstance().getUserInfo().nickname);
        }

        StrokeTextView searchBtn = findViewById(R.id.btn_search_room);
        StrokeTextView quickStart = findViewById(R.id.btn_quick_start);
        StrokeTextView createRoomBtn = findViewById(R.id.btn_create_room);
        searchEt = findViewById(R.id.et_search_room_number);

        quickStart.setOnClickListener(this);
        createRoomBtn.setOnClickListener(this);
        searchBtn.setOnClickListener(this);

        requestPlayerAction();
        registerMgsEvent();
    }

    /**
     * 注册监听mgs
     */
    private void registerMgsEvent() {
        //注册监听MGS房间销毁事件
        MgsApi.getInstance().registerMgsEventListener("destroyRoomEvent", new MgsEventListener() {
            @Override
            public void onMgsEventHandle(String jsonData) {
                Log.i(TAG, "destroyRoomEvent=" + jsonData);
                CustomDialog alertDialog = new CustomDialog.Builder(getContext())
                        .setMessage("您所在的房间已销毁")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //房间销毁后的操作
                                YcRoomManager.getInstance().leaveRoom(new YcRoomManager.OnLeaveRoomListener() {
                                    @Override
                                    public void onCompleted(boolean success) {
                                        if (success) {
                                            WebSocketManager.getInstance().disconnect();
                                        }
                                    }
                                });
                                if (dialog != null) {
                                    dialog.dismiss();
                                }
                            }
                        }).create();
                alertDialog.setCancelable(false);
                alertDialog.show();
            }
        });
    }

    /**
     * 检测玩家进入游戏时所选的操作，可在登录后进行操作
     */
    private void requestPlayerAction(){
        Log.i(TAG, "开始调用queryPlayerAction接口");
        showProgress();
        //检测玩家进入游戏时所选的操作，可在登录后进行操作
        MgsSdkBridgeHelper.getInstance()
                .queryPlayerAction(new MgsFeatureListener() {
                    @Override
                    public void onSuccess(int requestCode, String resultJson) {

                        dismissProgress();
                        // resultJson 返回值{"action":0,"mgsCpRead":false, "roomIdFromCp":"716","inviteOpenId":"123"}// action: -1: 没有任何操作 0: 加入房间， 1: 创建房间  2: 快速加入房间
                        Log.i(TAG, "Mgs queryPlayerAction callback :" + resultJson);

                        try {
                            JSONObject resultJsonObject = JsonUtils.createJsonObject(resultJson);

                            int action = JsonUtils.getInt(resultJsonObject, "action", -1);
                            String roomIdFromCp = JsonUtils.getString(resultJsonObject, "roomIdFromCp");
                            boolean mgsCpRead = JsonUtils.getBoolean(resultJsonObject, "mgsCpRead");
                            String inviteOpenId = JsonUtils.getString(resultJsonObject, "inviteOpenId");

                            switch (action) {
                                case ACTION_ROOM_JOIN:
                                    //加入房间
                                    requestJoinRoom(roomIdFromCp, 0);
                                    break;
                                case ACTION_ROOM_CREATE:
                                    //创建房间
                                    showChooseModeView(R.id.btn_create_room);
                                    break;
                                case ACTION_ROOM_QUICK_JOIN:
                                    //快速加入房间
                                    onQuickStartGame();
                                    break;
                                default:
                                    break;
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onFail(int requestCode, int code, String message) {
                        Log.e(TAG, "query player action error:" + message);
                        dismissProgress();
                    }
                });
    }



    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.ll_player_profile:
                onPlayerProfileClick();
                break;
            case R.id.btn_search_room:
                onSearchRoomClickListener();
                break;
            default:
                showChooseModeView(id);
                break;
        }
    }

    /**
     * 显示mgs的悬浮层
     */
    private void showFloatingLayer() {
        //聊天: 0, 好友: 1
        int tab = 1;
        //显示悬浮窗口
        MgsSdkBridgeHelper.getInstance().showFloatingLayer(tab);
    }

    /**
     * 房间搜索监听事件
     */
    public void onSearchRoomClickListener() {

        String roomNumber = searchEt.getText().toString();
        if (TextUtils.isEmpty(roomNumber)) {
            ToastUtils.showToast(getContext(), "房间号不能为空");
            return;
        }

        //调用MGS的房间号查找接口
        MgsSdkBridgeHelper.getInstance()
                .getCpRoomIdByRoomShowNum(roomNumber,new MgsFeatureListener(){
                    @Override
                    public void onSuccess(int requestCode, String resultJson) {
                        Log.i(TAG, "获取roomIdFromCp成功-成功->" + resultJson);

                        try {
                            JSONObject resultJsonObject  = JsonUtils.createJsonObject(resultJson);
                            String roomIdFromCp = JsonUtils.getString(resultJsonObject, "roomIdFromCp");

                            if (TextUtils.isEmpty(roomIdFromCp)) {
                                ToastUtils.showToast(getContext(), "未找到房间");
                                return;
                            }
                            //请求加入房间
                            requestJoinRoom(roomIdFromCp, 0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFail(int requestCode, int code, String message) {
                        ToastUtils.showToast(getContext(), "未找到房间" + message);
                        dismissProgress();
                    }
                });



    }

    /**
     * 游戏场景选择
     * @param btnId
     */
    private void showChooseModeView(int btnId){
        if (gameSceneChooseView == null) {
            gameSceneChooseView = new GameSceneChooseView(getContext());
        }
        gameSceneChooseView.setOnChooseModeListener(new GameSceneChooseView.OnChooseSceneListener() {
            @Override
            public void onGameSceneClick(int mode) {
                if (btnId == R.id.btn_quick_start) {
                    requestJoinRoom("", mode);
                } else if (btnId == R.id.btn_create_room) {
                    onCreateRoom(mode);
                }
            }
        });

        if (gameSceneChooseView.getParent() != null) {
            removeView(gameSceneChooseView);
        }
        addView(gameSceneChooseView);
    }

    /**
     * 头像被点击响应
     */
    private void onPlayerProfileClick() {
        //用户头像信息查看
        MgsSdkBridgeHelper.getInstance().showPlayerProfile(
                YcUserManager.getInstance().getUserInfo().openId);
    }


    private void onQuickStartGame(){
        showChooseModeView(R.id.btn_quick_start);
    }

    /**
     * 跳转到游戏场景
     */
    private void jumpToGameScene(RoomResp room, String mgsResultJson){

        Log.i(TAG, "roomResp="+room);
        if (TextUtils.isEmpty(mgsResultJson)) {
            ToastUtils.showToast(getContext(), "MGS返回房间信息为空,MGS可能未创建或无法加入");
            return;
        }

        //解析返回的json
        Map<String, Object> result = new Gson().fromJson(mgsResultJson,
                new TypeToken<Map<String, Object>>() {}.getType());

        String roomShowNumber = "";
        if (result != null && result.containsKey("roomShowNum")) {
            roomShowNumber = (String)result.get("roomShowNum");
        }

        //获取房间类型
        int roomType = room.roomInfo.roomType;

        //创建游戏场景
        GameSceneView gameSceneView;
        switch (roomType) {
            case GameConstants.GAME_MODE_DMM:
                //躲猫猫类型模式
                gameSceneView = new GameSceneDmmView(getContext());
                break;
            case GameConstants.GAME_MODE_5V5:
                //5v5类型模式
                gameSceneView = new GameScene5v5View(getContext());
                break;
            default:
                gameSceneView = new GameSceneView(getContext());
                break;
        }

        gameSceneView.setRoomInfo(room, room.roomInfo, roomShowNumber);
        addView(gameSceneView);

    }

    /**
     * 自定义埋点日志上报-示例
     */
    private void reportCreateRoomLog() {

        try {
            //日志上报 - 数据埋点的参数
            JSONObject eventObject = new JSONObject();
            eventObject.put("gamepkg", BuildConfig.APPLICATION_ID);
            eventObject.put("battle_mode", "battle_internal");
            eventObject.put("map", "map_test");
            eventObject.put("open_type", "create_room_enter");
            String eventData = eventObject.toString();

            //上报接口
            MgsSdkBridgeHelper.getInstance().reportLogInfo("event_mgs_game_battle_room_create",
                    "创建房间", eventData);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    /**
     * 创建房间
     * @param gameMode 房间类型 1v1 1v7这种形式
     */
    private void onCreateRoom(int gameMode){
        requestCreateRoom(gameMode);
    }

    /**
     * 请求服务器要创建房间
     * @param gameMode 房间类型
     */
    private void requestCreateRoom(int gameMode) {
        showProgress();

        //创建房间
        ApiService.createRoom(gameMode, new ResponseCallback<ApiResponse<RoomResp>>() {
            @Override
            public void onSuccess(ApiResponse<RoomResp> response) {
                //创建成功后跳转到房间页面
                Log.i(TAG, "create-room-" + response);
                //日志上报
                reportCreateRoomLog();

                if (response.isSuccess() ) {
                    onRoomOperateSuccess(response.data);
                } else {
                    //请求失败
                    onFailure(response.message);
                }

            }

            @Override
            public void onFailure(String error) {
                onRoomOperateFail(error);
            }
        });
    }

    /**
     * 处理房间操作成功
     * @param roomResp
     */
    private void onRoomOperateSuccess(RoomResp roomResp) {
        //加入到房间
         joinMgsRoom(roomResp, 0);
         dismissProgress();
    }

    /**
     * 处理房间操作失败
     * @param error
     */
    private void onRoomOperateFail(String error) {
        ToastUtils.showToast(getContext(), "操作失败," + error);
        dismissProgress();
    }

    /**
     * 加入mgs的房间
      * @param type 0:是通过创建房间加入  1：是加入房间加入的
     */
    private void joinMgsRoom(RoomResp roomResp, int type) {
        //服务端已经创建好房间，客户端直接加入即可
        MgsSdkBridgeHelper.getInstance()
                .joinRoom(roomResp.roomInfo.roomId, new MgsFeatureListener(){
                    @Override
                    public void onSuccess(int requestCode, String resultJson) {
                        Log.i(TAG, "同步- mgs - room-成功->" + resultJson);

                        dismissProgress();
                        //同步成功后，跳转到对应的游戏房间
                        jumpToGameScene(roomResp, resultJson);
                    }

                    @Override
                    public void onFail(int requestCode, int code, String message) {
                        Log.i(TAG, "同步- mgs - room-失败->" + message);
                        ToastUtils.showToast(getContext(), "加入房间失败," + message);
                        dismissProgress();
                    }
                });
    }


    /**
     * 向服务端请求加入房间
     * @param roomId 房间号
     * @param roomType 房间类型
     */
    public void requestJoinRoom(String roomId, int roomType) {
        Log.i(TAG, "调用加入房间-》" + roomId);
        showProgress();
        ApiService.joinRoom(roomId, roomType, new ResponseCallback<ApiResponse<RoomResp>>() {
            @Override
            public void onSuccess(ApiResponse<RoomResp> response) {
                dismissProgress();
                //加入成功，则跳转到对应的房间中
                Log.i(TAG, "加入房间结果:"+response);
                if (response.isSuccess()) {
                   onRoomOperateSuccess(response.data);
                } else {
                    //请求失败
                    onFailure(response.message);
                }
            }

            @Override
            public void onFailure(String error) {
                dismissProgress();
                Log.e(TAG, "加入房间失败结果:"+error);
                onRoomOperateFail(error);
            }

        });
    }
}
