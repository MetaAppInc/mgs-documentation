package com.meta.game.demo.yc233.sdk;

import android.content.Context;
import android.util.Log;

import com.meta.android.mgs.MgsApi;
import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.android.mgs.listener.MgsInitListener;

import java.util.List;

/**
 * MGS SDK bridge helper
 *
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/02
 */
public class MgsSdkBridgeHelper {

    private static final String TAG = "MgsSdkBridgeHelper";


    private static volatile MgsSdkBridgeHelper sInstance;
    /**
     * sdk初始化标识
     */
    private                 boolean            sdkInitialized = false;

    public static MgsSdkBridgeHelper getInstance() {
        if (sInstance == null) {
            synchronized (MgsSdkBridgeHelper.class) {
                if (sInstance == null) {
                    sInstance = new MgsSdkBridgeHelper();
                }
            }
        }
        return sInstance;
    }

    /**
     *
     * @param context context
     * @param apiKey  233开发者平台分配的apiKey
     * @param listener 初始化回调
     */
    public void initSdk(Context context, String apiKey, final MgsInitListener listener) {
        MgsApi.getInstance().initSdk(context, apiKey, new MgsInitListener() {
            @Override
            public void onSuccess() {
                sdkInitialized = true;
                if (listener != null) {
                    listener.onSuccess();
                }
                Log.i(TAG, "SDK 初始化成功");
            }

            @Override
            public void onFail(int code, String message) {
                sdkInitialized = false;
                Log.e(TAG, "SDK 初始化失败!" + message);
                if (listener != null) {
                    listener.onFail(code, message);
                }

            }
        });
    }

    /**
     * SDK是否初始化完成
     *
     * @return
     */
    public boolean isSdkInitialized() {
        return sdkInitialized;
    }

    /**
     * 233登录接口
     * @param listener
     */
    public void login(MgsFeatureListener listener) {
        //请求码,游戏可根据业务特征来就进行区分是哪次请求,默认可传0
        int requestCode = 1000;
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_LOGIN, requestCode, null, listener);
    }

    /**
     * 查询玩家从233进入游戏时所选的操作(创建/加入房间)
     *
     * @param listener
     */
    public void queryPlayerAction(MgsFeatureListener listener) {
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_QUERY_PLAYER_ACTION, 0, null, listener);
    }

    /**
     * 根据233的房间号来获取游戏方自己的房间号 roomIdFromCp
     * @param roomShowNum 233的房间号
     * @param listener
     */
    public void getCpRoomIdByRoomShowNum(String roomShowNum, MgsFeatureListener listener) {

        ParameterBuilder<Object> parameterBuilder = new ParameterBuilder.Builder<>()
                .put("roomShowNum", roomShowNum)
                .build();
        MgsApi.getInstance().invokeFeature("getCpRoomIdByRoomShowNum", 0,
                parameterBuilder.toJson(), listener);

    }

    /**
     * 创建房间
     *
     * @param cpRoomId  cp的房间号
     * @param roomName  房间名称
     * @param roomLimit 房间成员容量
     * @param roomTags  房间标签
     * @param listener  监听回调
     */
    public void createRoom(String cpRoomId, String roomName, int roomLimit, List<String> roomTags, MgsFeatureListener listener) {

        ParameterBuilder<Object> parameterBuilder = new ParameterBuilder.Builder<>()
                .put("roomIdFromCp", cpRoomId)
                .put("roomName", roomName)
                .put("roomLimit", roomLimit)
                .put("roomTags", roomTags)
                .build();
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_CREATE_AND_JOIN_ROOM, 0,
                parameterBuilder.toJson(), listener);
    }


    /**
     * 加入房间
     *
     * @param cpRoomId cp的房间号
     * @param listener 监听回调
     */
    public void joinRoom(String cpRoomId, MgsFeatureListener listener) {
        ParameterBuilder<String> parameterBuilder = new ParameterBuilder.Builder<String>()
                .put("roomIdFromCp", cpRoomId)
                .build();
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_JOIN_ROOM, 0, parameterBuilder.toJson(), listener);
    }

    /**
     * 离开房间  cp的房间号
     *
     * @param cpRoomId
     * @param listener
     */
    public void leaveRoom(String cpRoomId, MgsFeatureListener listener) {
        ParameterBuilder<String> parameterBuilder = new ParameterBuilder.Builder<String>()
                .put("roomIdFromCp", cpRoomId)
                .build();
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_LEAVE_ROOM, 0,
                parameterBuilder.toJson(), listener);
    }

    /**
     * 加入team
     * @param roomIdFromCp 游戏方队伍的ID
     * @param backRoomIdFromCp  CP的RoomId（离开team要返回到哪个Room，如果为null，则默认返回父ROOM的ID）
     * @param listener listener
     */
    public void joinTeam(String roomIdFromCp, String backRoomIdFromCp, MgsFeatureListener listener) {
        ParameterBuilder<String> parameterBuilder = new ParameterBuilder.Builder<String>()
                .put("roomIdFromCp", roomIdFromCp)
                .put("backRoomIdFromCp", backRoomIdFromCp)
                .build();
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_JOIN_TEAM, 0,
                parameterBuilder.toJson(), listener);
    }


    /**
     * 离开team
     * @param roomIdFromCp 游戏方队伍的ID
     * @param listener
     */
    public void leaveTeam(String roomIdFromCp, MgsFeatureListener listener) {
        ParameterBuilder<String> parameterBuilder = new ParameterBuilder.Builder<String>()
                .put("roomIdFromCp", roomIdFromCp)
                .build();
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_LEAVE_TEAM, 0,
                parameterBuilder.toJson(), listener);
    }

    /**
     * 显示玩家资料卡片
     *
     * @param openId 要查看的玩家openId
     */
    public void showPlayerProfile(String openId) {
        ParameterBuilder<String> parameterBuilder = new ParameterBuilder.Builder<String>()
                .put("openId", openId)
                .build();
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_USER_PROFILE, 0,
                parameterBuilder.toJson(), null);
    }

    /**
     * 判断两个玩家是否是好友
     *
     * @param openId 要查看的玩家openId
     */
    public void isFriendShip(String openId, MgsFeatureListener listener) {
        ParameterBuilder<String> parameterBuilder = new ParameterBuilder.Builder<String>()
                .put("friendOpenId", openId)
                .build();
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_IS_FRIENDSHIP, 0,
                parameterBuilder.toJson(), listener);
    }

    /**
     * 添加好友
     *
     * @param openId 要添加好友的openId
     */
    public void addFriend(String openId, MgsFeatureListener listener) {
        ParameterBuilder<String> parameterBuilder = new ParameterBuilder.Builder<String>()
                .put("friendOpenId", openId)
                .build();
        String params = parameterBuilder.toJson();
        MgsApi.getInstance().invokeFeature(MgsFeature.FEATURE_ADD_FRIEND, 0, params, listener);
    }


    /**
     * 显示悬浮层
     *
     * @param tab      聊天:0 / 好友:1
     */
    public void showFloatingLayer(int tab) {
        ParameterBuilder<Object> parameterBuilder = new ParameterBuilder.Builder<>()
                .put("tab", tab)
                .build();

        MgsApi.getInstance().invokeFeature("showFloatingLayer", 0,
                parameterBuilder.toJson(), null);
    }

    /**
     * 游戏埋点日志上报
     *
     * @param event     埋点事件标识
     * @param eventDesc 埋点事件描述
     * @param data      埋点事件参数数据
     */
    public void reportLogInfo(String event, String eventDesc, String data) {
        MgsApi.getInstance().reportLogInfo(event, eventDesc, data);
    }

    /**
     * 显示退出游戏确认框，需要注册exitGameEvent事件监听
     * <p>
     * 示例代码:
     * MgsApi.getInstance().registerMgsEventListener("exitGameEvent", new MgsEventListener() {
     *
     * @Override public void onMgsEventHandle(String jsonData) {
     * //退出游戏逻辑处理,可以做一些清理游戏相关信息的操作，如清理房间信息等操作
     * }
     * });
     */
    public void showExitGameDialog() {
        Log.i(TAG, "调用显示退出框3》");
        MgsApi.getInstance().invokeFeature("showExitGameDialog",
                0, null, null);
    }

    /**
     * 获取当前233的环境
     * @param context
     * @return 环境标识 0:测试环境 1:预发环境 2:线上环境
     */
    public int getCurrentEnvironment(Context context) {
        return MgsApi.getInstance().getCurrentEnvironment(context);
    }

    /**
     * 销毁MGS SDK
     */
    public void destroyMgsSdk() {
        MgsApi.getInstance().destroySdk();
    }
}
