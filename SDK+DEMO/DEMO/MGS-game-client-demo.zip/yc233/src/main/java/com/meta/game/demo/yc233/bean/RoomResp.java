package com.meta.game.demo.yc233.bean;

import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/18
 */
public class RoomResp {
    public YcRoomInfo     roomInfo;
    public List<TeamInfo> teamInfo;
    public String         currentTeamId = "";

    @Override
    public String toString() {
        return "RoomResp{" +
                "roomInfo=" + roomInfo +
                ", teamInfo=" + teamInfo +
                ", currentTeamId='" + currentTeamId + '\'' +
                '}';
    }
}
