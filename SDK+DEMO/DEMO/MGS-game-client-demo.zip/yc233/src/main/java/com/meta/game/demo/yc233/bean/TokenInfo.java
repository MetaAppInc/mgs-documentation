package com.meta.game.demo.yc233.bean;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/18
 */
public class TokenInfo {
    /**
     * 开发者平台用户id
     */
    public String openId;
    /**
     * 游戏玩家token
     */
    public String token = "";
    /**
     * token失效时间
     */
 //   public long invalidTime;

    @Override
    public String toString() {
        return "TokenInfo{" +
                "openId='" + openId + '\'' +
                ", token='" + token + '\'' +
           //     ", invalidTime=" + invalidTime +
                '}';
    }
}
