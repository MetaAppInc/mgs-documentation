package com.meta.game.demo.yc233.utils;

import android.os.Handler;
import android.os.Looper;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/20
 */
public class HandlerUtils {
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    public static void runOnUIThread(Runnable task) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            MAIN_HANDLER.post(task);
        } else {
            task.run();
        }
    }
}
