package com.meta.game.demo.yc233.listener;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/03
 */
public interface OnCompletedListener {
    /**
     * 完成的操作
     */
    void onCompleted();
}
