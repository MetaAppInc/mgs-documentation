package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.bean.PlayerInfo;
import com.meta.game.demo.yc233.bean.TeamInfo;
import com.meta.game.demo.yc233.bean.TeamPlayerListResp;
import com.meta.game.demo.yc233.data.YcRoomManager;

import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/18
 */
public class GameBattleView extends BaseView {


    /**
     * 左侧玩家列表
     */
    private RecyclerView leftRecyclerView;
    /**
     * 右侧玩家列表
     */
    private RecyclerView rightRecyclerView;

    private PlayerAdapter leftPlayerAdapter;
    private PlayerAdapter rightPlayerAdapter;

    List<TeamPlayerListResp> response;

    public GameBattleView(@NonNull Context context) {
        super(context, R.layout.game_battle);
    }

    @Override
    protected void init(Context context) {
        leftRecyclerView = findViewById(R.id.rv_team_players_left);
        rightRecyclerView = findViewById(R.id.rv_team_players_right);

        leftPlayerAdapter = new PlayerAdapter(getContext());
        rightPlayerAdapter = new PlayerAdapter(getContext());
        //配置左侧recycleview
        setRecyclerViewConfig(leftRecyclerView, leftPlayerAdapter);
        //配置右侧recycleview
        setRecyclerViewConfig(rightRecyclerView, rightPlayerAdapter);
    }

    /**
     * 配置recyclerView
     * @param recyclerView
     * @param adapter
     */
    private void setRecyclerViewConfig(RecyclerView recyclerView, PlayerAdapter adapter) {
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getContext(),
                DividerItemDecoration.HORIZONTAL);
        itemDecoration.setDrawable(getResources().getDrawable(R.drawable.space_5));
        recyclerView.addItemDecoration(itemDecoration);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),4));
        recyclerView.setAdapter(adapter);
    }

    public void refreshBattleView(String currentTeam,
                                  List<TeamPlayerListResp> response) {

        TeamPlayerListResp leftTeam = null;
        TeamPlayerListResp rightTeam = null;
        for (TeamPlayerListResp resp : response) {
            TeamInfo teamInfo = resp.teamInfo;
            if (currentTeam.equals(teamInfo.teamId)) {
                leftTeam = resp;
            } else {
                rightTeam = resp;
            }
        }

        if (leftTeam != null) {
             refreshPlayerAdapter(leftPlayerAdapter, leftTeam.playerList, leftTeam.teamInfo.roomLimit,
                     R.drawable.icon_player_prepared_green);
        }

        if (rightTeam != null) {
             refreshPlayerAdapter(rightPlayerAdapter, rightTeam.playerList, rightTeam.teamInfo.roomLimit,
                     R.drawable.icon_player_prepared_yellow);
        }

    }


    /**
     * 刷新玩家列表
     */
    private void refreshPlayerAdapter(PlayerAdapter adapter,List<PlayerInfo> currentPlayers, int limitPlayer, int playerIconRes) {

        //当前房间玩家数量
        int playerSize = currentPlayers.size();
        //判断玩家数量是否达到上限,如果是就不需要补空位
        if (playerSize < limitPlayer) {
            int diff = limitPlayer - playerSize;
            for (int i = 0; i < diff; i ++) {
                currentPlayers.add(new PlayerInfo());
            }
        }

        adapter.refresh(currentPlayers, YcRoomManager.getInstance().getRoomInfo().roomOwner,playerIconRes);
    }


}
