package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;
import android.widget.FrameLayout;

import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.bean.TeamPlayerListResp;
import com.meta.game.demo.yc233.data.YcUserManager;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/23
 */
public class GameSceneDmmView extends GameSceneView {

    private static final String         TAG = "GameSceneDmmView";
    /**
     * 战斗场景
     */
    private              GameBattleView battleView;
    private              FrameLayout    battleContainerLayout;
    /**
     * 躲猫猫使用的teamId
     */
    public               String         dmmTeamId = "";
    /**
     * 离开team标识
     */
    private boolean isDoLeaveTeam = false;
    /**
     * 房间内的team列表信息
     */
    private List<TeamPlayerListResp> teamPlayerList = new ArrayList<>();

    public GameSceneDmmView(@NonNull Context context) {
        super(context);
    }

    @Override
    protected void init(Context context) {
        super.init(context);

        battleContainerLayout = findViewById(R.id.ll_player_battle_container);
    }

    @Override
    void showStartBattleUI() {
        //游戏开始回调，不需要事先，躲猫猫类型需要分配好的队伍之后再来处理。
    }


    @Override
    void showEndBattleUI() {

        teamPlayerList.clear();

        //离开躲猫猫的房间
        leaveDmmTeam();

       hideBattleView();

    }


    /**
     * 刷新teamView的视图
     * @param response
     */
    @Override
    void refreshTeamView(List<TeamPlayerListResp> response) {
        Log.i(TAG, "刷新team数据");
        teamPlayerList.clear();
        teamPlayerList.addAll(response);

        //todo如果是躲猫猫类型的，且躲猫猫的team不为空，说明已经开始游戏，分好队伍了
        if ( !TextUtils.isEmpty(dmmTeamId)) {
            refreshDmmBattleView(response);
        }
    }

    @Override
    void doArrangedTeam(Map<String, String> arrangedTeamInfo) {
        Log.i(TAG,"队伍分配完毕--");
        String openId = arrangedTeamInfo.get("openId");
        if (YcUserManager.getInstance().getOpenId().equals(openId)) {
            dmmTeamId = arrangedTeamInfo.get("teamId");
            Log.i(TAG,"当前所在队伍--" + dmmTeamId);
            if (!TextUtils.isEmpty(dmmTeamId)) {
                joinMgsTeamOperate();
            }
        } else {
            Log.i(TAG, "openId is not equal current user's openId");
        }
    }

    /**
     * 加入mgs的team操作
     */
    private void joinMgsTeamOperate(){
        String backRoomId = roomInfo.roomId;
        MgsSdkBridgeHelper.getInstance()
                .joinTeam(dmmTeamId, backRoomId, new MgsFeatureListener() {
                    @Override
                    public void onSuccess(int requestCode, String resultJson) {

                        Log.i(TAG, "mgs joinTeam result onsuccess=" + resultJson);
                        showBattleView();
                    }

                    @Override
                    public void onFail(int i, int i1, String s) {
                        Log.i(TAG, "mgs joinTeam result onfail=" + s);
                        ToastUtils.showToast(getContext(),"加入失败:"+s);
                    }
                });
    }


    /**
     * 显示战斗页面
     */
    private void showBattleView() {
        //躲猫猫类型
        if (battleView == null) {
            battleView = new GameBattleView(getContext());
            battleContainerLayout.addView(battleView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        refreshDmmBattleView(teamPlayerList);
    }

    public void hideBattleView(){
        if (battleView != null) {
            battleContainerLayout.removeView(battleView);
            battleView = null;
        }
    }

    /**
     * 刷新躲猫猫的view
     */
    private void refreshDmmBattleView(List<TeamPlayerListResp> response){

        if (battleView != null ) {
            //刷新battleview的内容
            battleView.refreshBattleView(dmmTeamId, response);
        }
    }

    private void leaveDmmTeam() {
        if (!TextUtils.isEmpty(dmmTeamId) && !isDoLeaveTeam) {
            isDoLeaveTeam = true;
            MgsSdkBridgeHelper.getInstance().leaveTeam(dmmTeamId, new MgsFeatureListener() {
                @Override
                public void onSuccess(int i, String s) {
                    isDoLeaveTeam = false;
                    dmmTeamId = "";
                }

                @Override
                public void onFail(int i, int i1, String s) {
                    isDoLeaveTeam = false;
                }
            });
        }
    }
}
