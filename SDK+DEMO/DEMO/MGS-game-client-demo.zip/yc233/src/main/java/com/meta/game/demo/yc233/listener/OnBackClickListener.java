package com.meta.game.demo.yc233.listener;

import android.view.View;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/02/03
 */
public interface OnBackClickListener {
    /**
     * 返回
     * @param view
     */
   void onBackPressedClick(View view);
}
