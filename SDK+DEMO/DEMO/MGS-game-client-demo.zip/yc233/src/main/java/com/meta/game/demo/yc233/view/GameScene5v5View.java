package com.meta.game.demo.yc233.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;

import com.meta.android.mgs.listener.MgsFeatureListener;
import com.meta.game.demo.yc233.R;
import com.meta.game.demo.yc233.bean.PlayerInfo;
import com.meta.game.demo.yc233.bean.TeamInfo;
import com.meta.game.demo.yc233.bean.TeamPlayerListResp;
import com.meta.game.demo.yc233.constants.GameConstants;
import com.meta.game.demo.yc233.data.YcUserManager;
import com.meta.game.demo.yc233.sdk.MgsSdkBridgeHelper;
import com.meta.game.demo.yc233.utils.ToastUtils;
import com.meta.game.demo.yc233.utils.YcCommonUtils;
import com.meta.game.demo.yc233.widget.StrokeTextView;

import java.util.List;

/**
 * @author zhiwei.xu@appshahe.com
 * @date 2021/03/25
 */
public class GameScene5v5View extends GameSceneView {
    private static final String TAG = "GameScene5v5View";
    /**
     * 临时使用的teamId
     */
    private String tempTeamId;
    /**
     * 离开team标识
     */
    private boolean isDoLeaveTeam = false;

    private StrokeTextView changeTeamBtn;

    public GameScene5v5View(@NonNull Context context) {
        super(context);

    }

    @Override
    protected void init(Context context) {
        super.init(context);
        playerContainersLayout.setGravity(Gravity.CENTER);
        changeTeamBtn = findViewById(R.id.btn_room_change_team);
        ImageView carView = findViewById(R.id.iv_room_car);
        YcCommonUtils.setViewVisible(carView, false);
        changeTeamBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if (roomInfo.roomState != GameConstants.GAME_STATE_PREPARE) {
                    ToastUtils.showToast(getContext(), "游戏中无法切换队伍");
                    return;
                }

                List<TeamInfo> teamInfoList = roomResp.teamInfo;
                String anotherTeamId = "";
                for (TeamInfo teamInfo : teamInfoList) {
                    if (!currentTeamId.equals(teamInfo.teamId)) {
                        anotherTeamId = teamInfo.teamId;
                        break;
                    }
                }

                delegate.sendSwitchTeamAction(anotherTeamId);
            }
        });

        YcCommonUtils.setViewVisible(changeTeamBtn, true);
        YcCommonUtils.setViewVisible(vsView, true);
        YcCommonUtils.setViewVisible(bottomRecyclerView, true);

    }

    @Override
    void showStartBattleUI() {
        super.showStartBattleUI();
        joinMgsTeamOperate();
    }

    @Override
    void showEndBattleUI() {
        leaveMgsTeam();
    }

    @Override
    void refreshTeamView(List<TeamPlayerListResp> response) {
        int size = response != null ? response.size() : 0;

        if (size < 1) {
            Log.i(TAG, "5v5-房间队伍不够...");
            return;
        }


        for (TeamPlayerListResp teamPlayerInfo : response) {
            for (PlayerInfo playerInfo : teamPlayerInfo.playerList) {
                if (YcUserManager.getInstance().getOpenId().equals(playerInfo.userInfo.openId)) {
                    currentTeamId = teamPlayerInfo.teamInfo.teamId;
                    break;
                }
            }
        }

        TeamPlayerListResp topTeam = response.get(0);
        TeamPlayerListResp bottomTeam = response.get(1);

        if (topTeam != null) {
            refreshPlayerAdapter(topRecyclerViewAdapter, topTeam.playerList, topTeam.teamInfo.roomLimit, R.drawable.icon_player_prepared_green);
        }

        if (bottomTeam != null) {
            refreshPlayerAdapter(bottomRecyclerViewAdapter, bottomTeam.playerList, bottomTeam.teamInfo.roomLimit, R.drawable.icon_player_prepared_yellow);
        }

        refreshRoomState(roomInfo);
    }


    @Override
    protected RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
    }

    /**
     * 加入mgs的team操作
     */
    private void joinMgsTeamOperate(){

        tempTeamId = currentTeamId;
        //要返回的房间ID
        String backRoomId = roomInfo.roomId;
        MgsSdkBridgeHelper.getInstance()
                .joinTeam(currentTeamId, backRoomId, new MgsFeatureListener() {
                    @Override
                    public void onSuccess(int requestCode, String resultJson) {
                        Log.i(TAG, "加入team成功===" + resultJson);
                    }

                    @Override
                    public void onFail(int requestCode, int code, String message) {
                        ToastUtils.showToast(getContext(),"加入TEAM失败:"+ message);
                    }
                });
    }


    private void leaveMgsTeam() {

        if (!TextUtils.isEmpty(tempTeamId) && !isDoLeaveTeam) {
            isDoLeaveTeam = true;
            MgsSdkBridgeHelper.getInstance().leaveTeam(tempTeamId, new MgsFeatureListener() {
                @Override
                public void onSuccess(int requestCode, String resultJson) {
                    isDoLeaveTeam = false;
                    tempTeamId = "";
                }

                @Override
                public void onFail(int requestCode, int code, String message) {
                    isDoLeaveTeam = false;
                }
            });
        }

    }

}
