-- 建库sql
CREATE DATABASE `mgs_game_server` CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_general_ci';

-- 用户表sql
CREATE TABLE `t_user` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT,
	`openId` VARCHAR ( 64 ) NOT NULL COMMENT '开放用户ID',
	`openCode` VARCHAR ( 64 ) NOT NULL COMMENT '开放用户CODE',
	`avatar` VARCHAR ( 255 ) DEFAULT NULL COMMENT '用户头像',
	`nickname` VARCHAR ( 64 ) NOT NULL COMMENT '用户昵称',
	PRIMARY KEY ( `id` ),
	UNIQUE KEY `uniq_openId` ( `openId` ) USING BTREE,
UNIQUE KEY `uniq_openCode` ( `openCode` ) USING BTREE
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- token表sql
CREATE TABLE `t_token` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT,
	`openId` VARCHAR ( 64 ) NOT NULL COMMENT '开放用户ID',
	`token` VARCHAR ( 64 ) NOT NULL COMMENT 'Token',
	`invalidTime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'token失效时间',
	PRIMARY KEY ( `id` ),
	UNIQUE KEY `uniq_openId` ( `openId` ) USING BTREE,
UNIQUE KEY `uniq_token` ( `token` ) USING BTREE
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- 房间表sql
CREATE TABLE `t_room` (
	`roomId` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '房间ID',
	`roomLimit` INT ( 3 ) NOT NULL COMMENT '房间成员容量',
	`roomName` VARCHAR ( 128 ) NOT NULL COMMENT '房间名称',
	`roomState` INT ( 2 ) NOT NULL COMMENT '房间状态',
	`roomType` INT ( 2 ) NOT NULL COMMENT '房间类型',
	`full` TINYINT ( 1 ) NOT NULL DEFAULT '0' COMMENT '房间是否满员',
	`roomTags` VARCHAR ( 255 ) DEFAULT NULL COMMENT '房间标签',
	PRIMARY KEY ( `roomId` ),
KEY `idx_name_state_type` ( `roomName`, `roomState`, `roomType` ) USING BTREE
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- 房间-用户表sql
CREATE TABLE `t_room_user` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT,
	`roomId` INT ( 11 ) NOT NULL COMMENT '房间id',
	`openId` VARCHAR ( 64 ) NOT NULL COMMENT '用户开放id',
	`userState` INT ( 2 ) NOT NULL DEFAULT '1' COMMENT '玩家状态: 0 未准备, 1 准备',
	PRIMARY KEY ( `id` ),
KEY `idx_roomId` ( `roomId` ) USING BTREE
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci;


-- 2021/03/10 增加房主、team
ALTER TABLE `mgs_game_server`.`t_room`
ADD COLUMN `roomOwner` varchar(64) DEFAULT NULL COMMENT '房主openId' AFTER `roomTags`,
ADD COLUMN `hasParent` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'true表示该房间类型为TEAM，默认false' AFTER `roomOwner`;

-- gameToken增加字段长度
ALTER TABLE `mgs_game_server`.`t_token`
MODIFY COLUMN `token` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Token' AFTER `openId`;

-- 用户-房间 唯一索引
ALTER TABLE `mgs_game_server`.`t_room_user`
ADD UNIQUE INDEX `uniq_roomId_openId`(`roomId`, `openId`) USING BTREE;

-- 队伍表
CREATE TABLE `t_team` (
	`teamId` INT ( 11 ) NOT NULL COMMENT '队伍id',
	`parentId` INT ( 16 ) NOT NULL COMMENT '房间的id，表示该team在哪个房间下',
	`chatScope` INT ( 2 ) NOT NULL COMMENT '聊天室能力范围: 0无,1Room,2Team',
	`voiceScope` INT ( 2 ) NOT NULL COMMENT '开麦能力范围: 0无,1Room,2Team',
	PRIMARY KEY ( `teamId` ),
UNIQUE KEY `uniq_team_room` ( `teamId`, `parentId` ) USING BTREE
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci;