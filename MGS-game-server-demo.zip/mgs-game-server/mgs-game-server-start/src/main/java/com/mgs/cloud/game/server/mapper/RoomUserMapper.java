package com.mgs.cloud.game.server.mapper;

import com.mgs.cloud.game.server.model.entity.room.RoomUserEntity;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@Mapper
public interface RoomUserMapper {

    /**
     * 插入一条房间用户信息
     *
     * @param roomUser 房间id、用户openId
     * @return 受影响的行数
     */
    @Insert("insert into `t_room_user`(`roomId`, `openId`) " +
            "values(#{roomUser.roomId}, #{roomUser.openId}) ON DUPLICATE KEY UPDATE `openId` = values(`openId`) ")
    int insertOne(@Param("roomUser") RoomUserEntity roomUser);

    /**
     * 插入一坨房间用户信息
     *
     * @param roomUsers 房间id、用户openId List
     * @return 受影响的行数
     */
    @Insert({"<script>",
            "insert into `t_room_user`(`roomId`, `openId`) " +
                    "<foreach collection=\"roomUsers\" index=\"index\" item=\"item\" separator=\",\" open=\"values\">" +
                    "(#{item.roomId}, #{item.openId})" +
                    "</foreach> " +
                    " ON DUPLICATE KEY UPDATE " +
                    " `openId` = values(`openId`) ",
            "</script>"})
    int batchInsert(@Param("roomUsers") List<RoomUserEntity> roomUsers);

    /**
     * 根据roomId查询数量
     *
     * @param roomId 房间号
     * @return 该房间的用户数量
     */
    @Select("select `openId` from `t_room_user` where `roomId` = #{roomId} group by `openId`")
    List<String> selectOpenIdsByRoomId(@Param("roomId") Integer roomId);

    /**
     * 根据roomId、openId删除
     *
     * @param roomId 房间号
     * @param openId 用户开放id
     * @return 受影响的行数
     */
    @Delete("delete from `t_room_user` where `roomId` = #{roomId} and `openId` = #{openId}")
    int deleteByRoomIdOpenId(@Param("roomId") Integer roomId, @Param("openId") String openId);

    /**
     * 根据房间号查询玩家信息
     *
     * @param roomId 房间号
     * @return list
     */
    @Select("select * from `t_room_user` where `roomId` = #{roomId}")
    List<RoomUserEntity> listByRoomId(@Param("roomId") Integer roomId);

    /**
     * 根据roomId、openId查询
     *
     * @param roomId 房间id
     * @param openId 用户开放id
     * @return 数量
     */
    @Select("select count(1) from `t_room_user` where `openId` = #{openId} and `roomId` = #{roomId}")
    int selectByRoomIdOpenId(@Param("roomId") Integer roomId, @Param("openId") String openId);

    /**
     * 根据房间号、用户状态查询
     *
     * @param roomId    房间号
     * @param userState 用户状态
     * @return list
     */
    @Select("select * from `t_room_user` where `roomId` = #{roomId} and `userState` = #{userState}")
    List<RoomUserEntity> listByRoomIdState(@Param("roomId") Integer roomId, @Param("userState") Integer userState);

    /**
     * 根据roomId删除
     *
     * @param roomId 房间号
     * @return 受影响的行数
     */
    @Delete("delete from `t_room_user` where `roomId` = #{roomId}")
    int deleteByRoomId(@Param("roomId") Integer roomId);
}
