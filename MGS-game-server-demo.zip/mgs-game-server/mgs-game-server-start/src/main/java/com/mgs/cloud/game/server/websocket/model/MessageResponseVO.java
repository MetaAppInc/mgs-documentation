package com.mgs.cloud.game.server.websocket.model;

import com.mgs.api.game.server.model.vo.Response;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;

/**
 * @author guozheng.zhao
 * @date 2021/3/10
 */
@ToString
@Data
@ApiModel("webSocket返回")
@Accessors(chain = true)
public class MessageResponseVO {

    @NotNull(message = "action不能为空")
    @ApiModelProperty("执行的动作")
    private String action;

    @ApiModelProperty("返回的数据")
    private Response<?> response;

    @ApiModelProperty("请求标识码")
    private Integer requestCode;

}
