package com.mgs.cloud.game.server.websocket.config;

import com.google.common.base.Strings;
import com.mgs.cloud.game.server.aop.OpenUserTokenAop;
import com.mgs.cloud.game.server.config.AppKeyInfo;
import com.mgs.cloud.game.server.config.UserOpenIdInfo;
import com.mgs.cloud.game.server.model.enums.user.TokenInvalidConfig;
import com.mgs.cloud.game.server.service.IUserService;
import com.mgs.cloud.game.server.utils.SignUtil;
import com.mgs.cloud.game.server.utils.context.ApplicationContextUtil;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.URLDecoder;

/**
 * WebSocket校验gameToken、获取OpenId的Filter
 *
 * @author guozheng.zhao
 * @date 2021/3/9
 */
@Order(1)
@Component
@WebFilter(filterName = "WebsocketFilter", urlPatterns = "/connectServer/*")
public class WebsocketFilter implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        // 传递过来的token是URL编码加密的
        String encodeStr = request.getHeader(OpenUserTokenAop.TOKEN_KEY);
        if (!Strings.isNullOrEmpty(encodeStr)) {
            // appKey
            AppKeyInfo.setAppKey(request.getHeader(SignUtil.APP_KEY));
            // URL编码解密得到gameToken
            String gameToken = URLDecoder.decode(encodeStr, "UTF-8");
            // 校验gameToken
            IUserService userService = ApplicationContextUtil.getBean(IUserService.class);
            if (userService.checkToken(gameToken, TokenInvalidConfig.TOKEN_OPEN_USER)) {
                // gameToken校验通过后将openId传递
                UserOpenIdInfo.setOpenId(TokenInvalidConfig.TOKEN_OPEN_USER.getDecryptTokenFunc().apply(gameToken));
            } else {
                UserOpenIdInfo.clean();
            }
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }
}