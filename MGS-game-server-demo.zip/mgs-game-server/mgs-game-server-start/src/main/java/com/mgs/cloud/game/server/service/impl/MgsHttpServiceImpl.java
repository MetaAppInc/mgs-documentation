package com.mgs.cloud.game.server.service.impl;

import com.alibaba.fastjson.JSON;
import com.mgs.api.game.server.model.enums.mgs.MgsHttpConfig;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;
import com.mgs.api.game.server.model.vo.mgs.ResponseVO;
import com.mgs.cloud.game.server.config.AppKeyInfo;
import com.mgs.cloud.game.server.config.mgs.MgsConfig;
import com.mgs.cloud.game.server.config.mgs.MgsConfigItem;
import com.mgs.cloud.game.server.service.IMgsHttpService;
import com.mgs.cloud.game.server.utils.OkHttpClientUtil;
import com.mgs.cloud.game.server.utils.SignUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.lang.reflect.Type;


/**
 * 请求MGS服务端的Http请求Service逻辑实现
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@Slf4j
@Service
public class MgsHttpServiceImpl implements IMgsHttpService {

    @Autowired
    MgsConfig mgsConfig;

    /**
     * 向mgs发送http请求
     * <p>
     * 1. 校验参数类型是否和mgsHttpConfig配置的类型一致
     * 2. 根据请求头的appKey获取mgs配置
     * 3. 根据yml配置的域名 + mgsHttpConfig配置的url组成要请求的地址
     * 4. 根据yml配置的appSecret和请求参数加密签名
     * 5. 将yml配置的appKey和加密的签名加入到请求头
     * 6. 发送http请求
     * 7. 封装返回值
     *
     * @param mgsHttpConfig MGS Http请求的配置
     * @param param         请求参数，sign是根据param生成的，不能为null
     * @param <R>           返回数据的类型
     * @param <P>           请求参数的类型
     * @return 请求mgs返回的数据转换成mgsHttpConfig.responseClazz类型的返回值
     */
    @Override
    public <R, P> R sendPostJsonRequest(@NotNull MgsHttpConfig mgsHttpConfig, @NotNull P param) {
        if (param.getClass() != mgsHttpConfig.getRequestClazz()) {
            // 参数类型错误，抛出异常
            throw new UniversalException(UniversalErrorCode.CLASS_ERROR);
        }
        // 获取当前请求的appKey
        String currentAppKey = AppKeyInfo.getAppKey();
        // 根据当前appKey获取对应的mgs配置
        MgsConfigItem mgsConfigItem = mgsConfig.get(currentAppKey);
        // 域名 + 接口地址
        String url = mgsConfigItem.getDomain() + mgsHttpConfig.getUrl();
        try {
            // 进行签名
            String sign = SignUtil.getSign(param, mgsConfigItem.getAppSecret());
            // 存储到http header中   sign=签名    appKey=配置中的密钥
            Headers headers = new Headers.Builder()
                    .add(SignUtil.APP_KEY, mgsConfigItem.getAppKey())
                    .add(SignUtil.SIGN, sign).build();
            ResponseVO responseVO = JSON.parseObject(OkHttpClientUtil.postWithJson(url, JSON.toJSONString(param), headers), ResponseVO.class);
            // code 200 代表成功
            if (responseVO.getCode() != HttpStatus.OK.value()) {
                log.error("{} response error: {}", mgsHttpConfig.getUrl(), JSON.toJSONString(responseVO));
                throw new UniversalException(responseVO.getCode(), responseVO.getMessage());
            }
            // data 为null则不进行类型转换
            if (null == responseVO.getData()) {
                return null;
            }
            return JSON.parseObject(responseVO.getData().toString(), (Type) mgsHttpConfig.getResponseClazz());
        } catch (UniversalException universalException) {
            // 丢给上层处理
            throw universalException;
        } catch (IOException ioException) {
            log.error("sendPostJsonRequest http error: {}", ioException.getMessage(), ioException);
            log.info("mgs http request error info: url- {}, param- {}", url, param);
            throw new UniversalException(UniversalErrorCode.HTTP_ERROR);
        } catch (ClassCastException classCastException) {
            log.error("sendPostJsonRequest class cast error: {}", classCastException.getMessage(), classCastException);
            throw new UniversalException(UniversalErrorCode.CLASS_ERROR);
        } catch (Exception e) {
            log.error("sendPostJsonRequest error: {}", e.getMessage(), e);
            // 预期外异常，抛出UniversalException保证rollbackFor = UniversalException.class的事务可以正常回滚
            throw new UniversalException(UniversalErrorCode.HTTP_ERROR);
        }
    }

}
