package com.mgs.cloud.game.server.config;

import com.google.common.base.Strings;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;

/**
 * 在线程上下文获取使用当前appKey
 *
 * @author guozheng.zhao
 * @date 2021/3/19
 */
public class AppKeyInfo {

    /**
     * 当前请求的appKey
     */
    private static ThreadLocal<String> appKey = new ThreadLocal<>();

    /**
     * 获取appKey，为空直接抛出异常
     *
     * @return appKey
     */
    public static String getAppKey() {
        String currentAppKey = appKey.get();
        if (Strings.isNullOrEmpty(currentAppKey)) {
            throw new UniversalException(UniversalErrorCode.APP_KEY_ERROR);
        }
        return currentAppKey;
    }

    /**
     * 设置appKey，会在OpenUserTokenAop执行此方法
     *
     * @param appKey appKey
     */
    public static void setAppKey(String appKey) {
        clean();
        AppKeyInfo.appKey.set(appKey);
    }

    /**
     * 清除openId
     */
    public static void clean() {
        appKey.remove();
    }

}
