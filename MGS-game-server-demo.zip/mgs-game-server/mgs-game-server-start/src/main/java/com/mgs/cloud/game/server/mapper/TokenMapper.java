package com.mgs.cloud.game.server.mapper;

import com.mgs.cloud.game.server.model.entity.user.UserTokenEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@Mapper
public interface TokenMapper {

    /**
     * 插入/修改用户Token信息
     *
     * @param userToken 用户Token信息
     * @return 受影响的行数
     */
    @Insert("insert into `t_token`(`openId`, `token`, `invalidTime`) " +
            "values(#{userToken.openId}, #{userToken.token}, #{userToken.invalidTime}) " +
            "ON DUPLICATE KEY UPDATE `token` = values(`token`), invalidTime = values(`invalidTime`)")
    int insertOrUpdateToken(@Param("userToken") UserTokenEntity userToken);

    /**
     * 根据token查询UserToken信息
     *
     * @param token token
     * @return DTO
     */
    @Select("select * from `t_token` where `token` = #{token}")
    UserTokenEntity selectUserTokenByToken(@Param("token") String token);
}
