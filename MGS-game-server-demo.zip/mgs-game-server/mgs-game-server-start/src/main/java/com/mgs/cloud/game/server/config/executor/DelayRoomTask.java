package com.mgs.cloud.game.server.config.executor;

import org.jetbrains.annotations.NotNull;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 * 修改ROOM信息的延时任务
 *
 * @author guozheng.zhao
 * @date 2021/3/9
 */
public class DelayRoomTask<T extends Runnable> implements Delayed {

    /**
     * 延时时间
     */
    private final long time;

    /**
     * 延时任务
     */
    private final T task;

    DelayRoomTask(long time, T task) {
        this.time = time;
        this.task = task;
    }

    @Override
    public long getDelay(@NotNull TimeUnit unit) {
        return time - System.currentTimeMillis();
    }

    @Override
    public int compareTo(@NotNull Delayed o) {
        DelayRoomTask<?> other = (DelayRoomTask) o;
        long diff = time - other.time;
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        } else {
            return 0;
        }
    }

    @Override
    public int hashCode() {
        return task.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    public T getTask() {
        return task;
    }
}
