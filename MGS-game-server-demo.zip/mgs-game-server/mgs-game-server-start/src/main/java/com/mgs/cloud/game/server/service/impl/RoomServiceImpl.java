package com.mgs.cloud.game.server.service.impl;

import com.google.common.base.Strings;
import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.dto.team.TeamDTO;
import com.mgs.api.game.server.model.dto.user.UserInfoDTO;
import com.mgs.api.game.server.model.enums.mgs.MgsHttpConfig;
import com.mgs.api.game.server.model.enums.room.RoomStateEnum;
import com.mgs.api.game.server.model.enums.room.RoomTypeEnum;
import com.mgs.api.game.server.model.enums.team.TeamConfigEnum;
import com.mgs.api.game.server.model.enums.user.UserStateEnum;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;
import com.mgs.api.game.server.model.qo.mgs.room.CreateMgsRoomQuery;
import com.mgs.api.game.server.model.qo.mgs.room.DestroyRoomQuery;
import com.mgs.api.game.server.model.qo.mgs.room.SyncInfoQuery;
import com.mgs.api.game.server.model.qo.mgs.team.SyncMemberQuery;
import com.mgs.api.game.server.model.qo.mgs.user.BatchCheckFriendQuery;
import com.mgs.api.game.server.model.qo.room.CreateRoomQuery;
import com.mgs.api.game.server.model.qo.room.JoinRoomQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import com.mgs.api.game.server.model.qo.team.CreateTeamQuery;
import com.mgs.api.game.server.model.qo.team.JoinTeamQuery;
import com.mgs.api.game.server.model.qo.team.TeamIdQuery;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.api.game.server.model.vo.mgs.room.CreateRoomVO;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomInfoVO;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomUserVO;
import com.mgs.api.game.server.model.vo.room.RoomVO;
import com.mgs.api.game.server.model.vo.team.TeamInfoVO;
import com.mgs.cloud.game.server.config.UserOpenIdInfo;
import com.mgs.cloud.game.server.mapper.RoomMapper;
import com.mgs.cloud.game.server.mapper.RoomUserMapper;
import com.mgs.cloud.game.server.mapper.UserMapper;
import com.mgs.cloud.game.server.mapstruct.RoomEntityMapper;
import com.mgs.cloud.game.server.mapstruct.UserEntityMapper;
import com.mgs.cloud.game.server.model.entity.room.RoomEntity;
import com.mgs.cloud.game.server.model.entity.room.RoomUserEntity;
import com.mgs.cloud.game.server.model.entity.team.TeamEntity;
import com.mgs.cloud.game.server.model.entity.user.UserInfoEntity;
import com.mgs.cloud.game.server.service.IMgsHttpService;
import com.mgs.cloud.game.server.service.IRoomService;
import com.mgs.cloud.game.server.service.ITeamService;
import com.mgs.cloud.game.server.service.IUserService;
import com.mgs.cloud.game.server.websocket.WebSocketServer;
import com.mgs.cloud.game.server.websocket.config.MessageActionEnum;
import com.mgs.cloud.game.server.websocket.config.MessageMethodEnum;
import com.mgs.cloud.game.server.websocket.model.MessageResponseVO;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@Service
@Slf4j
public class RoomServiceImpl implements IRoomService {

    @Autowired
    private RoomMapper roomMapper;

    @Autowired
    private RoomUserMapper roomUserMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private IUserService userService;

    @Autowired
    private ITeamService teamService;

    @Autowired
    private IMgsHttpService mgsHttpService;

    /**
     * 创建房间，并同步mgs
     * <p>
     * 1. 将QO入参转换成Entity
     * 2. 新建房间（insert t_room）并将数据库生成的roomId返回到Entity
     * 3. 判断是否需要创建team
     * 4. 创建者加入房间（insert t_room_user），失败则回滚
     * 5. 判断是否需要加入team
     * 6. 将房间信息Entity转换为DTO返回
     *
     * @param createRoomQuery 房间设置信息
     * @return 房间信息
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public RoomVO createRoom(@NotNull CreateRoomQuery createRoomQuery) {
        return createRoom(createRoomQuery, UserOpenIdInfo.getOpenId());
    }

    /**
     * 创建游戏房间
     * <p>
     * 1. 参数初始化成t_room对应模型
     * 2. 入库
     *
     * @param createRoomQuery 房间设置信息
     * @param openId          用户id,当用户创建时传入
     * @param roomTypeEnum    房间类型配置
     * @return 房间信息
     */
    @Override
    public RoomDTO createGameRoom(@NotNull CreateRoomQuery createRoomQuery, @Nullable String openId, @NotNull RoomTypeEnum roomTypeEnum) {
        // 创建房间
        RoomEntity entity = new RoomEntity()
                .init(roomTypeEnum).initState()
                .setRoomOwner(openId);
        return createGameRoom(entity, openId);
    }

    /**
     * 创建游戏房间
     * <p>
     * 1. 新建房间（insert t_room）并将数据库生成的roomId返回到Entity
     * 2. 将房间信息Entity转换为DTO返回
     *
     * @param entity 房间实体信息
     * @param openId 用户id,当用户创建时传入
     * @return 房间信息
     */
    @Override
    public RoomDTO createGameRoom(@NotNull RoomEntity entity, @Nullable String openId) {
        if (!Strings.isNullOrEmpty(openId)) {
            entity.setRoomName(userMapper.selectByOpenId(openId).getNickname());
        }
        if (0 == roomMapper.insertOne(entity)) {
            throw new UniversalException(UniversalErrorCode.CREATE_ROOM_ERROR);
        }
        return RoomEntityMapper.INSTANCE.toRoomDTO(entity);
    }

    /**
     * 注：需要接入MGS房间系统请看此例
     * <p>
     * 创建房间，并同步mgs
     * <p>
     * 1. 新建房间（insert t_room）并将数据库生成的roomId返回到Entity
     * 2. 创建mgs房间
     * 3. 根据mgs返回值更新room的标签
     * 4. 如果room有team配置，则创建team
     * 5. 加入房间，并返回房间VO
     *
     * @param createRoomQuery 房间设置信息
     * @param openId          用户id,当用户创建时传入
     * @return 房间信息
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public RoomVO createRoom(@NotNull CreateRoomQuery createRoomQuery, @Nullable String openId) {
        RoomTypeEnum roomTypeEnum = RoomTypeEnum.getEnumTypeByCode(createRoomQuery.getRoomType());
        if (null == roomTypeEnum) {
            throw new UniversalException(UniversalErrorCode.ROOM_CONFIG_ERROR);
        }
        // 创建游戏房间
        RoomDTO room = createGameRoom(createRoomQuery, openId, roomTypeEnum).initRoomTagList();
        // 创建mgs房间
        CreateRoomVO mgsRoom = createMgsRoom(room.toCreateMgsRoomQuery());
        log.info("create mgs room response: {}", mgsRoom);
        // 标签不为空就更新到room
        if (!CollectionUtils.isEmpty(mgsRoom.getRoomTags())) {
            room.setRoomTagsByList(mgsRoom.getRoomTags());
            int row = roomMapper.updateRoomTags(room.getRoomId(), room.getRoomTags());
            log.info("update room tags[{}]: {}", mgsRoom.getRoomTags(), row);
        }
        if (roomTypeEnum.getHasTeam()) {
            CreateTeamQuery createTeamQuery = new CreateTeamQuery();
            BeanUtils.copyProperties(createRoomQuery, createTeamQuery);
            // 获取创建队伍使用的配置
            TeamConfigEnum teamConfig = roomTypeEnum.getTeamConfig();
            log.info("create by team config, chatScope: {}, voiceScope: {}", teamConfig.getChatScope(), teamConfig.getVoiceScope());
            // 创建队伍
            List<TeamDTO> team = teamService.createTeam(createTeamQuery.init(teamConfig, room.getRoomId()));
            log.info("create team result: {}", team);
        }

        // 加入房间
        return joinRoom(new JoinRoomQuery(room.getRoomId(), room.getRoomType())).setRoomShowNumber(mgsRoom.getRoomShowNum());
    }

    /**
     * 加入房间
     * <p>
     * 1. 判断是否是普通加入房间，是则joinRoom
     * 2. 随机一个人不满的房间joinRoom，没有则返回满员
     * 3. 判断是否需要加入team
     * 4. 房间成员同步mgs
     *
     * @param joinRoomQuery 房间id, 不为空代表正常加入房间, 为空代表快速加入房间
     * @return 房间信息
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public RoomVO joinRoom(@NotNull JoinRoomQuery joinRoomQuery) {
        Integer roomId = joinRoomQuery.getRoomId();
        Integer teamId = joinRoomQuery.getTeamId();
        String openId = UserOpenIdInfo.getOpenId();
        if (null == roomId) {
            // 快速加入房间，随机一个人不满且不是密码房的房间
            List<Integer> roomIdList = roomMapper.listTenRoomIdByFull(false, joinRoomQuery.getRoomType());
            if (CollectionUtils.isEmpty(roomIdList)) {
                // 所有房间均已满员
                throw new UniversalException(UniversalErrorCode.FREE_ROOM_NOT_FOUND);
            }
            roomId = roomIdList.get((int) (Math.random() * roomIdList.size()));
        }
        // 加入房间
        return joinRoom(roomId, openId, teamId);
    }

    /**
     * 注：需要接入MGS房间系统请看此例
     * <p>
     * 同步房间成员到mgs
     * <p>
     * 1. 查询房间内所有成员
     * 2. 房间成员、房间id 同步mgs
     * 3. mgs同步失败则抛出异常，上层业务回滚
     *
     * @param roomId 房间id
     */
    @Override
    public void syncRoomToMgs(@NotNull Integer roomId) {
        List<RoomUserEntity> userList = roomUserMapper.listByRoomId(roomId);
        List<String> openIdList = userList.stream().map(RoomUserEntity::getOpenId).collect(Collectors.toList());
        Boolean syncResult = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.ROOM_SYNC, new SyncMemberQuery(openIdList, roomId.toString()));
        log.info("sync mgs room member: {}", syncResult);
        if (!syncResult) {
            throw new UniversalException(UniversalErrorCode.ROOM_SYNC_MEMBER_ERROR);
        }
    }

    /**
     * 离开房间
     * 离开成功 return {@code true}, 离开失败 return {@code false}
     * <p>
     * 1. 校验房间号是否存在、用户是否在房间中
     * 2. 离开房间（delete t_room_user）
     * 3. 如果房间状态是满员，修改为未满员（update t_room）
     * 4. 如果是最后一个人离开房间则执行销毁房间，销毁失败则回滚
     *
     * @param leaveRoomQuery 房间id
     * @return 离开房间是否成功
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public Boolean leaveRoom(@NotNull RoomIdQuery leaveRoomQuery) {
        return leaveRoom(leaveRoomQuery.getRoomId(), UserOpenIdInfo.getOpenId());
    }

    /**
     * 离开房间并广播消息给房间内其他用户
     *
     * @param leaveRoomQuery 房间id
     * @return 是否离开成功
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public Boolean leaveRoomAndFanout(@NotNull RoomIdQuery leaveRoomQuery) {
        // 广播
        return fanout(leaveRoomQuery.getRoomId(), this::leaveRoom, leaveRoomQuery);
    }

    /**
     * 广播房间信息给房间内所有用户
     * <p>
     * 1. 执行广播的前置方法
     * 2. 查询房间信息
     * 3. 广播给房间内用户
     *
     * @param roomId 房间id
     * @param func   执行方法
     * @param t      方法参数
     * @param <T>    入参类型
     * @param <R>    返回值类型
     * @return 方法执行的返回值
     */
    @Override
    public <T, R> R fanout(@NotNull Integer roomId, @NotNull Function<T, R> func, @NotNull T t) {
        // 执行方法
        R apply = func.apply(t);
        // 先查询信息
        Response<Object> execute = Response.execute(res -> res.setData(queryRoom(new RoomIdQuery(roomId))));
        // 离开房间后查询，状态码不为200的话不广播数据
        if (!UniversalErrorCode.OK.getCode().equals(execute.getCode())) {
            return apply;
        }
        MessageResponseVO responseVO = new MessageResponseVO()
                .setAction(MessageMethodEnum.ROOM_QUERY.getAction())
                .setResponse(execute);
        // 广播
        WebSocketServer.fanoutMessage(responseVO, roomId);
        // 返回方法执行结果
        return apply;
    }

    /**
     * 离开房间
     * 离开成功 return {@code true}, 离开失败 return {@code false}
     * <p>
     * 1. 校验房间号是否存在、用户是否在房间中
     * 2. 离开房间（delete t_room_user）
     * 3. 如果房间状态是满员，修改为未满员（update t_room）
     * 4. 如果存在team模式，同时离开team
     * 5. 如果是最后一个人离开房间则执行销毁房间，销毁失败则回滚
     * 6. 如果不是最后一个人且是房主，则重新找一个人做房主
     *
     * @param roomId 房间id
     * @param openId 开放用户id
     * @return 离开房间是否成功
     */
    @Override
    public Boolean leaveRoom(@NotNull Integer roomId, @NotNull String openId) {
        RoomEntity room = roomMapper.selectByRoomId(roomId);
        // 房间不存在/用户不在房间内，判定为离开成功，直接返回true
        if (null == room || roomUserMapper.selectByRoomIdOpenId(roomId, openId) == 0) {
            return true;
        }
        int row = roomUserMapper.deleteByRoomIdOpenId(roomId, openId);
        if (0 == row) {
            return false;
        }
        // 如果房间是满员状态，修改为未满员
        if (room.getFull()) {
            roomMapper.updateRoomFull(roomId, false);
        }
        // 离开房间同时离开team
        if (!room.getHasParent()) {
            teamService.leaveTeamByParentId(roomId, openId);
        }
        List<String> openIds = getOpenIdsByRoomId(roomId);
        if (!room.getHasParent() && CollectionUtils.isEmpty(openIds)) {
            // 如果是房间最后一个人，则自动销毁房间
            destroyRoom(new RoomIdQuery(roomId));
        } else if (!room.getHasParent() && !Strings.isNullOrEmpty(room.getRoomOwner()) && room.getRoomOwner().equals(openId)) {
            // 不是最后一个人且是房主，则重新选一个房主
            String newRoomOwner = openIds.get(new Random().nextInt(openIds.size()));
            int updateRow = roomMapper.updateRoomOwnerByOpenId(newRoomOwner, roomId);
            log.info("update room[{}] roomOwner[{}]: {}", roomId, newRoomOwner, updateRow);
        }
        return true;
    }

    /**
     * 获取房间内的用户id列表
     *
     * @param roomId 房间id
     * @return 用户id列表
     */
    @Override
    public List<String> getOpenIdsByRoomId(@NotNull Integer roomId) {
        return roomUserMapper.selectOpenIdsByRoomId(roomId);
    }

    /**
     * 查询并校验房间信息
     *
     * @param roomId 房间id
     * @return 房间信息
     */
    private RoomEntity queryAndCheckRoom(@Nullable Integer roomId) {
        if (null == roomId) {
            throw new UniversalException(UniversalErrorCode.ROOM_NOT_FOUND);
        }
        // 先校验房间号的有效性
        RoomEntity room = roomMapper.selectByRoomId(roomId);
        if (null == room) {
            throw new UniversalException(UniversalErrorCode.ROOM_NOT_FOUND);
        }
        return room;
    }

    /**
     * 同步游戏房间信息
     * <p>
     * 1. 校验房间号是否存在、用户是否在房间中
     * 2. 校验房主
     * 3. 校验房间内玩家是否都是准备状态
     * 4. 修改房间状态（update t_room）
     * 5. 包含team模式则同步房间下所有队伍
     *
     * @param syncRoomStateQuery 房间状态
     * @return 是否同步成功
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public RoomDTO syncGameRoomInfo(@NotNull SyncRoomStateQuery syncRoomStateQuery) {
        String openId = UserOpenIdInfo.getOpenId();
        // 先校验房间号的有效性
        Integer roomId = syncRoomStateQuery.getRoomId();
        RoomEntity room = queryAndCheckRoom(roomId);
        Boolean isTeam = room.getHasParent();
        if (!isTeam) {
            // 校验用户是否在房间中
            checkUserInRoom(roomId, openId);
        }
        // 只有房主可以改变房间状态
        if (!isTeam && !openId.equals(room.getRoomOwner())) {
            throw new UniversalException(UniversalErrorCode.ROOM_SYNC_UNAUTHORIZED);
        }
        // 房间内玩家全部准备状态才可以开始游戏
        if (!isTeam && !RoomStateEnum.READYING.getStateCode().equals(syncRoomStateQuery.getState()) &&
                !CollectionUtils.isEmpty(roomUserMapper.listByRoomIdState(roomId, UserStateEnum.UNPREPARED.getStateCode()))) {
            throw new UniversalException(UniversalErrorCode.ROOM_SYNC_STATE_ERROR);
        }
        // 修改房间状态
        if (roomMapper.updateRoomState(roomId, syncRoomStateQuery.getState()) == 0) {
            throw new UniversalException(UniversalErrorCode.ROOM_UPDATE_ERROR);
        }
        RoomDTO roomDTO = RoomEntityMapper.INSTANCE.toRoomDTO(roomMapper.selectByRoomId(roomId));
        // 以下代码面向需要接入mgs的team系统的cp
        // 同步队伍成员，并校验队伍分配是否合理
        teamService.syncTeamMember(roomDTO, syncRoomStateQuery);
        // 同步房间下的team状态
        if (!isTeam) {
            teamService.syncTeamState(roomId, syncRoomStateQuery.getState());
        }
        return roomDTO;
    }

    /**
     * 注：需要接入MGS房间系统请看此例
     * <p>
     * 同步房间信息
     * 同步成功 return {@code true}, 同步失败 return {@code false}
     * <p>
     * 1. 同步游戏房间信息
     * 2. 同步mgs房间信息，失败则回滚
     * 3. 如果是开始游戏且房间配置是开始游戏时分配队伍，则调用随机分组的逻辑
     * 4. 将team成员同步至mgs
     *
     * @param syncRoomStateQuery 房间状态
     * @return 是否同步成功
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public Boolean syncRoomInfo(@NotNull SyncRoomStateQuery syncRoomStateQuery) {
        RoomDTO roomDTO = syncGameRoomInfo(syncRoomStateQuery);
        if (null == roomDTO) {
            return false;
        }
        // 同步房间状态到MGS
        Boolean result = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.ROOM_SYNC_INFO, new SyncInfoQuery().setRoomLimit(roomDTO.getRoomLimit()).init(syncRoomStateQuery));
        if (!result) {
            // mgs修改失败，回滚
            throw new UniversalException(UniversalErrorCode.MGS_ROOM_UPDATE_ERROR);
        }
        return true;
    }

    /**
     * 同步房间信息并广播房间状态
     *
     * @param syncRoomStateQuery 房间状态
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public void syncRoomInfoAndFanout(@NotNull SyncRoomStateQuery syncRoomStateQuery) {
        Boolean syncResult = syncRoomInfo(syncRoomStateQuery);
        WebSocketServer.sendMessage(syncResult, MessageActionEnum.ROOM_SYNC.getAction(), UserOpenIdInfo.getOpenId());
        if (syncResult) {
            // 广播房间状态
            WebSocketServer.fanoutMessage(syncRoomStateQuery.getState(), MessageActionEnum.ROOM_SYNC_STATE.getAction(), syncRoomStateQuery.getRoomId());
        }
    }

    /**
     * 销毁游戏房间
     * 销毁成功 return {@code true}, 销毁失败 return {@code false}
     * <p>
     * 1. 校验房间中剩余人数是否为0
     * 2. 销毁房间（delete t_room）
     *
     * @param roomId 房间号
     * @return 是否销毁成功
     */
    @Override
    public Boolean destroyGameRoom(@NotNull Integer roomId) {
        // 校验下房间是否没人了
        if (!CollectionUtils.isEmpty(roomUserMapper.selectOpenIdsByRoomId(roomId))) {
            return false;
        }
        return roomMapper.deleteByRoomId(roomId) > 0;
    }

    /**
     * 注：需要接入MGS房间系统请看此例
     * <p>
     * 销毁房间，并同步mgs
     * 销毁成功 return {@code true}, 销毁失败 return {@code false}
     * <p>
     * 1. 校验房间中剩余人数是否为0
     * 2. 调用mgs销毁房间
     * 3. 销毁房间（delete t_room）
     *
     * @param destroyRoomQuery 房间号
     * @return 是否销毁成功
     */
    @Override
    public Boolean destroyRoom(@NotNull RoomIdQuery destroyRoomQuery) {
        // 这里的销毁房间和mgs没有数据强一致性要求，所以优先以游戏服务端为主，即使mgs销毁失败也不需要回滚
        Integer roomId = destroyRoomQuery.getRoomId();
        // 调用MGS的销毁房间
        Boolean result = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.ROOM_DESTROY, new DestroyRoomQuery().init(destroyRoomQuery));
        log.info("destroy room[roomId- {}] result: {}", roomId, result);
        Boolean destroyed = destroyGameRoom(roomId);
        // 销毁房间后销毁房间下的team
        List<TeamEntity> teamEntities = teamService.listTeamByParentId(roomId);
        teamEntities.forEach(x -> teamService.destroyTeam(new TeamIdQuery(x.getTeamId())));
        return destroyed;
    }

    /**
     * 查询房间的玩家列表
     * <p>
     * 1. 查询房间内所有用户，去重
     * 2. 封装 用户信息、用户状态，返回
     *
     * @param queryUserQuery 房间号
     * @return 玩家列表
     */
    @Override
    public List<QueryRoomUserVO> queryUserList(@NotNull RoomIdQuery queryUserQuery) {
        // 房间内所有用户
        List<RoomUserEntity> roomUserEntities = roomUserMapper.listByRoomId(queryUserQuery.getRoomId());
        if (CollectionUtils.isEmpty(roomUserEntities)) {
            return new ArrayList<>();
        }
        // openId
        List<String> openIdList = roomUserEntities.stream().map(RoomUserEntity::getOpenId).distinct().collect(Collectors.toList());
        // 用户信息
        List<UserInfoDTO> userInfoDTOList = userService.selectUserByOpenIdList(openIdList);
        if (CollectionUtils.isEmpty(userInfoDTOList)) {
            return new ArrayList<>();
        }

        // openId对应的用户信息的map
        Map<String, UserInfoDTO> openIdUserMap = userInfoDTOList.stream().collect(Collectors.toMap(UserInfoDTO::getOpenId, Function.identity(), (x1, x2) -> x2));
        // 用户状态按id最大的一条生效
        Map<String, Integer> openIdStateMap = roomUserEntities.stream()
                .sorted(Comparator.comparingInt(RoomUserEntity::getId).reversed())
                .collect(Collectors.toMap(RoomUserEntity::getOpenId, RoomUserEntity::getUserState, (x1, x2) -> x1));
        // 封装VO返回
        return openIdList.stream()
                .map(x -> new QueryRoomUserVO()
                        .setUserInfo(UserEntityMapper.INSTANCE.toUserInfoVO(openIdUserMap.get(x)))
                        .setUserState(openIdStateMap.get(x))
                ).collect(Collectors.toList());
    }

    /**
     * 加入房间
     * <p>
     * 1. 加入游戏房间
     * 2. 获取房间配置信息
     * 3. 判断是否需要加入team，加入team的类型
     * 4. 查询房间下所有team及每个team的成员
     *
     * @param roomId 房间号
     * @param openId 用户开放id
     * @param teamId 队伍id
     * @return 房间信息
     */
    @Override
    public RoomVO joinRoom(@NotNull Integer roomId, @NotNull String openId, @Nullable Integer teamId) {
        RoomDTO room = joinGameRoom(roomId, openId);
        RoomTypeEnum roomTypeEnum = RoomTypeEnum.getEnumTypeByCode(room.getRoomType());
        // 返回的VO模型初始化room信息
        RoomVO roomVO = new RoomVO().setRoomInfo(room);
        // room无team模式、team模式配置的加入房间时不加入team，返回room信息
        if (!roomTypeEnum.getHasTeam() || !roomTypeEnum.getTeamConfig().getJoin()) {
            return roomVO;
        }
        // 加入team
        TeamDTO team = null == teamId ? teamService.joinTeamByParentId(roomId) : teamService.joinTeam(new JoinTeamQuery(teamId));
        // 统计teamId
        List<Integer> teamIdList = teamService.listTeamByParentId(room.getRoomId()).stream().map(TeamEntity::getTeamId).collect(Collectors.toList());
        // teamId和对应的用户id列表
        return roomVO.setCurrentTeamId(team.getTeamId())
                .setTeamInfo(teamIdList.stream().map(x -> new TeamInfoVO(x, roomUserMapper.selectOpenIdsByRoomId(x))).collect(Collectors.toList()));
    }

    /**
     * 加入游戏的房间
     * <p>
     * 1. 校验房间是否存在、房间是否满员
     * 2. 校验房间是否已经开始游戏
     * 3. 校验用户是否已经在房间内
     * 4. 加入房间（insert t_room_user）
     * 5. 判断加入房间后是否满员
     *
     * @param roomId 房间号
     * @param openId 用户开放id
     * @return 房间信息
     */
    @Override
    public RoomDTO joinGameRoom(@NotNull Integer roomId, @NotNull String openId) {
        RoomEntity room = queryAndCheckRoom(roomId);
        // 如果用户已经在房间，返回加入成功
        if (roomUserMapper.selectByRoomIdOpenId(roomId, openId) > 0) {
            return RoomEntityMapper.INSTANCE.toRoomDTO(room).initRoomTagList();
        }
        // 房间是否满员
        if (room.getFull()) {
            throw new UniversalException(UniversalErrorCode.ROOM_FULL);
        }
        // 已经开始游戏，根据业务决定是否可以加入已经开始的游戏
        if (!RoomStateEnum.READYING.getStateCode().equals(room.getRoomState())) {
            throw new UniversalException(UniversalErrorCode.ROOM_GAMING);
        }
        // 当前该房间的用户openId
        List<String> roomUserList = roomUserMapper.selectOpenIdsByRoomId(roomId);
        if (CollectionUtils.isEmpty(roomUserList)) {
            roomUserList = new ArrayList<>();
        }
        int roomUserCount = roomUserList.size();
        // 用户是否已经在房间
        boolean userInRoom = roomUserList.contains(openId);
        if (userInRoom) {
            // 已经在房间表示是掉线重连，执行对应逻辑
            reconnection(openId, roomId);
        } else {
            // 判断加入后房间是否满员
            if (++roomUserCount >= room.getRoomLimit()) {
                roomMapper.updateRoomFull(roomId, true);
            }
            roomUserMapper.insertOne(new RoomUserEntity(roomId, openId));
        }
        // 不满员且房间未开始游戏，加入成功
        return RoomEntityMapper.INSTANCE.toRoomDTO(room).initRoomTagList();
    }

    /**
     * 掉线重连
     *
     * @param openId 用户开放id
     * @param roomId 房间id
     */
    @Override
    public void reconnection(@NotNull String openId, @NotNull Integer roomId) {
        // 断线重连的逻辑预留方法
    }

    /**
     * 查询房间详细信息：房间信息、玩家列表
     * <p>
     * 1. 校验房间是否存在、用户是否在房间中
     * 2. 查询房间内用户信息列表、房间信息，返回
     *
     * @param queryUserQuery roomId
     * @return 玩家列表、房间信息
     */
    @Override
    public QueryRoomInfoVO queryRoom(@NotNull RoomIdQuery queryUserQuery) {
        RoomEntity roomEntity = queryAndCheckRoom(queryUserQuery.getRoomId());
        List<QueryRoomUserVO> userList = queryUserList(queryUserQuery);
        return new QueryRoomInfoVO(userList, RoomEntityMapper.INSTANCE.toRoomDTO(roomEntity).initRoomTagList());
    }

    /**
     * 注：需要接入MGS房间系统请看此例
     * <p>
     * 创建MGS房间
     *
     * @param qo 创建参数
     * @return 返回结果
     */
    @Override
    public CreateRoomVO createMgsRoom(@NotNull CreateMgsRoomQuery qo) {
        return mgsHttpService.sendPostJsonRequest(MgsHttpConfig.ROOM_CREATE, qo);
    }

    /**
     * 校验用户是否在房间中，不在则直接抛出UniversalException
     *
     * @param roomId 房间id
     * @param openId 用户开放id
     */
    private void checkUserInRoom(@NotNull Integer roomId, @NotNull String openId) {
        if (roomUserMapper.selectByRoomIdOpenId(roomId, openId) == 0) {
            // 不在房间中则不能修改房间名
            throw new UniversalException(UniversalErrorCode.UPDATE_ROOM_ERROR_NOT_IN);
        }
    }

    /**
     * 查询房间信息
     *
     * @param queryRoomQuery roomId
     * @return roomInfo
     */
    @Override
    public RoomDTO queryRoomInfo(@NotNull RoomIdQuery queryRoomQuery) {
        return RoomEntityMapper.INSTANCE.toRoomDTO(queryAndCheckRoom(queryRoomQuery.getRoomId()));
    }

    /**
     * 批量加入房间
     *
     * @param roomId     房间id
     * @param state      状态
     * @param openIdList 用户openId List
     * @return 受影响的行数
     */
    @Override
    public Integer batchJoinRoom(@NotNull Integer roomId, @NotNull Integer state, @NotNull List<String> openIdList) {
        if (CollectionUtils.isEmpty(openIdList)) {
            return 0;
        }
        List<RoomUserEntity> roomUsers = openIdList.stream().distinct().map(x -> new RoomUserEntity(roomId, x).setUserState(state)).collect(Collectors.toList());
        return roomUserMapper.batchInsert(roomUsers);
    }

    /**
     * 注：需要接入MGS房间系统请看此例
     * <p>
     * 批量校验好友关系，会在房间有新用户加入时触发该逻辑
     * <p>
     * 1. 查询房间内所有用户
     * 2. 调用mgs查询当前新加入用户和房间内用户的好友关系
     * 3. 将当前新加入用户和房间内用户的好友关系广播给房间
     *
     * @param roomId 房间id
     */
    @Override
    public void batchCheckFriend(@NotNull Integer roomId) {
        // 房间内所有用户
        List<String> openIdList = new ArrayList<>(roomUserMapper.selectOpenIdsByRoomId(roomId));
        if (CollectionUtils.isEmpty(openIdList)) {
            return;
        }
        // 当前用户信息
        List<UserInfoEntity> userList = userMapper.selectByOpenIdList(openIdList);
        userList.forEach(user -> {
            // 检查当前用户和房间内用户的好友关系
            Map<String, Boolean> map = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.FRIEND_CHECK, new BatchCheckFriendQuery(openIdList, user.getOpenCode(), user.getOpenId()));
            log.info("openId[{}] mgs batch check friend: {}", user.getOpenId(), map);
            // 发送给房间内用户
            WebSocketServer.sendMessage(map, MessageActionEnum.BATCH_CHECK_FRIEND.getAction(), user.getOpenId());
        });
    }
}
