package com.mgs.cloud.game.server.websocket.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * @author guozheng.zhao
 * @date 2021/3/10
 */
@ToString
@Data
@ApiModel("webSocket传参")
public class MessageParamVO {

    @NotNull(message = "action不能为空")
    @ApiModelProperty("执行的动作")
    private String action;

    @ApiModelProperty("接口的入参")
    private Object param;

    @ApiModelProperty("请求标识码")
    private Integer requestCode;

}
