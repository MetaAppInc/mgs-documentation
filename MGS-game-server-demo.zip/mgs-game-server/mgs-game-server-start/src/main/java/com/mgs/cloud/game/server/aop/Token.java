package com.mgs.cloud.game.server.aop;

import com.mgs.cloud.game.server.model.enums.user.TokenInvalidConfig;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 用于标记需要校验Token有效性的接口
 * <p>
 * 被标记了Token注解的方法：
 * 1. 会在执行前校验gameToken的有效性
 * 2. gameToken校验不通过返回401
 * 3. 将当前请求的用户的openId放到UserOpenIdInfo中，在方法执行结束之前均可以通过UserOpenIdInfo.getOpenId获取
 *
 * @author guozheng.zhao
 * @date 2021/2/5
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Token {

    /**
     * Token类型，默认是OpenUser
     *
     * @return tokenType
     */
    TokenInvalidConfig tokenType() default TokenInvalidConfig.TOKEN_OPEN_USER;

}
