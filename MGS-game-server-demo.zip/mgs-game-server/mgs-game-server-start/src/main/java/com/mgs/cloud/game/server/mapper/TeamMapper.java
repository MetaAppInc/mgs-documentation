package com.mgs.cloud.game.server.mapper;

import com.mgs.api.game.server.model.dto.team.TeamDTO;
import com.mgs.cloud.game.server.model.entity.team.TeamEntity;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@Mapper
public interface TeamMapper {

    /**
     * 添加一条team数据
     *
     * @param team 队伍信息
     * @return 受影响的行数
     */
    @Insert("insert into `t_team`(`teamId`, `parentId`, `chatScope`, `voiceScope`) " +
            "values(#{team.teamId}, #{team.parentId}, #{team.chatScope}, #{team.voiceScope})")
    int insertOne(@Param("team") TeamDTO team);

    /**
     * 根据teamId查询队伍信息
     *
     * @param teamId 队伍id，即该队伍在t_room表对应的roomId
     * @return 队伍信息
     */
    @Select("select * from `t_team` where teamId = #{teamId}")
    TeamEntity queryByTeamId(@Param("teamId") Integer teamId);

    /**
     * 根据parentId查询队伍信息
     *
     * @param parentId 房间id，即该队伍在t_room表对应的roomId
     * @return 队伍信息
     */
    @Select("select * from `t_team` where parentId = #{parentId}")
    List<TeamEntity> listByParentId(@Param("parentId") Integer parentId);

    /**
     * 根据teamId删除队伍信息
     *
     * @param teamId 队伍id
     * @return 受影响的行数
     */
    @Delete("delete from `t_team` where teamId = #{teamId}")
    int deleteByTeamId(@Param("teamId") Integer teamId);
}
