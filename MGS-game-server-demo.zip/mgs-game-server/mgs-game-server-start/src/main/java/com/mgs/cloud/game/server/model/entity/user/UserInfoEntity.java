package com.mgs.cloud.game.server.model.entity.user;

import com.mgs.api.game.server.model.vo.mgs.user.QueryOpenUserVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@Data
@ApiModel("用户信息数据库映射实体")
@Accessors(chain = true)
public class UserInfoEntity implements Serializable {

    private static final long serialVersionUID = -4827895237663204220L;

    @ApiModelProperty("用户ID")
    private String openId;

    @ApiModelProperty("开放用户CODE")
    private String openCode;

    @ApiModelProperty("用户头像")
    private String avatar;

    @ApiModelProperty("用户昵称")
    private String nickname;

    /**
     * Bean Equals - QueryOpenUserVO
     *
     * @param vo 用户信息VO
     * @return 是否相等
     */
    public boolean beanEqual(@NotNull QueryOpenUserVO vo) {
        return Objects.equals(vo.getAvatar(), getAvatar()) && Objects.equals(vo.getNickname(), getNickname());
    }
}
