package com.mgs.cloud.game.server.config.mgs;

import lombok.Data;
import lombok.ToString;

/**
 * @author guozheng.zhao
 * @date 2021/3/19
 */
@ToString
@Data
public class MgsConfigItem {

    /**
     * key
     */
    private String appKey;

    /**
     * app密钥
     */
    private String appSecret;

    /**
     * mgs调用域名
     */
    private String domain;

}
