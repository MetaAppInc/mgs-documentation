package com.mgs.cloud.game.server.controller;

import com.mgs.api.game.server.api.TeamApi;
import com.mgs.api.game.server.model.dto.team.TeamDTO;
import com.mgs.api.game.server.model.qo.team.CreateTeamQuery;
import com.mgs.api.game.server.model.qo.team.JoinTeamQuery;
import com.mgs.api.game.server.model.qo.team.TeamIdQuery;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.api.game.server.model.vo.team.QueryTeamInfoVO;
import com.mgs.cloud.game.server.aop.Token;
import com.mgs.cloud.game.server.service.ITeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@RestController
public class TeamController implements TeamApi {

    @Autowired
    ITeamService teamService;

    @Override
    @Token
    public Response<List<TeamDTO>> createTeam(@RequestBody @Valid CreateTeamQuery create) {
        return Response.execute(res -> res.setData(teamService.createTeam(create)));
    }

    @Override
    @Token
    public Response<TeamDTO> joinTeam(@RequestBody JoinTeamQuery join) {
        return Response.execute(res -> res.setData(teamService.joinTeam(join)));
    }

    @Override
    @Token
    public Response<Boolean> leaveTeam(@RequestBody TeamIdQuery leave) {
        return Response.execute(res -> res.setData(teamService.leaveTeam(leave)));
    }

    @Override
    @Token
    public Response<Boolean> leaveTeamAndFanout(@RequestBody TeamIdQuery leave) {
        return Response.execute(res -> res.setData(teamService.leaveTeamAndFanout(leave)));
    }

    @Override
    @Token
    public Response<Boolean> destroyTeam(@RequestBody TeamIdQuery destroy) {
        return Response.execute(res -> res.setData(teamService.destroyTeam(destroy)));
    }

    @Override
    @Token
    public Response<QueryTeamInfoVO> queryTeam(@RequestBody TeamIdQuery query) {
        return Response.execute(res -> res.setData(teamService.queryTeam(query)));
    }

    @Override
    public Response<String> teamConfig(@RequestParam("chatScope") Integer chatScope, @RequestParam("voiceScope") Integer voiceScope) {
        return Response.execute(res -> res.setData(teamService.updateConfig(chatScope, voiceScope)));
    }
}
