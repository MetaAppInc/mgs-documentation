package com.mgs.cloud.game.server.model.entity.team;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@Data
@ApiModel("队伍表实体")
@ToString
public class TeamEntity implements Serializable {

    private static final long serialVersionUID = -5507728943346696926L;

    @ApiModelProperty("聊天室能力范围: 0无,1Room,2Team")
    private Integer chatScope;

    @ApiModelProperty("开麦能力范围: 0无,1Room,2Team")
    private Integer voiceScope;

    @ApiModelProperty("房间的id，表示该team在哪个房间下")
    private Integer parentId;

    @ApiModelProperty("队伍id")
    private Integer teamId;

}
