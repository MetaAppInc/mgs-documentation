package com.mgs.cloud.game.server.controller;

import com.mgs.api.game.server.api.UserApi;
import com.mgs.api.game.server.model.qo.mgs.user.QueryOpenUserQuery;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.api.game.server.model.vo.user.UserLoginVO;
import com.mgs.cloud.game.server.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@RestController
public class UserController implements UserApi {

    @Autowired
    IUserService userService;

    @Override
    public Response<UserLoginVO> login(@RequestBody QueryOpenUserQuery qo) {
        return Response.execute(res -> res.setData(userService.login(qo)));
    }
}
