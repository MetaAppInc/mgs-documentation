package com.mgs.cloud.game.server.service;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.dto.team.TeamDTO;
import com.mgs.api.game.server.model.enums.team.TeamConfigEnum;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import com.mgs.api.game.server.model.qo.team.CreateTeamQuery;
import com.mgs.api.game.server.model.qo.team.JoinTeamQuery;
import com.mgs.api.game.server.model.qo.team.TeamIdQuery;
import com.mgs.api.game.server.model.vo.team.QueryTeamInfoVO;
import com.mgs.cloud.game.server.model.entity.team.TeamEntity;
import lombok.SneakyThrows;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.Field;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/14
 */
public interface ITeamService {

    /**
     * 创建队伍
     *
     * @param createTeam 队伍设置信息
     * @return 队伍信息
     */
    List<TeamDTO> createTeam(@NotNull CreateTeamQuery createTeam);

    /**
     * 加入队伍
     *
     * @param joinTeam 队伍id、密码
     * @return 队伍信息
     */
    TeamDTO joinTeam(@NotNull JoinTeamQuery joinTeam);

    /**
     * 根据父房间号加入队伍
     *
     * @param parentId roomId
     * @return 是否加入成功
     */
    TeamDTO joinTeamByParentId(@NotNull Integer parentId);

    /**
     * 离开队伍
     *
     * @param leave 队伍id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    Boolean leaveTeam(@NotNull TeamIdQuery leave);

    /**
     * 离开队伍，并广播给房间内其他人
     *
     * @param leave 队伍id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    Boolean leaveTeamAndFanout(@NotNull TeamIdQuery leave);

    /**
     * 销毁队伍
     *
     * @param destroy 队伍id
     * @return 销毁成功 return {@code true}, 销毁失败 return {@code false}
     */
    Boolean destroyTeam(@NotNull TeamIdQuery destroy);

    /**
     * 根据roomId查询team
     *
     * @param parentId roomId
     * @return 该roomId下的team
     */
    List<TeamEntity> listTeamByParentId(@NotNull Integer parentId);

    /**
     * 同步team状态
     *
     * @param parentId 父房间id
     * @param state    状态
     */
    void syncTeamState(@NotNull Integer parentId, @NotNull Integer state);

    /**
     * 查询队伍详细信息，小队成员信息、小队信息
     *
     * @param query 队伍id
     * @return 小队成员信息、小队信息
     */
    QueryTeamInfoVO queryTeam(@NotNull TeamIdQuery query);

    /**
     * 根据父房间id查询队伍信息
     *
     * @param parentId 父房间id
     * @return 该房间下的所有队伍信息
     */
    List<QueryTeamInfoVO> listTeamByRoomId(@NotNull Integer parentId);

    /**
     * 根据父房间id，将房间内用户随机加入到team
     *
     * @param parentId 父房间id
     */
    void randomJoinTeamByRoomId(@NotNull Integer parentId);

    /**
     * 同步team到mgs
     *
     * @param teamId 队伍id
     */
    void syncTeamUserToMgs(@NotNull Integer teamId);

    /**
     * 根据父房间id离开房间
     *
     * @param parentId 父房间id
     * @param openId   用户id
     */
    void leaveTeamByParentId(@NotNull Integer parentId, @NotNull String openId);

    /**
     * 切换team
     *
     * @param teamId teamId
     * @return 切换成功 return {@code true}, 切换失败 return {@code false}
     */
    TeamDTO switchTeam(@NotNull Integer teamId);

    /**
     * 同步mgs队伍成员
     *
     * @param roomDTO            房间信息
     * @param syncRoomStateQuery 同步状态
     */
    void syncTeamMember(@NotNull RoomDTO roomDTO, @NotNull SyncRoomStateQuery syncRoomStateQuery);

    /**
     * 修改队伍config设置
     *
     * @param chatScope  聊天室能力范围: 0无,1Room,2Team
     * @param voiceScope 开麦能力范围: 0无,1Room,2Team
     * @return 修改后的配置String
     */
    @SneakyThrows
    default String updateConfig(Integer chatScope, Integer voiceScope) {
        // 修改team配置
        TeamConfigEnum.JOIN_WHEN_GAME_START.setVoiceScope(voiceScope);
        TeamConfigEnum.JOIN_WHEN_GAME_START.setChatScope(chatScope);
        // 返回teamConfig所有属性
        StringBuilder builder = new StringBuilder();
        for (Field declaredField : TeamConfigEnum.JOIN_WHEN_GAME_START.getClass().getDeclaredFields()) {
            declaredField.setAccessible(true);
            builder.append(declaredField.getName()).append("=").append(declaredField.get(TeamConfigEnum.JOIN_WHEN_GAME_START)).append(",");
        }
        return builder.deleteCharAt(builder.length() - 1).toString();
    }
}
