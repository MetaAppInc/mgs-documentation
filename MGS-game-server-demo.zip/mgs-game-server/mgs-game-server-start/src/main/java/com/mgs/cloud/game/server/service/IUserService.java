package com.mgs.cloud.game.server.service;

import com.mgs.api.game.server.model.dto.user.UserInfoDTO;
import com.mgs.api.game.server.model.dto.user.UserTokenDTO;
import com.mgs.cloud.game.server.model.enums.user.TokenInvalidConfig;
import com.mgs.api.game.server.model.qo.mgs.user.QueryOpenUserQuery;
import com.mgs.api.game.server.model.vo.user.UserLoginVO;
import com.mgs.cloud.game.server.model.entity.user.UserTokenEntity;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
public interface IUserService {

    /**
     * 登录
     *
     * @param qo openId、openCode
     * @return 用户信息、token信息
     */
    UserLoginVO login(@NotNull QueryOpenUserQuery qo);

    /**
     * 创建OpenUser的Token
     *
     * @param openId             开放用户id
     * @param tokenInvalidConfig tokenConfig
     * @return token信息
     */
    UserTokenDTO createOpenUserToken(@NotNull String openId, @NotNull TokenInvalidConfig tokenInvalidConfig);

    /**
     * 根据token查询UserToken
     *
     * @param token token
     * @return token信息
     */
    UserTokenEntity selectUserTokenByToken(@NotNull String token);

    /**
     * 根据openId List查询用户信息
     *
     * @param openIdList 用户id List
     * @return 对应的用户信息
     */
    List<UserInfoDTO> selectUserByOpenIdList(@NotNull List<String> openIdList);

    /**
     * 给指定openId、token，重新计算有效期
     *
     * @param openId 开放用户id
     * @param token  token
     */
    void continuationInvalidTime(@NotNull String openId, @NotNull String token);

    /**
     * 校验token的有效性
     * 校验成功return {@code true}, 校验失败 return {@code false}
     *
     * @param tokenValue token值
     * @param config     token使用的配置
     * @return 校验成功return {@code true}, 校验失败 return {@code false}
     */
    boolean checkToken(@NotNull String tokenValue, @NotNull TokenInvalidConfig config);
}
