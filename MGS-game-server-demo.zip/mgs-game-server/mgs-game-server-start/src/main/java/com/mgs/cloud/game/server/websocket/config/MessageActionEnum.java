package com.mgs.cloud.game.server.websocket.config;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 服务端和客户端websocket交互指令
 *
 * @author guozheng.zhao
 * @date 2021/3/22
 */
@AllArgsConstructor
public enum MessageActionEnum {
    /**
     * ROOM
     */
    // 查询房间信息
    ROOM_QUERY("queryRoom"),
    // 同步房间信息
    ROOM_SYNC("syncRoom"),
    // 广播房间状态使用的action
    ROOM_SYNC_STATE("syncState"),
    // 离开房间
    ROOM_LEAVE("leaveRoom"),
    // 批量检查房间内好友关系
    BATCH_CHECK_FRIEND("batchCheckFriend"),

    /**
     * TEAM
     */
    // 查询队伍信息
    TEAM_QUERY("queryTeam"),
    // 创建队伍
    TEAM_CREATE("createTeam"),
    // 加入队伍
    TEAM_JOIN("joinTeam"),
    // 离开队伍
    TEAM_LEAVE("leaveTeam"),
    // 广播随机加入team使用的action
    TEAM_RANDOM_JOIN("randomJoinTeam"),
    // 切换team
    TEAM_SWITCH("switchTeam"),

    // 通知客户端连接不被允许
    COLLECTION_NOT_ALLOWED("connectionNotAllowed"),
    ;

    /**
     * websocket交互指令
     */
    @Getter
    private String action;
}
