package com.mgs.cloud.game.server.websocket;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.mgs.api.game.server.model.enums.mgs.MgsHttpConfig;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;
import com.mgs.api.game.server.model.qo.mgs.user.RemoveUserQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.cloud.game.server.config.AppKeyInfo;
import com.mgs.cloud.game.server.config.UserOpenIdInfo;
import com.mgs.cloud.game.server.config.executor.DelayQueueManager;
import com.mgs.cloud.game.server.config.executor.DelayRoomTask;
import com.mgs.cloud.game.server.mapper.RoomMapper;
import com.mgs.cloud.game.server.mapper.RoomUserMapper;
import com.mgs.cloud.game.server.model.entity.team.TeamEntity;
import com.mgs.cloud.game.server.service.IMgsHttpService;
import com.mgs.cloud.game.server.service.IRoomService;
import com.mgs.cloud.game.server.service.ITeamService;
import com.mgs.cloud.game.server.utils.context.ApplicationContextUtil;
import com.mgs.cloud.game.server.websocket.config.MessageActionEnum;
import com.mgs.cloud.game.server.websocket.config.MessageMethodEnum;
import com.mgs.cloud.game.server.websocket.model.MessageParamVO;
import com.mgs.cloud.game.server.websocket.model.MessageResponseVO;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * 用于和客户端用webSocket协议连接
 * <p>
 * web调试工具：mgs-game-server/mgs-game-server-start/src/test/web/websocket.html
 *
 * @author guozheng.zhao
 * @date 2021/3/8
 */
@Slf4j
@ServerEndpoint("/connectServer/{roomId}")
@Component
public class WebSocketServer {

    /**
     * 静态变量，用来记录当前在线连接数。
     */
    private static AtomicInteger onlineCount = new AtomicInteger(0);

    /**
     * 静态变量，用来存放每个客户端对应的MyWebSocket对象的Map。
     */
    private static final ConcurrentHashMap<String, WebSocketServer> WEB_SOCKET_MAP = new ConcurrentHashMap<>();

    /**
     * 静态变量，用来存放每个用户连接断开时离开房间的任务
     */
    private static ConcurrentHashMap<String, DelayRoomTask<?>> disconnectTaskMap = new ConcurrentHashMap<>();

    /**
     * 服务端向客户端通讯携带的请求码为-1
     */
    public static final Integer DEFAULT_REQUEST_CODE = -1;

    /**
     * 与某个客户端的连接会话，需要通过它来给客户端发送数据。
     */
    private Session session;

    /**
     * 接收openId
     */
    private String openId;

    /**
     * 接收房间id
     */
    @Getter
    private Integer roomId;

    /**
     * 当前用户请求的appKey
     */
    @Getter
    private String appKey;

    /**
     * roomId和openId组成的离开房间延迟队列的key
     *
     * @return string
     */
    private String getRoomIdOpenIdKey() {
        return roomId + ":" + openId;
    }

    /**
     * 连接建立成功调用的方法
     *
     * @param session 当前用户会话
     * @param roomId  房间id
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("roomId") Integer roomId) {
        this.openId = UserOpenIdInfo.getNullableOpenId();
        this.appKey = AppKeyInfo.getAppKey();
        try {
            // 如果用户不合法，关闭连接
            if (Strings.isNullOrEmpty(this.openId)) {
                session.close();
                return;
            }
            // 如果已经有存在的连接，先断开之前的连接
            if (WEB_SOCKET_MAP.containsKey(this.openId)) {
                WEB_SOCKET_MAP.get(this.openId).session.close();
            }
        } catch (IOException e) {
            log.error("session close error: {}", e.getMessage(), e);
            return;
        }
        // 初始化当前实例的session、openId、roomId
        this.session = session;
        this.roomId = roomId;
        // 登录时删除用户离开房间的逻辑
        String key = getRoomIdOpenIdKey();
        if (disconnectTaskMap.containsKey(key) && DelayQueueManager.getInstance().removeTask(disconnectTaskMap.get(key))) {
            disconnectTaskMap.remove(key);
        }
        // 将用户加入到webSocketMap中
        WEB_SOCKET_MAP.put(this.openId, this);
        log.info("用户[{}]连接, 当前在线人数: {}", this.openId, increment());
        UserOpenIdInfo.setOpenId(this.openId);
        // 校验房间和用户
        if (checkRoomAndUser(roomId, this.openId)) {
            return;
        }
        // 批量检查好友关系
        invokeMessageMethod(MessageMethodEnum.BATCH_CHECK_FRIEND, roomId, DEFAULT_REQUEST_CODE);
        // 加入房间通过房间信息给房间内所有用户
        fanoutRoom();
        fanoutTeam();
    }

    /**
     * 校验房间是否已经销毁
     * 校验用户是否已经退出
     *
     * @param roomId 房间id
     * @param openId 用户开放id
     * @return 本次连接是否有效，无效 return {@code true}, 有效 return {@code false}
     */
    private Boolean checkRoomAndUser(Integer roomId, String openId) {
        RoomMapper roomMapper = ApplicationContextUtil.getBean(RoomMapper.class);
        if (null == roomMapper.selectByRoomId(roomId)) {
            // 房间已不存在，通知客户端
            sendMessage(new MessageResponseVO()
                    .setRequestCode(DEFAULT_REQUEST_CODE)
                    .setAction(MessageActionEnum.COLLECTION_NOT_ALLOWED.getAction())
                    .setResponse(Response.transformByErrorCode(UniversalErrorCode.ROOM_DESTROYED)));
            return true;
        }
        RoomUserMapper roomUserMapper = ApplicationContextUtil.getBean(RoomUserMapper.class);
        if (0 == roomUserMapper.selectByRoomIdOpenId(roomId, openId)) {
            // 用户已经退出房间
            sendMessage(new MessageResponseVO()
                    .setRequestCode(DEFAULT_REQUEST_CODE)
                    .setAction(MessageActionEnum.COLLECTION_NOT_ALLOWED.getAction())
                    .setResponse(Response.transformByErrorCode(UniversalErrorCode.ROOM_LEAVED)));
            return true;
        }
        return false;
    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        if (Strings.isNullOrEmpty(this.openId)) {
            return;
        }
        // 从webSocketMap中删除
        WEB_SOCKET_MAP.remove(this.openId);
        log.info("用户[{}]退出, 当前在线人数为: {}", this.openId, decrement());
        IRoomService roomService = ApplicationContextUtil.getBean(IRoomService.class);
        ITeamService teamService = ApplicationContextUtil.getBean(ITeamService.class);
        IMgsHttpService mgsHttpService = ApplicationContextUtil.getBean(IMgsHttpService.class);
        // 加入到延迟队列中，30s后调用用户离开房间的逻辑
        DelayRoomTask<?> task = DelayQueueManager.getInstance().put(() -> {
            UserOpenIdInfo.setOpenId(this.openId);
            AppKeyInfo.setAppKey(this.appKey);
            // 退出房间同步退出mgs team
            List<TeamEntity> teamEntities = teamService.listTeamByParentId(this.roomId);
            teamEntities.forEach(x -> {
                Boolean removeTeam = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.TEAM_REMOVE, new RemoveUserQuery(this.openId, x.getTeamId().toString()));
                log.info("mgs team[{}] remove member: {}", x.getTeamId(), removeTeam);
            });
            // 退出房间同步mgs
            Boolean removeRoom = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.ROOM_REMOVE, new RemoveUserQuery(this.openId, this.roomId.toString()));
            log.info("mgs room remove member: {}", removeRoom);
            // 离开房间
            Response<Boolean> response = Response.execute(res -> res.setData(roomService.leaveRoom(this.roomId, this.openId)));
            log.info("openId[{}] leave room[{}]: {}", this.openId, this.roomId, response);
            // 退出房间同步房间信息给房间内所有用户
            MessageResponseVO roomVO = invokeMessageMethod(MessageMethodEnum.ROOM_QUERY, JSON.toJSONString(new RoomIdQuery(this.roomId)), DEFAULT_REQUEST_CODE);
            // 离开房间后查询，状态码不为200的话不广播
            if (UniversalErrorCode.OK.getCode().equals(roomVO.getResponse().getCode())) {
                fanoutMessage(roomVO, this.roomId);
            }
            MessageResponseVO teamVO = invokeMessageMethod(MessageMethodEnum.TEAM_QUERY, JSON.toJSONString(this.roomId), DEFAULT_REQUEST_CODE);
            // 离开队伍后查询，状态码不为200的话不广播
            if (teamVO.getResponse().getData() != null && UniversalErrorCode.OK.getCode().equals(teamVO.getResponse().getCode())) {
                fanoutMessage(teamVO, this.roomId);
            }
            // 方法执行结束后删除延时队列任务
            disconnectTaskMap.remove(getRoomIdOpenIdKey());
        }, 30, TimeUnit.SECONDS);
        disconnectTaskMap.put(getRoomIdOpenIdKey(), task);
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message) {
        log.info("openId[{}] on message: {}", this.openId, message);
        if (Strings.isNullOrEmpty(message)) {
            return;
        }
        // 解析发送的报文
        MessageParamVO paramVO = JSON.parseObject(message, MessageParamVO.class);
        // 获取执行的方法配置
        MessageMethodEnum methodEnum = MessageMethodEnum.get(paramVO.getAction());
        // 指令无对应配置，直接返回
        if (null == methodEnum) {
            sendMessage(new MessageResponseVO()
                    .setAction(paramVO.getAction())
                    .setRequestCode(paramVO.getRequestCode()));
            return;
        }

        // 将返回值推送回去
        sendMessage(invokeMessageMethod(methodEnum, paramVO.getParam(), paramVO.getRequestCode()));
        if (methodEnum.isFanoutRoom()) {
            // 将房间最新信息同步给房间内所有用户
            fanoutRoom();
        }
        if (methodEnum.isFanoutTeam()) {
            // 将队伍最新信息同步给房间内所有用户
            fanoutTeam();
        }
    }

    /**
     * 将当前房间的最新信息同步给房间内所有用户
     */
    public void fanoutRoom() {
        fanoutMessage(invokeMessageMethod(MessageMethodEnum.ROOM_QUERY, JSON.toJSONString(new RoomIdQuery(this.roomId)), DEFAULT_REQUEST_CODE), this.roomId);
    }

    /**
     * 将当前队伍的最新信息同步给房间内所有用户
     */
    public void fanoutTeam() {
        MessageResponseVO responseVO = invokeMessageMethod(MessageMethodEnum.TEAM_QUERY, JSON.toJSONString(this.roomId), DEFAULT_REQUEST_CODE);
        if (responseVO.getResponse().getData() != null) {
            fanoutMessage(responseVO, this.roomId);
        }
    }

    /**
     * 执行MessageMethodEnum配置的方法
     * 1. 根据methodEnum的方法名、参数类型反射获取方法
     * 2. paramVO转成方法入参的Class类型
     * 3. 执行方法前将openId加到UserOpenIdInfo中
     * 4. 执行方法，获取返回值的Response
     * 5. return
     *
     * @param methodEnum  执行方法配置
     * @param reqParam    入参
     * @param requestCode 请求标识码
     * @return 返回推送给客户端的VO
     */
    public MessageResponseVO invokeMessageMethod(@NotNull MessageMethodEnum methodEnum, @NotNull Object reqParam, @NotNull Integer requestCode) {
        // 执行方法的类Class
        Class<?> clazz = methodEnum.getClazz();
        // 方法入参Class
        Class<?> paramClass = methodEnum.getParamClass();
        String action = methodEnum.getAction();
        MessageResponseVO responseVO = new MessageResponseVO().setAction(action).setRequestCode(requestCode);
        try {
            // 获取执行的目标方法
            Method method = clazz.getDeclaredMethod(methodEnum.getMethod(), paramClass);
            // 方法入参
            Object param = JSON.parseObject(String.valueOf(reqParam), paramClass);
            // 执行方法前将用户openId和appKey set到ThreadLocal
            UserOpenIdInfo.setOpenId(this.openId);
            AppKeyInfo.setAppKey(this.appKey);
            // 方法执行结果set到Response
            responseVO.setResponse(Response.execute(res -> {
                try {
                    res.setData(method.invoke(ApplicationContextUtil.getBean(clazz), param));
                } catch (IllegalAccessException e) {
                    log.error("[{}] illegal access error: {}", action, e.getMessage(), e);
                } catch (InvocationTargetException e) {
                    if (e.getTargetException() instanceof UniversalException) {
                        // 业务异常抛给Response处理
                        throw (UniversalException) e.getTargetException();
                    }
                    log.error("[{}] invocation target error: {}", action, e.getMessage(), e);
                }
            }));
        } catch (NoSuchMethodException e) {
            log.error("[{}] no such method error: {}", action, e.getMessage(), e);
        }
        return responseVO;
    }

    /**
     * 当连接发生异常时调用的方法
     *
     * @param error 异常信息
     */
    @OnError
    public void onError(Throwable error) {
        log.error("openId[{}] error: {}", this.openId, error.getMessage(), error);
    }

    /**
     * 服务器主动推送
     *
     * @param message 推送的统一Bean格式数据
     */
    public void sendMessage(@NotNull MessageResponseVO message) {
        // 返回状态码不为200 || 返回data不为null，推送
        if (!message.getResponse().getCode().equals(UniversalErrorCode.OK.getCode()) || Objects.nonNull(message.getResponse().getData())) {
            sendMessage(JSON.toJSONString(message));
        }
    }

    /**
     * 服务器主动推送
     *
     * @param message 推送的消息
     */
    public void sendMessage(@NotNull String message) {
        synchronized (WEB_SOCKET_MAP) {
            try {
                this.session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                log.error("send message error: {}", e.getMessage(), e);
            }
        }
    }

    /**
     * 发送自定义消息
     *
     * @param message 发送的消息
     * @param openId  用户openId
     */
    public static void sendMessage(@NotNull MessageResponseVO message, @NotNull String openId) {
        log.info("send to [{}], message: {}", openId, message);
        if (!Strings.isNullOrEmpty(openId) && WEB_SOCKET_MAP.containsKey(openId)) {
            WEB_SOCKET_MAP.get(openId).sendMessage(JSON.toJSONString(message));
        }
    }

    /**
     * 发送自定义消息
     *
     * @param responseData response的data数据
     * @param action       发送消息的action
     * @param openId       用户openId
     */
    public static void sendMessage(@NotNull Object responseData, @NotNull String action, @NotNull String openId) {
        MessageResponseVO message = new MessageResponseVO()
                .setAction(action)
                .setRequestCode(DEFAULT_REQUEST_CODE)
                .setResponse(Response.execute(res -> res.setData(responseData)));
        sendMessage(message, openId);
    }

    /**
     * 广播消息
     *
     * @param responseData response的data数据
     * @param action       发送消息的action
     * @param roomId       房间id
     */
    public static void fanoutMessage(@NotNull Object responseData, @NotNull String action, @NotNull Integer roomId) {
        MessageResponseVO message = new MessageResponseVO()
                .setAction(action)
                .setRequestCode(DEFAULT_REQUEST_CODE)
                .setResponse(Response.execute(res -> res.setData(responseData)));
        fanoutMessage(message, roomId);
    }

    /**
     * 向一个房间内所有用户发送消息
     *
     * @param message 发送的消息
     * @param roomId  房间id
     */
    public static void fanoutMessage(@NotNull MessageResponseVO message, @NotNull Integer roomId) {
        // 获取房间内所有用户的连接
        List<WebSocketServer> servers = listByRoomId(roomId);
        if (CollectionUtils.isEmpty(servers)) {
            return;
        }
        // 发送的消息转String
        String sendStr = JSON.toJSONString(message);
        log.info("fanout [{}], fanout number[{}], message: {}", roomId, servers.size(), sendStr);
        // 给每个用户发送消息
        servers.forEach(item -> item.sendMessage(sendStr));
    }

    /**
     * 根据房间号获取websocket连接集合
     *
     * @param roomId 房间号
     * @return 房间内所有用户的连接
     */
    public static List<WebSocketServer> listByRoomId(@NotNull Integer roomId) {
        Map<Integer, List<WebSocketServer>> roomIdMap = WEB_SOCKET_MAP.values().stream()
                .collect(Collectors.groupingBy(WebSocketServer::getRoomId));
        if (!roomIdMap.containsKey(roomId)) {
            return new ArrayList<>();
        }
        return roomIdMap.get(roomId);
    }

    /**
     * 获取当前在线用户数
     *
     * @return 当前在线用户数
     */
    public static synchronized int getOnlineCount() {
        return onlineCount.get();
    }

    /**
     * 当前在线用户数自增
     *
     * @return 自增后的用户数
     */
    public static synchronized int increment() {
        return WebSocketServer.onlineCount.incrementAndGet();
    }

    /**
     * 当前在线用户数自减
     *
     * @return 自减后的用户数
     */
    public static synchronized int decrement() {
        return WebSocketServer.onlineCount.decrementAndGet();
    }
}
