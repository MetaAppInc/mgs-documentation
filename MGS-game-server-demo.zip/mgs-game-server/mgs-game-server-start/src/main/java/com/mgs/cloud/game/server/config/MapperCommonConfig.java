package com.mgs.cloud.game.server.config;


import org.mapstruct.MapperConfig;
import org.mapstruct.ReportingPolicy;

/**
 * 未配置映射策略时，忽略
 *
 * @author guozheng.zhao
 * @date 2021/2/5
 */
@MapperConfig(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MapperCommonConfig {
}
