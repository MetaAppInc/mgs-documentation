package com.mgs.cloud.game.server.config.executor;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.*;

/**
 * 修改房间信息延时队列
 *
 * @author guozheng.zhao
 * @date 2021/3/9
 */
@Slf4j
public class DelayQueueManager {

    /**
     * 执行任务的线程池
     */
    private static final ThreadPoolExecutor THREAD_POOL_EXECUTOR =
            new ThreadPoolExecutor(
                    4,
                    4,
                    10,
                    TimeUnit.SECONDS,
                    new LinkedBlockingQueue<>(1024),
                    new ThreadPoolExecutor.CallerRunsPolicy());

    /**
     * 延时队列
     */
    private DelayQueue<DelayRoomTask<?>> delayQueue;

    /**
     * 单例
     */
    private static DelayQueueManager instance = new DelayQueueManager();

    /**
     * 结束标记
     */
    private static volatile boolean endTag = true;

    /**
     * 修改endTag的标记
     *
     * @param endTag 修改后的标记
     */
    public static void changeEndTag(boolean endTag) {
        DelayQueueManager.endTag = endTag;
    }

    /**
     * 构造
     */
    private DelayQueueManager() {
        delayQueue = new DelayQueue<>();
        init();
    }

    /**
     * 获取实例
     *
     * @return instance
     */
    public static DelayQueueManager getInstance() {
        return instance;
    }

    /**
     * 初始化
     */
    private void init() {
        // 开一个线程监视延迟队列
        ThreadFactory namedThreadFactory = new ThreadFactoryBuilder()
                .setNameFormat("delay-monitor-%d").build();
        ExecutorService singleThreadPool = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(1024), namedThreadFactory, new ThreadPoolExecutor.AbortPolicy());

        // 延迟执行队列中的Task
        singleThreadPool.execute(this::execute);
    }

    /**
     * 执行
     */
    private void execute() {
        while (endTag) {
            log.info("当前所有存活线程数量:" + Thread.getAllStackTraces().size());
            log.info("当前ROOM延时任务数量:" + delayQueue.size());
            try {
                // 从延时队列中获取任务 提交到线程池执行task
                THREAD_POOL_EXECUTOR.execute(delayQueue.take().getTask());
            } catch (Exception e) {
                log.error("DelayQueueManager execute error: {}", e.getMessage(), e);
            }
        }
    }

    /**
     * 添加任务
     *
     * @param task 延时任务
     * @param time 延时时间
     * @param unit 时间单位
     */
    public DelayRoomTask<?> put(@NotNull Runnable task, long time, @NotNull TimeUnit unit) {
        // 获取延时时间
        long timeout = System.currentTimeMillis() + unit.toMillis(time);
        // 将任务封装成实现Delayed接口的消息体
        DelayRoomTask<?> delayRoomTask = new DelayRoomTask<>(timeout, task);
        // 将消息体放到延时队列中
        delayQueue.put(delayRoomTask);
        return delayRoomTask;
    }

    /**
     * 删除任务
     *
     * @param task 任务
     * @return 是否删除成功
     */
    public boolean removeTask(@NotNull DelayRoomTask<?> task) {
        return delayQueue.remove(task);
    }
}

