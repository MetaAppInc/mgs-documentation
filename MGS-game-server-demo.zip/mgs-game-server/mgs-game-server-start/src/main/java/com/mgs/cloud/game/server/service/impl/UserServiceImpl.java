package com.mgs.cloud.game.server.service.impl;

import com.google.common.base.Strings;
import com.mgs.api.game.server.model.dto.user.UserInfoDTO;
import com.mgs.api.game.server.model.dto.user.UserTokenDTO;
import com.mgs.api.game.server.model.enums.mgs.MgsHttpConfig;
import com.mgs.api.game.server.util.TimeUtil;
import com.mgs.cloud.game.server.config.UserOpenIdInfo;
import com.mgs.cloud.game.server.model.enums.user.TokenInvalidConfig;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;
import com.mgs.api.game.server.model.qo.mgs.user.QueryOpenUserQuery;
import com.mgs.api.game.server.model.vo.mgs.user.QueryOpenUserVO;
import com.mgs.api.game.server.model.vo.user.UserLoginVO;
import com.mgs.cloud.game.server.mapper.TokenMapper;
import com.mgs.cloud.game.server.mapper.UserMapper;
import com.mgs.cloud.game.server.mapstruct.UserEntityMapper;
import com.mgs.cloud.game.server.model.entity.user.UserInfoEntity;
import com.mgs.cloud.game.server.model.entity.user.UserTokenEntity;
import com.mgs.cloud.game.server.service.IUserService;
import com.mgs.cloud.game.server.service.IMgsHttpService;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@Slf4j
@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private TokenMapper tokenMapper;

    @Autowired
    private IMgsHttpService mgsHttpService;

    /**
     * 登录
     * <p>
     * 1. 调用mgs校验用户是否有效
     * 2. 校验用户信息（t_user）是否需要更新
     * 3. 生成token
     * 4. 封装用户信息、token信息返回
     *
     * @param qo openId、openCode
     * @return 用户信息、token信息
     */
    @Override
    public UserLoginVO login(@NotNull QueryOpenUserQuery qo) {
        log.info("login: {}", qo.toString());
        // 校验openId是否有效
        QueryOpenUserVO vo = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.USER_QUERY, qo);
        if (null == vo || !qo.getOpenId().equals(vo.getOpenId())) {
            // 身份验证错误
            throw new UniversalException(UniversalErrorCode.UNAUTHORIZED);
        }
        UserInfoDTO userInfo = new UserInfoDTO().init(vo, qo.getOpenCode());
        //插入/更新用户信息
        userMapper.insertOrUpdateUser(userInfo);
        UserTokenDTO userToken = createOpenUserToken(vo.getOpenId(), TokenInvalidConfig.TOKEN_OPEN_USER);

        return new UserLoginVO(userInfo, userToken);
    }

    /**
     * 创建OpenUser的Token
     * <p>
     * 1. 根据配置生成token
     * 2. 存储（t_token）
     *
     * @param openId             开放用户id
     * @param tokenInvalidConfig tokenConfig
     * @return token信息
     */
    @Override
    public UserTokenDTO createOpenUserToken(@NotNull String openId, @NotNull TokenInvalidConfig tokenInvalidConfig) {
        // 生成token
        UserTokenEntity userTokenEntity = new UserTokenEntity().init(openId, tokenInvalidConfig);
        // token存储
        tokenMapper.insertOrUpdateToken(userTokenEntity);

        return UserEntityMapper.INSTANCE.toUserTokenDTO(userTokenEntity);
    }

    /**
     * 根据token查询UserToken
     *
     * @param token token
     * @return token信息
     */
    @Override
    public UserTokenEntity selectUserTokenByToken(@NotNull String token) {
        return tokenMapper.selectUserTokenByToken(token);
    }

    /**
     * 根据openId List查询用户信息
     * <p>
     * 1. 根据openIdList查询（t_user）
     * 2. Entity转DTO返回
     *
     * @param openIdList 用户id List
     * @return 对应的用户信息
     */
    @Override
    public List<UserInfoDTO> selectUserByOpenIdList(@NotNull List<String> openIdList) {
        if (CollectionUtils.isEmpty(openIdList)) {
            return new ArrayList<>();
        }
        List<UserInfoEntity> userInfoEntities = userMapper.selectByOpenIdList(openIdList);
        UserEntityMapper instance = UserEntityMapper.INSTANCE;
        return userInfoEntities.stream().map(instance::toUserInfoDTO).collect(Collectors.toList());
    }

    /**
     * 给指定openId、token，重新计算有效期
     * <p>
     * 1. 根据配置重新计算token的有效期
     * 2. 更新token（t_token）
     *
     * @param openId 开放用户id
     * @param token  token
     */
    @Override
    public void continuationInvalidTime(@NotNull String openId, @NotNull String token) {
        // 生成token
        UserTokenEntity userTokenEntity = new UserTokenEntity()
                .setOpenId(openId)
                .setToken(token)
                .createInvalidTime(TokenInvalidConfig.TOKEN_OPEN_USER);

        // token更新有效时间
        tokenMapper.insertOrUpdateToken(userTokenEntity);
    }

    /**
     * 校验token的有效性
     * 校验成功return {@code true}, 校验失败 return {@code false}
     * 1. 校验@Token是否为null
     * 2. 校验请求头是否有gameToken
     * 3. 校验gameToken是否可以解析到openId
     * 4. 校验gameToken解析的openId是否和该用户的openId一致
     * 5. 校验token是否过期
     * 以上校验均通过，则给token续命，并将openId set到UserOpenIdInfo
     *
     * @param tokenValue token值
     * @param config     token使用的配置
     * @return 校验成功return {@code true}, 校验失败 return {@code false}
     */
    @Override
    public boolean checkToken(@NotNull String tokenValue, @NotNull TokenInvalidConfig config) {
        if (Strings.isNullOrEmpty(tokenValue)) {
            // 不传token返回UNAUTHORIZED
            log.info("UNAUTHORIZED: gameToken is null or empty");
            return false;
        }
        // 解密token获取openId
        String openId = config.getDecryptTokenFunc().apply(tokenValue);
        if (Strings.isNullOrEmpty(openId)) {
            // token解析不到openId返回UNAUTHORIZED
            log.info("UNAUTHORIZED[{}]: token's openId is null or empty", tokenValue);
            return false;
        }
        // 校验Token有效性
        UserTokenEntity userToken = selectUserTokenByToken(tokenValue);
        if (null == userToken || !userToken.getOpenId().equals(openId)) {
            // openId不一致返回UNAUTHORIZED
            log.info("UNAUTHORIZED[{}]: openId inconsistency", openId);
            return false;
        }
        // 校验Token有效性
        if (userToken.getInvalidTime().getTime() < TimeUtil.currentTimeMillis()) {
            // token过期返回UNAUTHORIZED
            log.info("UNAUTHORIZED[{}]: token invalid", tokenValue);
            return false;
        }
        continuationInvalidTime(openId, tokenValue);
        UserOpenIdInfo.setOpenId(openId);
        return true;
    }
}
