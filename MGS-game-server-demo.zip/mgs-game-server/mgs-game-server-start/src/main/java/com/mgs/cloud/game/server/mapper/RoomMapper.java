package com.mgs.cloud.game.server.mapper;

import com.mgs.cloud.game.server.model.entity.room.RoomEntity;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@Mapper
public interface RoomMapper {

    /**
     * 插入一条房间信息
     *
     * @param room 房间信息
     * @return 受影响的行数
     */
    @Options(useGeneratedKeys = true, keyProperty = "roomId", keyColumn = "roomId")
    @Insert({"<script>",
            "insert into `t_room`(`roomLimit`, `roomName`, `roomState`, `roomType`, `roomTags`, `roomOwner`" +
                    "<if test = \"room.hasParent != null\">, `hasParent`</if>" +
                    ") " +
                    "values(#{room.roomLimit}, #{room.roomName}, #{room.roomState}, #{room.roomType}, #{room.roomTags}, #{room.roomOwner} " +
                    "<if test = \"room.hasParent != null\">, #{room.hasParent}</if>" +
                    ")"
            , "</script>"})
    int insertOne(@Param("room") RoomEntity room);

    /**
     * 根据房间号查询
     *
     * @param roomId 房间号
     * @return 房间信息
     */
    @Select("select * from `t_room` where `roomId` = #{roomId}")
    RoomEntity selectByRoomId(@Param("roomId") Integer roomId);

    /**
     * 修改房间的是否满员状态
     *
     * @param roomId 房间号
     * @param full   是否满员
     * @return 受影响的行数
     */
    @Update("update `t_room` set `full` = #{full} where `roomId` = #{roomId}")
    int updateRoomFull(@Param("roomId") Integer roomId, @Param("full") boolean full);

    /**
     * 根据是否满员查询十条的房间号
     *
     * @param full     是否满员
     * @param roomType 房间类型
     * @return 查询到的房间号
     */
    @Select({"<script>",
            "select `roomId` from `t_room` where `full` = #{full} and `roomState` = 0 and `hasParent` = 0 " +
                    "<if test = \"roomType != null\">" +
                    " and roomType = #{roomType}" +
                    "</if>" +
                    " order by `roomId` desc limit 10",
            "</script>"})
    List<Integer> listTenRoomIdByFull(@Param("full") boolean full, @Param("roomType") Integer roomType);

    /**
     * 根据房间号修改房间状态
     *
     * @param roomId    房间号
     * @param roomState 房间状态
     * @return 受影响的行数
     */
    @Update("update `t_room` set `roomState` = #{roomState} where `roomId` = #{roomId}")
    int updateRoomState(@Param("roomId") Integer roomId, @Param("roomState") Integer roomState);

    /**
     * 根据房间号删除房间
     *
     * @param roomId 房间号
     * @return 受影响的行数
     */
    @Delete("delete from `t_room` where `roomId` = #{roomId}")
    int deleteByRoomId(@Param("roomId") Integer roomId);

    /**
     * 根据房间号修改房主
     *
     * @param openId 房主openId
     * @param roomId 房间号
     * @return 受影响的行数
     */
    @Update("update `t_room` set `roomOwner` = #{openId} where `roomId` = #{roomId}")
    int updateRoomOwnerByOpenId(@Param("openId") String openId, @Param("roomId") Integer roomId);

    /**
     * 根据是否满员和房间id List查询一条的房间号
     *
     * @param full    是否满员
     * @param roomIds 房间id
     * @return 查询到的房间号
     */
    @Select({"<script>",
            "select * from `t_room` where `full` = #{full} and `roomId` in " +
                    "<foreach collection=\"roomIds\" index=\"index\" item=\"item\" separator=\",\" open=\"(\" close=\")\">" +
                    "#{item}" +
                    "</foreach>" +
                    " limit 1",
            "</script>"})
    RoomEntity selectOneRoomIdByFullAndRoomIdList(@Param("full") boolean full, @Param("roomIds") List<Integer> roomIds);

    /**
     * 根据房间id修改房间标签
     *
     * @param roomId   房间id
     * @param roomTags 标签
     * @return 受影响的行数
     */
    @Update("update `t_room` set `roomTags` = #{roomTags} where `roomId` = #{roomId}")
    int updateRoomTags(@Param("roomId") Integer roomId, @Param("roomTags") String roomTags);
}
