package com.mgs.cloud.game.server.model.entity.room;

import com.mgs.api.game.server.model.enums.room.RoomStateEnum;
import com.mgs.api.game.server.model.enums.room.RoomTypeEnum;
import com.mgs.api.game.server.model.qo.team.CreateTeamQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@ToString
@Data
@ApiModel("房间信息数据库映射实体")
@Accessors(chain = true)
public class RoomEntity implements Serializable {

    private static final long serialVersionUID = 8631378999280335060L;

    @ApiModelProperty("房间id")
    private Integer roomId;

    @ApiModelProperty("房间成员容量")
    private Integer roomLimit;

    @ApiModelProperty("房间名称")
    private String roomName;

    /**
     * 房间状态码：
     *
     * @see com.mgs.api.game.server.model.enums.room.RoomStateEnum
     */
    @ApiModelProperty("房间状态码")
    private Integer roomState;

    /**
     * 房间类型码：
     *
     * @see com.mgs.api.game.server.model.enums.room.RoomTypeEnum
     */
    @ApiModelProperty("房间类型码")
    private Integer roomType;

    @ApiModelProperty("房间是否满员")
    private Boolean full;

    @ApiModelProperty("房间标签,自定义")
    private String roomTags;

    @ApiModelProperty("房主openId")
    private String roomOwner;

    @ApiModelProperty("true表示该房间类型为TEAM，默认false")
    private Boolean hasParent;

    /**
     * 初始化 房间状态
     *
     * @return this
     */
    public RoomEntity initState() {
        // 房间创建时为准备状态
        return this.setRoomState(RoomStateEnum.READYING.getStateCode());
    }

    /**
     * 初始化
     *
     * @param roomTypeEnum 房间类型的配置信息
     * @return this
     */
    public RoomEntity init(@NotNull RoomTypeEnum roomTypeEnum) {
        return this
                .setRoomLimit(roomTypeEnum.getRoomLimit())
                .setRoomType(roomTypeEnum.getRoomType());
    }

    /**
     * 初始化TEAM
     *
     * @param qo        创建队伍请求参数
     * @param teamLimit 队伍规模
     * @return this
     */
    public RoomEntity initTeam(@NotNull CreateTeamQuery qo, @NotNull Integer teamLimit) {
        return initState()
                .setRoomType(qo.getRoomType())
                .setRoomLimit(teamLimit)
                .setHasParent(true);
    }
}
