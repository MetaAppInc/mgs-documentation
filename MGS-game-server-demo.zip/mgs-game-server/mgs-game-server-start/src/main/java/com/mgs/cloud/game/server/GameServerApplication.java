package com.mgs.cloud.game.server;

import com.mgs.cloud.game.server.config.DataSourceConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 启动类
 *
 * @author guozheng.zhao
 * @date 2021/2/3
 */
@ComponentScan({"com.mgs.cloud.game", "com.mgs.api.game.server.model.exception.resolver"})
@EnableSwagger2
@SpringBootApplication
@MapperScan(basePackages = "com.mgs.cloud.game.server", annotationClass = Mapper.class)
@ImportAutoConfiguration({DataSourceConfig.class})
@Slf4j
public class GameServerApplication {

    public static void main(String[] args) {
        try {
            SpringApplication.run(GameServerApplication.class, args);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
