package com.mgs.cloud.game.server.model.enums.user;

import com.mgs.cloud.game.server.utils.EncryptUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;

/**
 * Token有效期配置
 *
 * @author guozheng.zhao
 * @date 2021/2/5
 */
@AllArgsConstructor
public enum TokenInvalidConfig {
    // 用户token有效期、加密解密规则 配置
    TOKEN_OPEN_USER(TimeUnit.HOURS, 12L, EncryptUtil::aesEncrypt, EncryptUtil::aesDecrypt),
    ;

    /**
     * 时间单位
     */
    @Getter
    private TimeUnit timeUnit;

    /**
     * 过期时间
     */
    @Getter
    private Long time;

    /**
     * 创建token的Function
     */
    @Getter
    private Function<String, String> createTokenFunc;

    /**
     * 解密token的Function
     */
    @Getter
    private Function<String, String> decryptTokenFunc;
}
