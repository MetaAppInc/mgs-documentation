package com.mgs.cloud.game.server.service;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.enums.room.RoomTypeEnum;
import com.mgs.api.game.server.model.qo.mgs.room.CreateMgsRoomQuery;
import com.mgs.api.game.server.model.qo.room.CreateRoomQuery;
import com.mgs.api.game.server.model.qo.room.JoinRoomQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import com.mgs.api.game.server.model.vo.mgs.room.CreateRoomVO;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomInfoVO;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomUserVO;
import com.mgs.api.game.server.model.vo.room.RoomVO;
import com.mgs.cloud.game.server.model.entity.room.RoomEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Function;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
public interface IRoomService {

    /**
     * 创建房间并同步mgs
     *
     * @param createRoomQuery 房间设置信息
     * @return 房间信息
     */
    RoomVO createRoom(@NotNull CreateRoomQuery createRoomQuery);

    /**
     * 创建游戏房间
     *
     * @param createRoomQuery 房间设置信息
     * @param openId          开放用户id
     * @param roomTypeEnum    房间类型配置
     * @return 房间信息
     */
    RoomDTO createGameRoom(@NotNull CreateRoomQuery createRoomQuery, @Nullable String openId, @NotNull RoomTypeEnum roomTypeEnum);

    /**
     * 创建游戏房间
     *
     * @param entity 房间实体信息
     * @param openId 开放用户id
     * @return 房间信息
     */
    RoomDTO createGameRoom(@NotNull RoomEntity entity, @Nullable String openId);

    /**
     * 创建房间并同步mgs
     *
     * @param createRoomQuery 房间设置信息
     * @param openId          开放用户id
     * @return 房间信息
     */
    RoomVO createRoom(@NotNull CreateRoomQuery createRoomQuery, @Nullable String openId);

    /**
     * 加入房间
     *
     * @param joinRoomQuery 房间id, 不为空代表正常加入房间, 为空代表快速加入房间
     * @return 是否加入成功
     */
    RoomVO joinRoom(@NotNull JoinRoomQuery joinRoomQuery);

    /**
     * 同步房间成员到mgs
     *
     * @param roomId 房间id
     */
    void syncRoomToMgs(@NotNull Integer roomId);

    /**
     * 加入房间，并执行Team相关逻辑
     *
     * @param roomId 房间号
     * @param openId 用户开放id
     * @param teamId 队伍id
     * @return 房间信息
     */
    RoomVO joinRoom(@NotNull Integer roomId, @NotNull String openId, @Nullable Integer teamId);

    /**
     * 加入游戏房间
     *
     * @param roomId 房间号
     * @param openId 用户开放id
     * @return 房间信息
     */
    RoomDTO joinGameRoom(@NotNull Integer roomId, @NotNull String openId);

    /**
     * 掉线重连
     *
     * @param openId 用户开放id
     * @param roomId 房间id
     */
    void reconnection(@NotNull String openId, @NotNull Integer roomId);

    /**
     * 离开房间
     *
     * @param roomId 房间id
     * @param openId 开放用户id
     * @return 是否离开成功
     */
    Boolean leaveRoom(@NotNull Integer roomId, @NotNull String openId);

    /**
     * 获取房间内的用户id列表
     *
     * @param roomId 房间id
     * @return 用户id列表
     */
    List<String> getOpenIdsByRoomId(@NotNull Integer roomId);

    /**
     * 离开房间
     *
     * @param leaveRoomQuery 房间id
     * @return 是否离开成功
     */
    Boolean leaveRoom(@NotNull RoomIdQuery leaveRoomQuery);

    /**
     * 离开房间并广播消息给房间内其他用户
     *
     * @param leaveRoomQuery 房间id
     * @return 是否离开成功
     */
    Boolean leaveRoomAndFanout(@NotNull RoomIdQuery leaveRoomQuery);

    /**
     * 广播房间信息给房间内所有用户
     *
     * @param roomId 房间id
     * @param func   执行方法
     * @param t      方法参数
     * @param <T>    入参类型
     * @param <R>    返回值类型
     * @return 方法执行的返回值
     */
    <T, R> R fanout(@NotNull Integer roomId, @NotNull Function<T, R> func, @NotNull T t);

    /**
     * 同步游戏房间信息
     *
     * @param syncRoomStateQuery 房间状态
     * @return 是否同步成功
     */
    RoomDTO syncGameRoomInfo(@NotNull SyncRoomStateQuery syncRoomStateQuery);

    /**
     * 同步房间信息并同步mgs
     *
     * @param syncRoomStateQuery 房间状态
     * @return 是否同步成功
     */
    Boolean syncRoomInfo(@NotNull SyncRoomStateQuery syncRoomStateQuery);

    /**
     * 同步房间信息并广播房间状态
     *
     * @param syncRoomStateQuery 房间状态
     */
    void syncRoomInfoAndFanout(@NotNull SyncRoomStateQuery syncRoomStateQuery);

    /**
     * 销毁游戏房间
     *
     * @param roomId 房间号
     * @return 是否销毁成功
     */
    Boolean destroyGameRoom(@NotNull Integer roomId);

    /**
     * 销毁房间并同步mgs
     *
     * @param destroyRoomQuery 房间号
     * @return 是否销毁成功
     */
    Boolean destroyRoom(@NotNull RoomIdQuery destroyRoomQuery);

    /**
     * 查询房间的玩家列表
     *
     * @param queryUserQuery 房间号
     * @return 玩家列表
     */
    List<QueryRoomUserVO> queryUserList(@NotNull RoomIdQuery queryUserQuery);

    /**
     * 查询房间详细信息：房间信息、玩家列表
     *
     * @param queryUserQuery roomId
     * @return 房间信息
     */
    QueryRoomInfoVO queryRoom(@NotNull RoomIdQuery queryUserQuery);

    /**
     * 创建MGS房间
     *
     * @param qo 创建参数
     * @return 返回结果
     */
    CreateRoomVO createMgsRoom(@NotNull CreateMgsRoomQuery qo);

    /**
     * 查询房间信息
     *
     * @param queryRoomQuery roomId
     * @return roomInfo
     */
    RoomDTO queryRoomInfo(@NotNull RoomIdQuery queryRoomQuery);

    /**
     * 批量加入房间
     *
     * @param roomId     房间id
     * @param state      状态
     * @param openIdList 用户openId List
     * @return 受影响的行数
     */
    Integer batchJoinRoom(@NotNull Integer roomId, @NotNull Integer state, @NotNull List<String> openIdList);

    /**
     * 批量校验房间内用户好友关系
     *
     * @param roomId 房间id
     */
    void batchCheckFriend(@NotNull Integer roomId);
}
