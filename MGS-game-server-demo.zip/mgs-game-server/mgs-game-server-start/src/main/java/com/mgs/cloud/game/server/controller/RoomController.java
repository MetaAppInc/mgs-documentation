package com.mgs.cloud.game.server.controller;

import com.mgs.api.game.server.api.RoomApi;
import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.qo.room.CreateRoomQuery;
import com.mgs.api.game.server.model.qo.room.JoinRoomQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomInfoVO;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomUserVO;
import com.mgs.api.game.server.model.vo.room.RoomVO;
import com.mgs.cloud.game.server.aop.Token;
import com.mgs.cloud.game.server.service.IRoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@RestController
public class RoomController implements RoomApi {

    @Autowired
    private IRoomService roomService;

    @Override
    @Token
    public Response<RoomVO> createRoom(@RequestBody @Valid CreateRoomQuery createRoomQuery) {
        return Response.execute(res -> res.setData(roomService.createRoom(createRoomQuery)));
    }

    @Override
    @Token
    public Response<RoomVO> joinRoom(@RequestBody JoinRoomQuery joinRoomQuery) {
        return Response.execute(res -> res.setData(roomService.joinRoom(joinRoomQuery)));
    }

    @Override
    @Token
    public Response<Boolean> leaveRoom(@RequestBody RoomIdQuery leaveRoomQuery) {
        return Response.execute(res -> res.setData(roomService.leaveRoom(leaveRoomQuery)));
    }

    @Override
    @Token
    public Response<Boolean> leaveRoomAndFanout(RoomIdQuery leaveRoomQuery) {
        return Response.execute(res -> res.setData(roomService.leaveRoomAndFanout(leaveRoomQuery)));
    }

    @Override
    @Token
    public Response<Boolean> syncRoomInfo(@RequestBody @Valid SyncRoomStateQuery syncRoomStateQuery) {
        return Response.execute(res -> res.setData(roomService.syncRoomInfo(syncRoomStateQuery)));
    }

    @Override
    @Token
    public Response<Boolean> destroyRoom(@RequestBody RoomIdQuery destroyRoomQuery) {
        return Response.execute(res -> res.setData(roomService.destroyRoom(destroyRoomQuery)));
    }

    @Override
    @Token
    public Response<List<QueryRoomUserVO>> queryUserList(@RequestBody RoomIdQuery queryUserQuery) {
        return Response.execute(res -> res.setData(roomService.queryUserList(queryUserQuery)));
    }

    @Override
    @Token
    public Response<QueryRoomInfoVO> queryRoom(@RequestBody RoomIdQuery queryUserQuery) {
        return Response.execute(res -> res.setData(roomService.queryRoom(queryUserQuery)));
    }

    @Override
    public Response<RoomVO> createMgsRoom(@RequestBody @Valid CreateRoomQuery createRoomQuery) {
        return Response.execute(res -> res.setData(roomService.createRoom(createRoomQuery, null)));
    }

    @Override
    public Response<RoomDTO> queryRoomInfo(@RequestBody RoomIdQuery queryRoomQuery) {
        return Response.execute(res -> res.setData(roomService.queryRoomInfo(queryRoomQuery)));
    }

    @Override
    @Token
    public Response batchCheckFriend(@RequestBody Integer roomId) {
        roomService.batchCheckFriend(roomId);
        return Response.transformByErrorCode(UniversalErrorCode.OK);
    }
}
