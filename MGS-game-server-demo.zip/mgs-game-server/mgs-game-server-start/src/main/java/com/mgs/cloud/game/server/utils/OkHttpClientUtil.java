package com.mgs.cloud.game.server.utils;

import com.mgs.api.game.server.util.TimeUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import okhttp3.FormBody.Builder;
import okio.Buffer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * OkHttp工具类
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@Slf4j
public class OkHttpClientUtil {

    /**
     * MediaType - JSON
     */
    public static final MediaType MEDIA_TYPE_JSON = MediaType.parse("application/json; charset=utf-8");

    /**
     * OkHttpClient
     */
    private static final OkHttpClient HTTP_CLIENT =
            new OkHttpClient.Builder()
                    .readTimeout(5000, TimeUnit.MILLISECONDS)
                    .connectTimeout(5000, TimeUnit.MILLISECONDS)
                    .build();

    /**
     * Post with FormData
     *
     * @param url 请求地址
     * @param map 请求参数
     * @return Response String
     * @throws IOException okHttp3.Call.execute
     */
    public static String postFormData(@NotNull String url, @NotNull Map<String, String> map) throws IOException {
        return postFormData(url, map, null);
    }

    /**
     * Post with FormData
     *
     * @param url    请求地址
     * @param map    请求参数
     * @param client 指定HttpClient
     * @return Response String
     * @throws IOException okHttp3.Call.execute
     */
    public static String postFormData(@NotNull String url, @NotNull Map<String, String> map, @Nullable OkHttpClient client) throws IOException {
        if (null == client) {
            client = HTTP_CLIENT;
        }
        Builder builder = new FormBody.Builder();
        map.forEach((k, v) -> {
            if (Objects.nonNull(k) && Objects.nonNull(v)) {
                builder.add(k, v);
            }
        });
        Request request = new Request.Builder().url(url).post(builder.build()).build();
        return callRequest(request, client);
    }

    /**
     * Post with JSON
     *
     * @param url  请求地址
     * @param json 请求参数，JSON字符串
     * @return Response String
     * @throws IOException okHttp3.Call.execute
     */
    public static String postWithJson(@NotNull String url, @NotNull String json) throws IOException {
        return postWithJson(url, json, null);
    }

    /**
     * Post with JSON
     *
     * @param url     请求地址
     * @param json    请求参数，JSON字符串
     * @param headers 请求头
     * @return Response String
     * @throws IOException okHttp3.Call.execute
     */
    public static String postWithJson(@NotNull String url, @NotNull String json, @Nullable Headers headers) throws IOException {
        log.info("postWithJson param：{}", json);
        RequestBody body = RequestBody.create(json, MEDIA_TYPE_JSON);
        Request.Builder requestBuilder = new Request.Builder().url(url).post(body);
        if (headers != null) {
            requestBuilder.headers(headers);
        }
        return callRequest(requestBuilder.build());
    }

    /**
     * Call Request
     *
     * @param request 请求Request
     * @return Response String
     * @throws IOException okHttp3.Call.execute
     */
    private static String callRequest(@NotNull Request request) throws IOException {
        return callRequest(request, null);
    }

    /**
     * Call Request
     *
     * @param request 请求Request
     * @param client  指定HttpClient
     * @return Response String
     * @throws IOException okHttp3.Call.execute
     */
    private static String callRequest(@NotNull Request request, @Nullable OkHttpClient client) throws IOException {
        if (null == client) {
            client = HTTP_CLIENT;
        }
        final Buffer buffer = new Buffer();
        try {
            long contentLength = request.body().contentLength();
            request.body().writeTo(buffer);
            String bodyText = buffer.readUtf8();
            log.info("HttpClientPostBodyText:[{}] 请求体长度:[{}]", bodyText, contentLength);
        } finally {
            buffer.close();
        }
        long startTime = TimeUtil.currentTimeMillis();
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                log.error("http请求失败, 耗时: {}ms,  requestHeader:{} response: {} ", (TimeUtil.currentTimeMillis() - startTime), request.headers(), response.body().string());
                throw new IOException("http unexpected code: " + response);
            }
            ResponseBody body = response.body();
            if (null == body) {
                return null;
            }
            return body.string();
        }
    }

    /**
     * Get
     *
     * @param url 请求地址
     * @return Response String
     * @throws IOException okHttp3.Call.execute
     */
    public static String get(String url) throws IOException {
        return get(url, null);
    }

    /**
     * Get
     *
     * @param url     请求地址
     * @param headers 请求头
     * @return Response String
     * @throws IOException okHttp3.Call.execute
     */
    public static String get(@NotNull String url, @Nullable Headers headers) throws IOException {
        Request.Builder requestBuilder = new Request.Builder().url(url);
        if (headers != null) {
            requestBuilder.headers(headers);
        }
        return callRequest(requestBuilder.build());
    }

}
