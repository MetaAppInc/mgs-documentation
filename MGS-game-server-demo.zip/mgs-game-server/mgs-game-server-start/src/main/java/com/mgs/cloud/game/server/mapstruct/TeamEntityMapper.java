package com.mgs.cloud.game.server.mapstruct;

import com.mgs.api.game.server.model.dto.team.TeamDTO;
import com.mgs.cloud.game.server.config.MapperCommonConfig;
import com.mgs.cloud.game.server.model.entity.team.TeamEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * 队伍实体映射
 *
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@Mapper(config = MapperCommonConfig.class)
public interface TeamEntityMapper {

    TeamEntityMapper INSTANCE = Mappers.getMapper(TeamEntityMapper.class);

    /**
     * Team Entity -> DTO
     *
     * @param entity Entity
     * @return DTO
     */
    TeamDTO toRoomDTO(TeamEntity entity);

}
