package com.mgs.cloud.game.server.config.mgs;

import org.jetbrains.annotations.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Mgs配置类
 *
 * @author shuai.shao
 */
@Configuration
@ConfigurationProperties(prefix = "mgs.server")
public class MgsConfig {

    /**
     * appKey为key
     */
    private Map<String, MgsConfigItem> configMap;

    /**
     * configList的配置列表添加到configMap
     *
     * @param configList 配置列表
     */
    public void setConfigList(List<MgsConfigItem> configList) {
        this.configMap = configList.stream().collect(Collectors.toMap(MgsConfigItem::getAppKey, Function.identity()));
    }

    /**
     * 根据appKey获取mgs配置
     *
     * @param appKey appKey
     * @return mgs配置
     */
    public MgsConfigItem get(@NotNull String appKey) {
        return configMap.get(appKey);
    }
}

