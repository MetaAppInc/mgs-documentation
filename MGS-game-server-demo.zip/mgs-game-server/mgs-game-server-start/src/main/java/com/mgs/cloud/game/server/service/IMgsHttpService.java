package com.mgs.cloud.game.server.service;

import com.mgs.api.game.server.model.enums.mgs.MgsHttpConfig;
import org.jetbrains.annotations.NotNull;


/**
 * 请求MGS服务端的Http请求Service interface
 *
 * @author guozheng.zhao
 * @date 2021/2/4 19:12
 */
public interface IMgsHttpService {

    /**
     * 发送Post、请求参数JSON的Http请求访问MGS接口
     *
     * @param mgsHttpConfig MGS Http请求的配置
     * @param param         请求参数，sign是根据param生成的，不能为null
     * @param <R>           MgsHttpConfig.ResponseClazz
     * @param <P>           参数类型
     * @return Response
     */
    <R, P> R sendPostJsonRequest(@NotNull MgsHttpConfig mgsHttpConfig, @NotNull P param);

}
