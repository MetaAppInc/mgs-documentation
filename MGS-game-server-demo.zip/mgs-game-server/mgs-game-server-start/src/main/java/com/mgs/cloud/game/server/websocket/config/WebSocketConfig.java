package com.mgs.cloud.game.server.websocket.config;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

/**
 * @author guozheng.zhao
 * @date 2021/3/8
 */
@Component
public class WebSocketConfig {

    /**
     * 开启SpringBoot webSocket支持
     *
     * @return ServerEndpointExporter
     */
    @Bean
    public ServerEndpointExporter serverEndpointExporter() {
        return new ServerEndpointExporter();
    }

}
