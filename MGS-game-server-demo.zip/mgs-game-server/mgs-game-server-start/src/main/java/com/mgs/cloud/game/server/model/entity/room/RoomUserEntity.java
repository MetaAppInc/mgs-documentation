package com.mgs.cloud.game.server.model.entity.room;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@ToString
@Data
@ApiModel("房间-用户 数据库映射实体")
@Accessors(chain = true)
public class RoomUserEntity implements Serializable {

    private static final long serialVersionUID = 3577697253142344958L;

    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("房间id")
    private Integer roomId;

    @ApiModelProperty("开放用户id")
    private String openId;

    /**
     * 玩家状态
     *
     * @see com.mgs.api.game.server.model.enums.user.UserStateEnum
     */
    @ApiModelProperty("玩家状态: 0 未准备, 1 准备")
    private Integer userState;

    public RoomUserEntity() {
    }

    public RoomUserEntity(Integer roomId, String openId) {
        this.roomId = roomId;
        this.openId = openId;
    }
}
