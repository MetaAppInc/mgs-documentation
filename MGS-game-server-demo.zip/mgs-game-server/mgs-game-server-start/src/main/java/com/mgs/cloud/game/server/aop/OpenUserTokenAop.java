package com.mgs.cloud.game.server.aop;

import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.cloud.game.server.config.AppKeyInfo;
import com.mgs.cloud.game.server.config.UserOpenIdInfo;
import com.mgs.cloud.game.server.service.IUserService;
import com.mgs.cloud.game.server.utils.SignUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

/**
 * 校验用户Token的Aop
 *
 * @author guozheng.zhao
 * @date 2021/2/5
 */
@Slf4j
@Aspect
@Component
public class OpenUserTokenAop {

    /**
     * 客户端请求头带的token的key
     */
    public static final String TOKEN_KEY = "gameToken";

    @Autowired
    IUserService userService;

    /**
     * 使用@Token作为切入点
     */
    @Pointcut("@annotation(Token)")
    public void checkUserOpenId() {
    }

    /**
     * 获取appKey
     *
     * @param joinPoint 切点
     */
    @Before("execution(* com.mgs.cloud.game.server.controller..*.*(..))")
    public void setAppKey(JoinPoint joinPoint) {
        HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
        AppKeyInfo.setAppKey(request.getHeader(SignUtil.APP_KEY));
    }

    /**
     * 校验gameToken
     * <p>
     * 1. 校验@Token是否为null
     * 2. 校验请求头是否有gameToken
     * 3. 校验gameToken是否可以解析到openId
     * 4. 校验gameToken解析的openId是否和该用户的openId一致
     * 5. 校验token是否过期
     * 以上校验均通过，则给token续命，并将openId set到UserOpenIdInfo
     *
     * @param pjp 环绕通知连接点
     * @return Response
     */
    @Around("checkUserOpenId()")
    public Object checkToken(ProceedingJoinPoint pjp) {
        HttpServletRequest request = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
        // 目标接口的Token注解
        Token token = ((MethodSignature) pjp.getSignature()).getMethod().getAnnotation(Token.class);
        // 不加@Token的接口不需要校验
        if (null == token) {
            return proceed(pjp);
        }
        // 获取客户端请求头的token
        String tokenValue = request.getHeader(TOKEN_KEY);
        if (!userService.checkToken(tokenValue, token.tokenType())) {
            return Response.transformByErrorCode(UniversalErrorCode.UNAUTHORIZED);
        }
        return proceed(pjp);
    }

    /**
     * 执行切面方法
     *
     * @param pjp 切点
     * @return response
     */
    private Object proceed(ProceedingJoinPoint pjp) {
        try {
            return pjp.proceed();
        } catch (Throwable throwable) {
            log.error("pjp proceed error: {}", throwable.getMessage(), throwable);
            return null;
        } finally {
            // 无论执行结果如何，在方法执行完毕之后都要清除线程上下文的openId
            UserOpenIdInfo.clean();
        }
    }
}
