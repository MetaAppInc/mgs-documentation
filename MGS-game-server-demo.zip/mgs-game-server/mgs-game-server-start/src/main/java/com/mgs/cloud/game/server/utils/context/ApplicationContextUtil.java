package com.mgs.cloud.game.server.utils.context;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * @author guozheng.zhao
 * @date 2021/3/9
 */
@Component
@Lazy(false)
public class ApplicationContextUtil implements ApplicationContextAware {

    private static ApplicationContext APPLICATION_CONTEXT;

    /**
     * 设置spring上下文
     *
     * @param applicationContext spring上下文
     * @throws BeansException ApplicationContextAware throws
     */
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        APPLICATION_CONTEXT = applicationContext;
    }

    /**
     * 获取上下文
     *
     * @return APPLICATION_CONTEXT
     */
    public static ApplicationContext getApplicationContext() {
        return APPLICATION_CONTEXT;
    }

    /**
     * 获取容器中的Bean
     *
     * @param requiredType Bean的Class类型
     * @param <T>          Bean的类型
     * @return Bean
     * @throws BeansException ApplicationContext.getBean throws
     */
    public static <T> T getBean(Class<T> requiredType) throws BeansException {
        return APPLICATION_CONTEXT.getBean(requiredType);
    }

}
