package com.mgs.cloud.game.server.mapstruct;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.cloud.game.server.config.MapperCommonConfig;
import com.mgs.cloud.game.server.model.entity.room.RoomEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * 房间实体映射
 *
 * @author guozheng.zhao
 * @date 2021/2/5
 */
@Mapper(config = MapperCommonConfig.class)
public interface RoomEntityMapper {

    RoomEntityMapper INSTANCE = Mappers.getMapper(RoomEntityMapper.class);

    /**
     * Room Entity -> DTO
     *
     * @param entity Entity
     * @return DTO
     */
    RoomDTO toRoomDTO(RoomEntity entity);

}
