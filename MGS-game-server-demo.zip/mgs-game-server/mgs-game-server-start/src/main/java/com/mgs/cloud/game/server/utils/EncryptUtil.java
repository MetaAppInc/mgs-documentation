package com.mgs.cloud.game.server.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.jetbrains.annotations.NotNull;
import sun.misc.BASE64Decoder;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 * AES算法加密解密
 *
 * @author guozheng.zhao
 * @date 2021/2/5
 */
@Slf4j
public class EncryptUtil {

    /**
     * 密钥, AES加密要求key必须要128个byte（这里需要长度为16，否则会报错）
     */
    private static final String KEY = "1122334455667788";

    /**
     * AES
     */
    private static final String AES = "AES";

    /**
     * 算法
     */
    private static final String ALGORITHM_STR = "AES/ECB/PKCS5Padding";

    /**
     * base 64 encode
     *
     * @param bytes 待编码的byte[]
     * @return 编码后的base 64 code
     */
    private static String base64Encode(@NotNull byte[] bytes) {
        return Base64.encodeBase64String(bytes);
    }

    /**
     * base 64 decode
     *
     * @param base64Code 待解码的base 64 code
     * @return 解码后的byte[]
     * @throws IOException 抛出异常
     */
    private static byte[] base64Decode(@NotNull String base64Code) throws IOException {
        return new BASE64Decoder().decodeBuffer(base64Code);
    }

    /**
     * AES加密
     *
     * @param token 待加密的内容
     * @return 加密后的byte[]
     */
    private static byte[] aesEncryptToBytes(@NotNull String token) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        Cipher cipher = Cipher.getInstance(ALGORITHM_STR);
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(EncryptUtil.KEY.getBytes(), AES));

        return cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * AES加密为base 64 code
     *
     * @param token 待加密的内容
     * @return 加密后的base 64 code
     */
    public static String aesEncrypt(@NotNull String token) {
        try {
            return base64Encode(aesEncryptToBytes(token));
        } catch (Exception e) {
            log.error("aesEncrypt error: {}", e.getMessage(), e);
            return token;
        }
    }

    /**
     * AES解密
     *
     * @param encryptBytes 待解密的byte[]
     * @return 解密后的String
     */
    private static String aesDecryptByBytes(@NotNull byte[] encryptBytes) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Cipher cipher = Cipher.getInstance(ALGORITHM_STR);
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(EncryptUtil.KEY.getBytes(), AES));
        byte[] decryptBytes = cipher.doFinal(encryptBytes);

        return new String(decryptBytes);
    }

    /**
     * 将base 64 code AES解密
     *
     * @param encryptStr 待解密的base 64 code
     * @return 解密后的string
     */
    public static String aesDecrypt(@NotNull String encryptStr) {
        try {
            return aesDecryptByBytes(base64Decode(encryptStr));
        } catch (Exception e) {
            log.error("aesDecrypt error: {}", e.getMessage(), e);
            return null;
        }
    }
}
