package com.mgs.cloud.game.server.websocket.config;

import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import com.mgs.api.game.server.model.qo.team.CreateTeamQuery;
import com.mgs.api.game.server.model.qo.team.JoinTeamQuery;
import com.mgs.cloud.game.server.service.IRoomService;
import com.mgs.cloud.game.server.service.ITeamService;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * webSocket和客户端通讯方法名和对应的实际调用的方法的配置
 * <p>
 * action作为服务端和客户端通讯的指令约定，
 * 使用spring上下文根据clazz获取到容器中的属性，
 * 通过method方法名、paramClass入参类型 反射到执行的方法执行
 * <p>
 * fanoutRoom表示执行完方法后是否广播给房间
 * fanoutTeam表示执行完方法后是否广播给队伍
 *
 * @author guozheng.zhao
 * @date 2021/3/10
 */
@AllArgsConstructor
public enum MessageMethodEnum {
    /*
      Room
     */
    // 查询房间信息
    ROOM_QUERY(MessageActionEnum.ROOM_QUERY.getAction(), "queryRoom", IRoomService.class, RoomIdQuery.class, false, false),
    // 同步房间信息，开始游戏/结束游戏
    ROOM_SYNC(MessageActionEnum.ROOM_SYNC.getAction(), "syncRoomInfoAndFanout", IRoomService.class, SyncRoomStateQuery.class, true, true),
    // 离开房间
    ROOM_LEAVE(MessageActionEnum.ROOM_LEAVE.getAction(), "leaveRoom", IRoomService.class, RoomIdQuery.class, true, true),
    // 批量检查房间内好友关系
    BATCH_CHECK_FRIEND(MessageActionEnum.BATCH_CHECK_FRIEND.getAction(), "batchCheckFriend", IRoomService.class, Integer.class, false, false),

    /*
      TEAM
     */
    // 查询team信息
    TEAM_QUERY(MessageActionEnum.TEAM_QUERY.getAction(), "listTeamByRoomId", ITeamService.class, Integer.class, false, false),
    // 创建team
    TEAM_CREATE(MessageActionEnum.TEAM_CREATE.getAction(), "createTeam", ITeamService.class, CreateTeamQuery.class, true, true),
    // 加入team
    TEAM_JOIN(MessageActionEnum.TEAM_JOIN.getAction(), "joinTeam", ITeamService.class, JoinTeamQuery.class, true, true),
    // 离开team
    TEAM_LEAVE(MessageActionEnum.TEAM_LEAVE.getAction(), "leaveTeam", ITeamService.class, RoomIdQuery.class, true, true),
    // 切换房间
    TEAM_SWITCH(MessageActionEnum.TEAM_SWITCH.getAction(), "switchTeam", ITeamService.class, Integer.class, true, true),
    ;
    /**
     * 执行的动作，由客户端传给服务端
     */
    @Getter
    private String action;

    /**
     * 该动作对应的执行的方法名
     */
    @Getter
    private String method;

    /**
     * 执行方法的类的Class
     */
    @Getter
    private Class<?> clazz;

    /**
     * 入参的Class类型
     */
    @Getter
    private Class<?> paramClass;

    /**
     * 执行后是否将最新房间信息推送给房间内所有用户
     */
    @Getter
    private boolean fanoutRoom;

    /**
     * 执行后是否将最新队伍信息推送给房间内所有用户
     */
    @Getter
    private boolean fanoutTeam;

    /**
     * 方法名为key，MessageMethodEnum为value的不可变Map
     */
    private static final Map<String, MessageMethodEnum> METHOD_ENUM_MAP = Collections.unmodifiableMap(
            Arrays.stream(MessageMethodEnum.values()).collect(Collectors.toMap(MessageMethodEnum::getAction, Function.identity())));

    /**
     * 根据接口名获取要执行的方法
     *
     * @param action 接口名
     * @return 执行方法
     */
    public static MessageMethodEnum get(@NotNull String action) {
        return METHOD_ENUM_MAP.get(action);
    }
}
