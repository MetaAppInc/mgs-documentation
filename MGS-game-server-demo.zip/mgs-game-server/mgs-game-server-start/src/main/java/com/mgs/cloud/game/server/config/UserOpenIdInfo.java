package com.mgs.cloud.game.server.config;

import com.google.common.base.Strings;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;

/**
 * 在线程上下文获取使用用户的OpenId
 *
 * @author guozheng.zhao
 * @date 2021/2/5
 */
public class UserOpenIdInfo {

    /**
     * 当前用户的openId
     */
    private static ThreadLocal<String> openId = new ThreadLocal<>();

    /**
     * 获取openId，为空直接抛出异常
     *
     * @return openId 开放用户id
     */
    public static String getOpenId() {
        String currentOpenId = openId.get();
        if (Strings.isNullOrEmpty(currentOpenId)) {
            throw new UniversalException(UniversalErrorCode.UNAUTHORIZED);
        }
        return currentOpenId;
    }

    /**
     * 获取openId，返回值可以为空
     *
     * @return openId 开放用户id
     */
    public static String getNullableOpenId() {
        return openId.get();
    }

    /**
     * 设置openId，会在OpenUserTokenAop校验gameToken通过后执行此方法
     *
     * @param id 开放用户id
     */
    public static void setOpenId(String id) {
        clean();
        openId.set(id);
    }

    /**
     * 清除openId
     */
    public static void clean() {
        openId.remove();
    }

}
