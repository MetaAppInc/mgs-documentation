package com.mgs.cloud.game.server.utils;

import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * MD5工具类
 *
 * @author shuai.shao
 */
@Slf4j
public class Md5Util {

    /**
     * Md5加密
     *
     * @param str 字符串
     * @return 加密后的字符串
     */
    public static String md5Encode(String str) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(str.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(bytes);
        } catch (NoSuchAlgorithmException e) {
            log.error("MD5 encode异常:", e);
            throw new UniversalException(UniversalErrorCode.UNAUTHORIZED);
        }
    }

    /**
     * byte[] 转十六进制
     *
     * @param bytes byte[]
     * @return 转换后的字符串
     */
    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString().toUpperCase();
    }

}
