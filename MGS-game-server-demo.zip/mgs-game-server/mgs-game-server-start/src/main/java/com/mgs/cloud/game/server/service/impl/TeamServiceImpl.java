package com.mgs.cloud.game.server.service.impl;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.dto.team.TeamDTO;
import com.mgs.api.game.server.model.enums.mgs.MgsHttpConfig;
import com.mgs.api.game.server.model.enums.room.RoomStateEnum;
import com.mgs.api.game.server.model.enums.room.RoomTypeEnum;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;
import com.mgs.api.game.server.model.qo.mgs.room.DestroyRoomQuery;
import com.mgs.api.game.server.model.qo.mgs.room.SyncInfoQuery;
import com.mgs.api.game.server.model.qo.mgs.team.SyncMemberQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import com.mgs.api.game.server.model.qo.team.CreateTeamQuery;
import com.mgs.api.game.server.model.qo.team.JoinTeamQuery;
import com.mgs.api.game.server.model.qo.team.TeamIdQuery;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomUserVO;
import com.mgs.api.game.server.model.vo.mgs.team.CreateMgsRoomVO;
import com.mgs.api.game.server.model.vo.team.QueryTeamInfoVO;
import com.mgs.api.game.server.model.vo.team.TeamUserVO;
import com.mgs.cloud.game.server.config.UserOpenIdInfo;
import com.mgs.cloud.game.server.mapper.RoomMapper;
import com.mgs.cloud.game.server.mapper.RoomUserMapper;
import com.mgs.cloud.game.server.mapper.TeamMapper;
import com.mgs.cloud.game.server.mapstruct.TeamEntityMapper;
import com.mgs.cloud.game.server.model.entity.room.RoomEntity;
import com.mgs.cloud.game.server.model.entity.room.RoomUserEntity;
import com.mgs.cloud.game.server.model.entity.team.TeamEntity;
import com.mgs.cloud.game.server.service.IMgsHttpService;
import com.mgs.cloud.game.server.service.IRoomService;
import com.mgs.cloud.game.server.service.ITeamService;
import com.mgs.cloud.game.server.websocket.WebSocketServer;
import com.mgs.cloud.game.server.websocket.config.MessageActionEnum;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 注：需要接入MGS的TEAM系统请看此Service，如不需要接入TEAM系统可以忽略
 *
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@Slf4j
@Service
public class TeamServiceImpl implements ITeamService {

    @Autowired
    private IRoomService roomService;

    @Autowired
    private IMgsHttpService mgsHttpService;

    @Resource
    private TeamMapper teamMapper;

    @Resource
    private RoomMapper roomMapper;

    @Resource
    private RoomUserMapper roomUserMapper;

    /**
     * 创建队伍
     * <p>
     * 1. 获取父房间配置、team模式配置
     * 2. 创建team，存储team配置
     * 3. 同步mgs
     *
     * @param createTeam 队伍设置信息
     * @return 队伍信息
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public List<TeamDTO> createTeam(@NotNull CreateTeamQuery createTeam) {
        // 查询team的父房间配置
        RoomEntity roomEntity = roomMapper.selectByRoomId(createTeam.getParentId());
        if (null == roomEntity) {
            throw new UniversalException(UniversalErrorCode.ROOM_NOT_FOUND);
        }
        // 房间类型的配置
        RoomTypeEnum roomConfig = RoomTypeEnum.getEnumTypeByCode(roomEntity.getRoomType());
        if (!roomConfig.getHasTeam()) {
            // 房间无team模式配置
            throw new UniversalException(UniversalErrorCode.TEAM_CONT_CREATE);
        }
        List<TeamDTO> teamList = new ArrayList<>();
        // 根据room的team规模配置，创建出对应的team
        roomConfig.getTeamLimit().forEach(item -> {
            RoomDTO room = roomService.createGameRoom(new RoomEntity().initTeam(createTeam, item).setRoomName(roomEntity.getRoomName()), null);
            TeamDTO team = new TeamDTO().init(room).init(createTeam);
            // team配置入库
            if (0 == teamMapper.insertOne(team)) {
                throw new UniversalException(UniversalErrorCode.TEAM_CREATE_ERROR);
            }
            teamList.add(team);
            // 同步mgs
            CreateMgsRoomVO result = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.TEAM_CREATE, team.toCreateMgsTeamQuery());
            log.info("create mgs team response: {}", result);
        });
        return teamList;
    }

    /**
     * 加入队伍
     * <p>
     * 1. 加入游戏team
     * 2. 查询team信息
     * 3. 封装返回
     *
     * @param joinTeam 队伍id、密码
     * @return 队伍信息
     */
    @Override
    public TeamDTO joinTeam(@NotNull JoinTeamQuery joinTeam) {
        Integer teamId = joinTeam.getTeamId();
        RoomDTO room = roomService.joinGameRoom(teamId, UserOpenIdInfo.getOpenId());
        return queryTeam(teamId, room);
    }

    /**
     * 根据父房间号加入队伍
     * <p>
     * 1. 根据父房间号获取team列表
     * 2. 从team列表找一个未满员的team
     * 3. 加入该team
     *
     * @param parentId roomId
     * @return 是否加入成功
     */
    @Override
    public TeamDTO joinTeamByParentId(@NotNull Integer parentId) {
        List<TeamEntity> teams = teamMapper.listByParentId(parentId);
        if (CollectionUtils.isEmpty(teams)) {
            throw new UniversalException(UniversalErrorCode.TEAM_QUERY_ERROR);
        }
        List<Integer> teamIds = teams.stream().map(TeamEntity::getTeamId).collect(Collectors.toList());
        RoomEntity room = roomMapper.selectOneRoomIdByFullAndRoomIdList(false, teamIds);
        if (null == room) {
            throw new UniversalException(UniversalErrorCode.TEAM_FULL_ERROR);
        }
        TeamDTO team = joinTeam(new JoinTeamQuery(room.getRoomId()));
        log.info("join team by parentId result: {}", team);
        return team;
    }

    /**
     * 查询Team信息
     *
     * @param teamId 队伍id
     * @return team信息
     */
    private TeamDTO queryTeam(@NotNull Integer teamId) {
        RoomDTO room = roomService.queryRoomInfo(new RoomIdQuery(teamId));
        return queryTeam(teamId, room);
    }

    /**
     * 查询Team详细信息，包括team的房间信息
     *
     * @param teamId 队伍id
     * @param room   该队伍继承的房间信息
     * @return team信息
     */
    private TeamDTO queryTeam(@NotNull Integer teamId, @NotNull RoomDTO room) {
        TeamEntity teamEntity = teamMapper.queryByTeamId(teamId);
        TeamDTO team = TeamEntityMapper.INSTANCE.toRoomDTO(teamEntity);
        BeanUtils.copyProperties(room, team);
        return team;
    }

    /**
     * 离开队伍
     * <p>
     * 1. 调用离开房间逻辑
     *
     * @param leave 房间id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public Boolean leaveTeam(@NotNull TeamIdQuery leave) {
        return leaveTeam(leave.getTeamId(), UserOpenIdInfo.getOpenId());
    }

    /**
     * 离开队伍
     * <p>
     * 1. 调用离开房间逻辑
     *
     * @param teamId 房间id
     * @param openId 用户id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    private Boolean leaveTeam(@NotNull Integer teamId, @NotNull String openId) {
        if (!roomService.leaveRoom(teamId, openId)) {
            throw new UniversalException(UniversalErrorCode.TEAM_LEAVE_ERROR);
        }
        return true;
    }

    /**
     * 离开队伍，并广播给房间内其他人
     * <p>
     * 1. 离开队伍
     * 2. 查询队伍的父房间id
     * 3. 广播给父房间所有用户
     *
     * @param leave 队伍id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public Boolean leaveTeamAndFanout(@NotNull TeamIdQuery leave) {
        TeamEntity team = teamMapper.queryByTeamId(leave.getTeamId());
        return roomService.fanout(team.getParentId(), this::leaveTeam, leave);
    }

    /**
     * 销毁队伍
     * <p>
     * 1. 调用销毁房间的逻辑
     * 2. 同步mgs
     *
     * @param destroy 队伍id
     * @return 销毁成功 return {@code true}, 销毁失败 return {@code false}
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public Boolean destroyTeam(@NotNull TeamIdQuery destroy) {
        Integer teamId = destroy.getTeamId();
        if (!roomService.destroyGameRoom(teamId)) {
            throw new UniversalException(UniversalErrorCode.TEAM_DESTROY_ERROR);
        }
        int row = teamMapper.deleteByTeamId(teamId);
        log.info("destroy team[teamId- {}] result: {}", teamId, row);
        // 同步mgs
        Boolean result = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.TEAM_DESTROY, new DestroyRoomQuery().setRoomIdFromCp(teamId.toString()));
        log.info("destroy mgs team[teamId- {}] result: {}", teamId, result);
        return true;
    }

    /**
     * 根据roomId查询team
     *
     * @param parentId roomId
     * @return 该roomId下的team
     */
    @Override
    public List<TeamEntity> listTeamByParentId(@NotNull Integer parentId) {
        List<TeamEntity> teamEntities = teamMapper.listByParentId(parentId);
        if (CollectionUtils.isEmpty(teamEntities)) {
            return new ArrayList<>();
        }
        return teamEntities;
    }

    /**
     * 同步team状态
     *
     * @param parentId 队伍id
     * @param state    状态
     */
    @Override
    public void syncTeamState(@NotNull Integer parentId, @NotNull Integer state) {
        List<TeamEntity> teams = listTeamByParentId(parentId);
        if (CollectionUtils.isEmpty(teams)) {
            return;
        }
        // 队伍分配合理，同步到mgs
        teams.forEach(x -> {
            RoomDTO room = roomService.syncGameRoomInfo(new SyncRoomStateQuery(x.getTeamId(), state));
            // 同步mgs
            Boolean result = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.TEAM_SYNC_INFO, new SyncInfoQuery().init(room));
            log.info("sync team result: {}", result);
        });
    }

    /**
     * 查询队伍详细信息，小队成员信息、小队信息
     *
     * @param query 队伍id
     * @return 小队成员信息、小队信息
     */
    @Override
    public QueryTeamInfoVO queryTeam(@NotNull TeamIdQuery query) {
        TeamDTO team = queryTeam(query.getTeamId());
        List<QueryRoomUserVO> players = roomService.queryUserList(query.toRoomIdQuery());
        return new QueryTeamInfoVO(players, team);
    }

    /**
     * 根据父房间id，将房间内用户随机加入到team
     * <p>
     * 1. 获取房间内所有用户
     * 2. 获取房间下所有team
     * 3. 随机分配成员到team
     * * 分配team逻辑：
     * * 3.1) 遍历房间成员
     * * 3.2) 对team数量取余获取到team的下标，加入team
     * * 3.3) 加入后如果team容量已满，移除team不继续分配成员
     * 4. 遍历分配后的team，将分配结果入库、同步mgs、发送给对应用户
     *
     * @param parentId 父房间id
     */
    @Override
    public void randomJoinTeamByRoomId(@NotNull Integer parentId) {
        // 房间内所有用户
        List<RoomUserEntity> userList = new ArrayList<>(roomUserMapper.listByRoomId(parentId));
        // 该父房间下的所有team
        List<TeamEntity> teamList = teamMapper.listByParentId(parentId);
        // teamId : team的房间信息
        Map<Integer, RoomEntity> teamIdMap = teamList.stream().collect(Collectors.toMap(TeamEntity::getTeamId, x -> roomMapper.selectByRoomId(x.getTeamId())));
        // 最终分配结果，key为队伍id，value为队伍内的成员
        Map<Integer, List<TeamUserVO>> result = teamList.stream().collect(Collectors.toMap(TeamEntity::getTeamId, x -> new ArrayList<>()));
        Integer teamId;
        TeamEntity teamEntity;
        for (int i = 0; i < userList.size(); i++) {
            // team信息
            teamEntity = teamList.get(i % teamList.size());
            teamId = teamEntity.getTeamId();
            // 用户openId加入到team中
            result.get(teamId).add(new TeamUserVO(teamId, userList.get(i).getOpenId()));
            // 加入team后如果team容量已满，则移除team不再继续分配
            if (result.get(teamId).size() >= teamIdMap.get(teamId).getRoomLimit()) {
                teamList.remove(teamEntity);
            }
        }
        result.values().forEach(x -> {
            if (CollectionUtils.isEmpty(x)) {
                throw new UniversalException(UniversalErrorCode.TEAM_GROUP_UNREASONABLE);
            }
        });
        result.forEach((id, list) -> {
            if (CollectionUtils.isEmpty(list)) {
                return;
            }
            List<String> openIdList = list.stream().map(TeamUserVO::getOpenId).collect(Collectors.toList());
            int row = roomService.batchJoinRoom(id, teamIdMap.get(id).getRoomState(), openIdList);
            log.info("roomId[{}] batch join teamId[{}]: {}", parentId, id, row);
        });
    }

    /**
     * 同步team到mgs
     * <p>
     * 1. 查询team内所有成员
     * 2. 成员openId、teamId 同步到mgs
     * 3. mgs同步失败抛出异常，上层业务回滚
     *
     * @param teamId 队伍id
     */
    @Override
    public void syncTeamUserToMgs(@NotNull Integer teamId) {
        // team内所有成员
        List<RoomUserEntity> userList = roomUserMapper.listByRoomId(teamId);
        if (CollectionUtils.isEmpty(userList)) {
            return;
        }
        // openId
        List<String> openIdList = userList.stream().map(RoomUserEntity::getOpenId).collect(Collectors.toList());
        // 同步到mgs
        Boolean syncResult = mgsHttpService.sendPostJsonRequest(MgsHttpConfig.TEAM_SYNC, new SyncMemberQuery(openIdList, teamId.toString()));
        log.info("sync mgs team[{}] member: {}", teamId, syncResult);
        if (!syncResult) {
            throw new UniversalException(UniversalErrorCode.TEAM_SYNC_MEMBER_ERROR);
        }
        // 将分组结果发送给对应用户
        openIdList.forEach(x -> WebSocketServer.sendMessage(new TeamUserVO(teamId, x), MessageActionEnum.TEAM_RANDOM_JOIN.getAction(), x));
    }

    /**
     * 根据父房间id查询队伍信息
     *
     * @param parentId 父房间id
     * @return 该房间下的所有队伍信息
     */
    @Override
    public List<QueryTeamInfoVO> listTeamByRoomId(@NotNull Integer parentId) {
        List<TeamEntity> teams = teamMapper.listByParentId(parentId);
        if (CollectionUtils.isEmpty(teams)) {
            return null;
        }
        return teams.stream().map(x -> queryTeam(new TeamIdQuery(x.getTeamId()))).collect(Collectors.toList());
    }

    /**
     * 根据父房间id离开房间
     *
     * @param parentId 父房间id
     * @param openId   用户id
     */
    @Override
    public void leaveTeamByParentId(@NotNull Integer parentId, @NotNull String openId) {
        List<TeamEntity> teamEntities = teamMapper.listByParentId(parentId);
        if (!CollectionUtils.isEmpty(teamEntities)) {
            teamEntities.forEach(x -> leaveTeam(x.getTeamId(), openId));
        }
    }

    /**
     * 切换team
     *
     * @param teamId teamId
     * @return 切换成功 return {@code true}, 切换失败 return {@code false}
     */
    @Override
    @Transactional(rollbackFor = UniversalException.class)
    public TeamDTO switchTeam(@NotNull Integer teamId) {
        String openId = UserOpenIdInfo.getOpenId();
        TeamEntity teamEntity = teamMapper.queryByTeamId(teamId);
        if (null == teamEntity) {
            throw new UniversalException(UniversalErrorCode.TEAM_QUERY_ERROR);
        }
        // 离开之前的队伍
        leaveTeamByParentId(teamEntity.getParentId(), openId);
        // 加入新队伍
        try {
            return joinTeam(new JoinTeamQuery(teamId));
        } catch (UniversalException e) {
            if (e.getCode() == UniversalErrorCode.ROOM_FULL.getCode()) {
                throw new UniversalException(UniversalErrorCode.TEAM_SWITCH_ERROR);
            }
            throw e;
        }
    }

    /**
     * 同步team成员相关信息
     * <p>
     * 1. 判断是否是room、是否有team配置
     * 2. 根据状态执行相关逻辑
     * * 1) 开始游戏时组建队伍：
     * * * 1.1) 开始游戏：随机分组，分组后校验队伍成员分配是否合理
     * * * 1.2) 结束游戏：清空team成员
     * * 2) 开始游戏前组建队伍：
     * * * 2.1) 开始游戏：校验队伍成员分配是否合理
     * 3. team成员同步到mgs
     *
     * @param roomDTO            房间信息
     * @param syncRoomStateQuery 状态、房间id
     */
    @Override
    public void syncTeamMember(@NotNull RoomDTO roomDTO, @NotNull SyncRoomStateQuery syncRoomStateQuery) {
        Integer roomId = roomDTO.getRoomId();
        RoomTypeEnum roomTypeEnum = RoomTypeEnum.getEnumTypeByCode(roomDTO.getRoomType());
        // 不是room || 无team配置
        if (roomDTO.getHasParent() || !roomTypeEnum.getHasTeam()) {
            return;
        }
        // 房间下的队伍List
        List<TeamEntity> teamEntities = listTeamByParentId(roomId);
        // 是否是开始游戏
        boolean startGame = RoomStateEnum.GAMING.getStateCode().equals(syncRoomStateQuery.getState());
        // 开始游戏时组建队伍
        if (roomTypeEnum.getTeamConfig().getStart()) {
            if (RoomStateEnum.END.getStateCode().equals(syncRoomStateQuery.getState())) {
                // 结束游戏时清空team
                teamEntities.forEach(x -> log.info("clear team[{}] user: {}", x.getTeamId(), roomUserMapper.deleteByRoomId(x.getTeamId())));
            } else if (startGame) {
                // 开始游戏时随机分组
                randomJoinTeamByRoomId(roomId);
            }
        } else if (startGame) {
            // 游戏开始前队伍已经组建完毕，在开始游戏时校验队伍是否分配合理
            teamEntities.forEach(x -> {
                // 开始游戏且队伍中没人，抛出队伍分配不合理异常
                if (CollectionUtils.isEmpty(roomUserMapper.listByRoomId(x.getTeamId()))) {
                    throw new UniversalException(UniversalErrorCode.TEAM_GROUP_UNREASONABLE);
                }
            });
        }
        if (startGame) {
            // 同步用户
            syncTeamUserToMgsByRoomId(roomId);
        }
    }

    /**
     * 同步房间下所有team成员
     *
     * @param roomId 房间id
     */
    private void syncTeamUserToMgsByRoomId(@NotNull Integer roomId) {
        List<TeamEntity> teamList = listTeamByParentId(roomId);
        if (CollectionUtils.isEmpty(teamList)) {
            return;
        }
        // 有team模式的房间，开始游戏时将team成员信息同步给mgs
        teamList.forEach(x -> syncTeamUserToMgs(x.getTeamId()));
    }

}
