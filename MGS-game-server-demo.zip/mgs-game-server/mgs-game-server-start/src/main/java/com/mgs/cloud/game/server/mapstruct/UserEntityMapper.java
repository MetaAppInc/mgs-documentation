package com.mgs.cloud.game.server.mapstruct;

import com.mgs.api.game.server.model.dto.user.UserInfoDTO;
import com.mgs.api.game.server.model.dto.user.UserTokenDTO;
import com.mgs.api.game.server.model.vo.user.UserInfoVO;
import com.mgs.cloud.game.server.config.MapperCommonConfig;
import com.mgs.cloud.game.server.model.entity.user.UserInfoEntity;
import com.mgs.cloud.game.server.model.entity.user.UserTokenEntity;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * 用户实体映射
 *
 * @author guozheng.zhao
 * @date 2021/2/5
 */
@Mapper(config = MapperCommonConfig.class)
public interface UserEntityMapper {

    UserEntityMapper INSTANCE = Mappers.getMapper(UserEntityMapper.class);

    /**
     * UserToken Entity -> DTO
     *
     * @param entity Entity
     * @return DTO
     */
    UserTokenDTO toUserTokenDTO(UserTokenEntity entity);

    /**
     * UserInfo Entity -> DTO
     *
     * @param entity entity
     * @return DTO
     */
    UserInfoDTO toUserInfoDTO(UserInfoEntity entity);

    /**
     * UserInfo DTO -> VO
     *
     * @param dto DTO
     * @return VO
     */
    UserInfoVO toUserInfoVO(UserInfoDTO dto);

}
