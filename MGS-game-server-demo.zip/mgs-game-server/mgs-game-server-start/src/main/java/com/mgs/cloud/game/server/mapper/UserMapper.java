package com.mgs.cloud.game.server.mapper;

import com.mgs.api.game.server.model.dto.user.UserInfoDTO;
import com.mgs.cloud.game.server.model.entity.user.UserInfoEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@Mapper
public interface UserMapper {

    /**
     * 根据用户openId查询用户信息
     *
     * @param openId 开放用户id
     * @return DTO
     */
    @Select("select * from `t_user` where `openId` = #{openId}")
    UserInfoEntity selectByOpenId(@Param("openId") String openId);

    /**
     * 插入/修改用户信息
     *
     * @param userInfo 用户信息
     * @return 受影响的行数
     */
    @Insert("insert into `t_user`(`openId`, `openCode`, `avatar`, `nickname`) " +
            "values(#{userInfo.openId}, #{userInfo.openCode}, #{userInfo.avatar}, #{userInfo.nickname}) " +
            "ON DUPLICATE KEY UPDATE `avatar` = values(`avatar`), `nickname` = values(`nickname`), `openCode` = values(`openCode`)")
    int insertOrUpdateUser(@Param("userInfo") UserInfoDTO userInfo);

    /**
     * 根据openId List查询用户信息
     *
     * @param openIdList openId List
     * @return 对应的用户信息
     */
    @Select({"<script>",
            "select * from `t_user` where `openId` in " +
                    "<foreach collection=\"openIdList\" index=\"index\" item=\"item\" separator=\",\" open=\"(\" close=\")\">" +
                    "#{item}" +
                    "</foreach>",
            "</script>"})
    List<UserInfoEntity> selectByOpenIdList(@Param("openIdList") List<String> openIdList);
}
