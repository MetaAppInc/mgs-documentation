package com.mgs.cloud.game.server.utils;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * 生成 mgs请求头签名验证 的工具类
 *
 * @author shuai.shao
 */
@Slf4j
public class SignUtil {


    /**
     * 请求头中 签名 的key名称
     */
    public static final String SIGN = "sign";

    /**
     * 请求头中 AppKey 的key名称
     */
    public static final String APP_KEY = "appKey";

    /**
     * 用户反射存储类结构  优化性能
     */
    private static Map<Class<?>, List<Field>> propertiesMapper = new ConcurrentHashMap<>();

    /**
     * 获取某个类的所有字段，包括父类的
     *
     * @param object 被获取字段的对象
     * @return 所有字段的List
     */
    public static List<Field> getAllFields(@NotNull Object object) {
        Class<?> clazz = object.getClass();
        List<Field> fieldList = new ArrayList<>();
        while (clazz != null) {
            fieldList.addAll(Arrays.stream(clazz.getDeclaredFields())
                    // 非静态的、是基本类型、String类型、Collection类型  才进行转换
                    .filter(field -> !Modifier.isStatic(field.getModifiers()) && (isPrimitive(field.getType()) || Collection.class.isAssignableFrom(field.getType())))
                    .collect(Collectors.toList()));
            clazz = clazz.getSuperclass();
        }
        // 排序list  根据field的name进行字典序
        return fieldList.stream().sorted(Comparator.comparing(Field::getName)).collect(Collectors.toList());
    }

    /**
     * 将对象中的属性以及数据 获取并排序，生成签名Sign返回
     * 1. 解析入参obj的class，获取属性名和属性值
     * 2. 将类型为基础类型、String类型、Collection类型的属性进行签名计算
     * 3. Collection类型调用this.collectionToString()方法生成字符串
     * 4. 其他类型转成"key=value"的结构拼接字符串
     * 5. 字符串为url格式
     * 6. 字符串尾部拼接key=appSecret
     * 7. 字符串md5加密
     *
     * @param obj       原始对象
     * @param appSecret 密钥
     * @return String 加密后生成的签名
     */
    public static String getSign(@NotNull Object obj, @NotNull String appSecret) {
        Class<?> clazz = obj.getClass();
        // 存在该class，就取出缓存的field结构，否则存入
        List<Field> cacheFields = propertiesMapper.computeIfAbsent(clazz, key -> getAllFields(obj));
        // 查找到了缓存结构
        StringBuilder stringBuilder = new StringBuilder();
        // item为属性名
        cacheFields.forEach(item -> {
            try {
                item.setAccessible(true);
                // 获取到该属性的值
                Object fieldValue = item.get(obj);
                // 为空则不参与签名
                if (Objects.isNull(fieldValue)) {
                    return;
                }
                String valueString;
                if (fieldValue instanceof Collection && !CollectionUtils.isEmpty((Collection<?>) fieldValue)) {
                    // 集合类型，注意：这里不能是无序集合
                    valueString = collectionToString((Collection<?>) fieldValue, item);
                } else {
                    // 其他类型
                    valueString = String.valueOf(fieldValue);
                }
                if (!Objects.isNull(valueString)) {
                    stringBuilder.append(item.getName()).append("=").append(valueString).append("&");
                }

            } catch (IllegalAccessException e) {
                log.error(e.getMessage(), e);
            }
        });
        stringBuilder.append("key=").append(appSecret);
        String msg = stringBuilder.toString();
        log.info("加密的字符串: {}", msg);
        // 根据文档要求要进行
        return md5Sign(msg);
    }

    /**
     * 将Collection转换成 “[”开头、“]”结尾、“,”分割的字符串
     *
     * @param collection collection
     * @param field      当前这个属性的Field
     * @param <E>        Collection泛型
     * @return string
     */
    private static <E> String collectionToString(Collection<E> collection, Field field) {
        collection.removeIf(Objects::isNull);
        Type type = ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0];
        // 泛型不是预期内类型的话，不参与签名校验
        if (!isPrimitive((Class<?>) type)) {
            return null;
        }

        Iterator<E> it = collection.iterator();
        if (!it.hasNext()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (; ; ) {
            sb.append(it.next());
            if (!it.hasNext()) {
                return sb.append(']').toString();
            }
            sb.append(',');
        }
    }

    /**
     * 字符串md5加密
     *
     * @param text 要签名的字符串
     * @return md5加密后的字符串
     */
    public static String md5Sign(String text) {
        if (text == null) {
            throw new IllegalArgumentException("MD5签名明文数据不能为空!");
        }
        return Md5Util.md5Encode(text);
    }

    /**
     * 判断某一个Class是不是
     * 基本类型，基本类型的包装类型，以及String类型
     * 满足以上类型一种，返回true
     *
     * @param cls 类的class对象
     * @return boolean
     */
    public static boolean isPrimitive(Class<?> cls) {
        return cls.isPrimitive() || cls == String.class || cls == Boolean.class || cls == Character.class
                || Number.class.isAssignableFrom(cls);
    }

}
