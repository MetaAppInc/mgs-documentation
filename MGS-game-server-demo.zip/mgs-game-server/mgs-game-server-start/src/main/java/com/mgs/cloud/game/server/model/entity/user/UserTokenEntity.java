package com.mgs.cloud.game.server.model.entity.user;

import com.mgs.cloud.game.server.model.enums.user.TokenInvalidConfig;
import com.mgs.api.game.server.util.TimeUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.Date;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@Data
@ApiModel("用户Token数据库映射实体")
@Accessors(chain = true)
public class UserTokenEntity implements Serializable {

    private static final long serialVersionUID = 8137789426135248660L;

    @ApiModelProperty("用户ID")
    private String openId;

    @ApiModelProperty("token")
    private String token;

    @ApiModelProperty("token失效时间")
    private Date invalidTime;

    /**
     * 初始化
     *
     * @param openId             开放用户id
     * @param tokenInvalidConfig token过期配置
     * @return this
     */
    public UserTokenEntity init(@NotNull String openId, @NotNull TokenInvalidConfig tokenInvalidConfig) {
        return this.setOpenId(openId)
                .createInvalidTime(tokenInvalidConfig)
                .createToken(tokenInvalidConfig);
    }

    /**
     * 根据Token配置创建失效时间
     *
     * @param tokenInvalidConfig token过期配置
     * @return this
     */
    public UserTokenEntity createInvalidTime(@NotNull TokenInvalidConfig tokenInvalidConfig) {
        long invalidTimeMillis = TimeUtil.currentTimeMillis() +
                tokenInvalidConfig.getTimeUnit().toMillis(tokenInvalidConfig.getTime());

        return this.setInvalidTime(new Date(invalidTimeMillis));
    }

    /**
     * 根据Token配置创建token
     *
     * @param tokenInvalidConfig token过期配置
     * @return this
     */
    public UserTokenEntity createToken(@NotNull TokenInvalidConfig tokenInvalidConfig) {
        return this.setToken(tokenInvalidConfig.getCreateTokenFunc().apply(getOpenId()));
    }

}
