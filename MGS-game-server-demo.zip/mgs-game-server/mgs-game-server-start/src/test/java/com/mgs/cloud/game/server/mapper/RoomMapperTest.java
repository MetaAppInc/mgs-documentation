package com.mgs.cloud.game.server.mapper;

import com.mgs.api.game.server.model.enums.room.RoomStateEnum;
import com.mgs.api.game.server.model.enums.room.RoomTypeEnum;
import com.mgs.cloud.game.server.GameServerApplication;
import com.mgs.cloud.game.server.model.entity.room.RoomEntity;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GameServerApplication.class)
@Slf4j
public class RoomMapperTest {

    @Resource
    private RoomMapper roomMapper;

    @Test
    public void insertOne() {
        RoomEntity roomEntity = new RoomEntity()
                .setRoomId(1)
                .setRoomLimit(1)
                .setRoomState(RoomStateEnum.READYING.getStateCode())
                .setRoomType(RoomTypeEnum.TEAM_HIDE_AND_SEEK.getRoomType())
                .setFull(true);
        int row = roomMapper.insertOne(roomEntity);
        log.info("insert one result: {}", row);
        assert row != 0;
    }

    @Test
    public void selectByRoomId() {
        RoomEntity roomEntity = roomMapper.selectByRoomId(1);
        log.info("select by roomId result: {}", roomEntity);
        assert roomEntity != null;
    }

    @Test
    public void updateRoomFull() {
        int row = roomMapper.updateRoomFull(1, false);
        log.info("update room full result: {}", row);
        assert row != 0;
    }

    @Test
    public void selectOneRoomIdByFull() {
        List<Integer> roomId = roomMapper.listTenRoomIdByFull(false, null);
        log.info("select one roomId by full result: {}", roomId);
        assert !CollectionUtils.isEmpty(roomId);
    }

    @Test
    public void updateRoomState() {
        int row = roomMapper.updateRoomState(1, RoomStateEnum.GAMING.getStateCode());
        log.info("update room state result: {}", row);
        assert row != 0;
    }

    @Test
    public void deleteByRoomId() {
        int row = roomMapper.deleteByRoomId(1);
        log.info("delete by roomId result: {}", row);
        assert row != 0;
    }
}
