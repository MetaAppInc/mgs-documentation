package com.mgs.cloud.game.server.mapper;

import com.mgs.cloud.game.server.GameServerApplication;
import com.mgs.cloud.game.server.model.entity.room.RoomUserEntity;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GameServerApplication.class)
@Slf4j
public class RoomUserMapperTest {

    @Resource
    private RoomUserMapper roomUserMapper;

    @Test
    public void insertOne() {
        RoomUserEntity roomUserEntity = new RoomUserEntity(1, "openId");
        roomUserEntity.setId(1);
        roomUserEntity.setUserState(0);
        int row = roomUserMapper.insertOne(roomUserEntity);
        log.info("insert one result: {}", row);
        assert row != 0;
    }

    @Test
    public void selectCountByRoomId() {
        List<String> list = roomUserMapper.selectOpenIdsByRoomId(1);
        log.info("select count by roomId result: {}", list);
        assert !CollectionUtils.isEmpty(list);
    }

    @Test
    public void deleteByRoomIdOpenId() {
        int row = roomUserMapper.deleteByRoomIdOpenId(1, "openId");
        log.info("delete by roomId openId result: {}", row);
        assert row != 0;
    }

    @Test
    public void listByRoomId() {
        List<RoomUserEntity> roomUserEntities = roomUserMapper.listByRoomId(1);
        log.info("list by roomId result: {}", roomUserEntities);
        assert !CollectionUtils.isEmpty(roomUserEntities);
    }
}
