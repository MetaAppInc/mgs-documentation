package com.mgs.cloud.game.server.utils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EncryptUtilTest {

    public static void main(String[] args) {
        String token = "aisndnmaslDFKLJAKdsklnfl424586";

        String encrypt2 = EncryptUtil.aesEncrypt(token);
        log.info("加密之后: {}", encrypt2);
        assert encrypt2 != null;
        String decrypt2 = EncryptUtil.aesDecrypt(encrypt2);
        log.info("解密之后: {}", decrypt2);
        log.info("原token equals 加密后的token: {}", token.equals(decrypt2));
    }

}
