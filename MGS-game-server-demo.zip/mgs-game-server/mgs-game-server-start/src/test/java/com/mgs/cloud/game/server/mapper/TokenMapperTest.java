package com.mgs.cloud.game.server.mapper;

import com.mgs.cloud.game.server.GameServerApplication;
import com.mgs.cloud.game.server.model.entity.user.UserTokenEntity;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.Date;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GameServerApplication.class)
@Slf4j
public class TokenMapperTest {

    @Resource
    private TokenMapper tokenMapper;

    @Test
    public void insertOrUpdateToken() {
        UserTokenEntity userTokenEntity = new UserTokenEntity()
                .setToken("token")
                .setInvalidTime(new Date())
                .setOpenId("openId");
        int row = tokenMapper.insertOrUpdateToken(userTokenEntity);
        log.info("insert or update token result: {}", row);
        assert row != 0;
    }

    @Test
    public void selectUserTokenByToken() {
        UserTokenEntity userTokenEntity = tokenMapper.selectUserTokenByToken("token");
        log.info("select user token by token result: {}", userTokenEntity);
        assert userTokenEntity != null;
    }
}
