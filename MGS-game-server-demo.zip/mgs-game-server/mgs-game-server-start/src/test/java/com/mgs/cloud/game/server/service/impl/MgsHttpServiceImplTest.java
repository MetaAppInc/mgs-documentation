package com.mgs.cloud.game.server.service.impl;

import com.mgs.api.game.server.model.qo.room.CreateRoomQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomInfoVO;
import com.mgs.api.game.server.model.vo.room.RoomVO;
import com.mgs.api.game.server.model.vo.team.QueryTeamInfoVO;
import com.mgs.cloud.game.server.GameServerApplication;
import com.mgs.cloud.game.server.config.AppKeyInfo;
import com.mgs.cloud.game.server.config.UserOpenIdInfo;
import com.mgs.cloud.game.server.service.IRoomService;
import com.mgs.cloud.game.server.service.ITeamService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GameServerApplication.class)
@Slf4j
public class MgsHttpServiceImplTest {

    @Autowired
    private IRoomService roomService;

    @Autowired
    private ITeamService teamService;

    @Test
    public void sendCreatePostJsonRequest() {
        AppKeyInfo.setAppKey("");
        UserOpenIdInfo.setOpenId("");
        RoomVO room = roomService.createRoom(new CreateRoomQuery().setRoomType(102));
        log.info("create room: {}", room);
        Integer roomId = room.getRoomInfo().getRoomId();
        QueryRoomInfoVO queryRoomInfoVO = roomService.queryRoom(new RoomIdQuery(roomId));
        log.info("query room info: {}", queryRoomInfoVO);
        List<QueryTeamInfoVO> queryTeamInfoVOS = teamService.listTeamByRoomId(roomId);
        log.info("query team info: {}", queryTeamInfoVOS);

        roomService.batchCheckFriend(roomId);
    }
}
