package com.mgs.cloud.game.server.mapper;

import com.mgs.api.game.server.model.dto.user.UserInfoDTO;
import com.mgs.cloud.game.server.GameServerApplication;
import com.mgs.cloud.game.server.model.entity.user.UserInfoEntity;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GameServerApplication.class)
@Slf4j
public class UserMapperTest {

    @Resource
    private UserMapper userMapper;

    @Test
    public void insertOrUpdateUser() {
        UserInfoDTO userInfoDTO = new UserInfoDTO()
                .setAvatar("avatar")
                .setNickname("nickname")
                .setOpenCode("openCode")
                .setOpenId("openId");
        int row = userMapper.insertOrUpdateUser(userInfoDTO);
        log.info("insert or update user result: {}", row);
        assert row != 0;
    }

    @Test
    public void selectByOpenId() {
        UserInfoEntity userInfoEntity = userMapper.selectByOpenId("openId");
        log.info("select by openId result: {}", userInfoEntity);
        assert userInfoEntity != null;
    }

    @Test
    public void selectByOpenIdList() {
        List<String> list = new ArrayList<>(Arrays.asList("openId", "openId2"));
        List<UserInfoEntity> userInfoEntities = userMapper.selectByOpenIdList(list);
        log.info("select by openId list result: {}", userInfoEntities);
        assert !CollectionUtils.isEmpty(userInfoEntities);
    }
}

