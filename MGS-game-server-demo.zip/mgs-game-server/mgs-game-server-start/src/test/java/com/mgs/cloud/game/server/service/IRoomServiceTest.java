package com.mgs.cloud.game.server.service;

import com.mgs.api.game.server.model.qo.room.CreateRoomQuery;
import com.mgs.api.game.server.model.qo.room.JoinRoomQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomUserVO;
import com.mgs.api.game.server.model.vo.room.RoomVO;
import com.mgs.cloud.game.server.GameServerApplication;
import com.mgs.cloud.game.server.config.AppKeyInfo;
import com.mgs.cloud.game.server.config.UserOpenIdInfo;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = GameServerApplication.class)
@Slf4j
public class IRoomServiceTest {

    @Autowired
    private IRoomService roomService;

    @Test
    public void createRoom() {
        CreateRoomQuery createRoomQuery = new CreateRoomQuery();
        createRoomQuery.setRoomType(1);
        RoomVO room = roomService.createRoom(createRoomQuery, null);
        log.info("createRoom return: {}", room);
        assert room != null;
    }

    @Test
    public void joinRoom() {
        JoinRoomQuery roomIdQO = new JoinRoomQuery();
        roomIdQO.setRoomId(1);
        RoomVO joined = roomService.joinRoom(roomIdQO);
        log.info("joinRoom return: {}", joined);
        assert joined != null;
    }

    @Test
    public void leaveRoom() {
        RoomIdQuery roomIdQuery = new RoomIdQuery();
        roomIdQuery.setRoomId(1);
        Boolean leaved = roomService.leaveRoom(roomIdQuery);
        log.info("leaveRoom return: {}", leaved);
        assert leaved;
    }

    @Test
    public void syncRoomInfo() {
        SyncRoomStateQuery syncRoomStateQuery = new SyncRoomStateQuery();
        syncRoomStateQuery.setRoomId(1);
        syncRoomStateQuery.setState(1);
        Boolean synced = roomService.syncRoomInfo(syncRoomStateQuery);
        log.info("syncRoom return: {}", synced);
        assert synced;
    }

    @Test
    public void destroyRoom() {
        RoomIdQuery roomIdQuery = new RoomIdQuery();
        roomIdQuery.setRoomId(1);
        Boolean destroyed = roomService.destroyRoom(roomIdQuery);
        log.info("destroyRoom return: {}", destroyed);
        assert destroyed;
    }

    @Test
    public void queryUserList() {
        RoomIdQuery roomIdQuery = new RoomIdQuery();
        roomIdQuery.setRoomId(1000);
        List<QueryRoomUserVO> queryRoomUserVOS = roomService.queryUserList(roomIdQuery);
        log.info("queryRoomUser return: {}", queryRoomUserVOS);
        assert !CollectionUtils.isEmpty(queryRoomUserVOS);
    }

    @Test
    public void leaveRoomAndFanout() {
        RoomIdQuery roomIdQuery = new RoomIdQuery();
        roomIdQuery.setRoomId(1);
        Boolean leaved = roomService.leaveRoomAndFanout(roomIdQuery);
        log.info("leaveRoom return: {}", leaved);
        assert leaved;
    }

    @Test
    public void batchCheckFriend() {
        UserOpenIdInfo.setOpenId("");
        AppKeyInfo.setAppKey("");
        roomService.batchCheckFriend(2372);
    }

    @Test
    public void syncRoomInfoAndFanout() {
        UserOpenIdInfo.setOpenId("");
        AppKeyInfo.setAppKey("");
        roomService.syncRoomInfoAndFanout(new SyncRoomStateQuery(3567, 1));
    }
}