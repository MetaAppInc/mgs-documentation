package com.mgs.api.game.server.model.qo.mgs.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@ToString
@Data
@Accessors(chain = true)
@ApiModel("查询用户信息QO")
public class QueryOpenUserQuery implements Serializable {

    private static final long serialVersionUID = -6895892063529251396L;

    @ApiModelProperty("开放用户CODE")
    private String openCode;

    @ApiModelProperty("开放用户ID")
    private String openId;

}
