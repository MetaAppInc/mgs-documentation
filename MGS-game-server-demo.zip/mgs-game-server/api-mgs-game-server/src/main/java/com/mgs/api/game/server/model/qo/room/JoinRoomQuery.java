package com.mgs.api.game.server.model.qo.room;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.jetbrains.annotations.Nullable;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/24
 */
@ToString
@Data
@ApiModel("加入房间请求参数")
@AllArgsConstructor
@NoArgsConstructor
public class JoinRoomQuery implements Serializable {

    private static final long serialVersionUID = -9210971609494801586L;

    @ApiModelProperty("房间id，默认null")
    @Nullable
    private Integer roomId = null;

    @ApiModelProperty("队伍id，默认null")
    @Nullable
    private Integer teamId = null;

    /**
     * 房间类型码：
     *
     * @see com.mgs.api.game.server.model.enums.room.RoomTypeEnum
     */
    @ApiModelProperty("房间类型码，默认null")
    @Nullable
    private Integer roomType;

    /**
     * 构造
     *
     * @param roomId   房间id
     * @param roomType 房间类型
     */
    public JoinRoomQuery(@Nullable Integer roomId, @Nullable Integer roomType) {
        this.roomId = roomId;
        this.roomType = roomType;
    }
}
