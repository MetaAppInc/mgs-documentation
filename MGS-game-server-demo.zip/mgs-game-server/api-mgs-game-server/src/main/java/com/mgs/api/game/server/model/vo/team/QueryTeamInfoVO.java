package com.mgs.api.game.server.model.vo.team;

import com.mgs.api.game.server.model.dto.team.TeamDTO;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomUserVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/17
 */
@ToString
@Data
@ApiModel("队伍详细信息")
@NoArgsConstructor
@AllArgsConstructor
public class QueryTeamInfoVO implements Serializable {

    private static final long serialVersionUID = -936726448386755867L;

    @ApiModelProperty("玩家列表")
    private List<QueryRoomUserVO> playerList;

    @ApiModelProperty("队伍信息")
    private TeamDTO teamInfo;

}
