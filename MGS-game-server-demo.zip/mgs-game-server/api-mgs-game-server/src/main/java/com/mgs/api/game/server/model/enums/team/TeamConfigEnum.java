package com.mgs.api.game.server.model.enums.team;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * 队伍信息配置
 * <p>
 *
 * @author guozheng.zhao
 * @date 2021/3/16
 */
@AllArgsConstructor
public enum TeamConfigEnum {
    // 游戏开始前组队
    JOIN_BEFORE_GAME_START(true, false, 1, 2),
    // 游戏开始时随机组队
    JOIN_WHEN_GAME_START(false, true, 1, 2),
    ;
    /**
     * 是否在加入房间时加入team
     */
    @Getter
    private Boolean join;

    /**
     * 是否在游戏开始时加入team
     */
    @Getter
    private Boolean start;

    /**
     * 聊天室能力范围: 0无,1Room,2Team
     */
    @Getter
    @Setter
    private Integer chatScope;

    /**
     * 开麦能力范围: 0无,1Room,2Team
     */
    @Getter
    @Setter
    private Integer voiceScope;
}
