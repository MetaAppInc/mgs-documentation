package com.mgs.api.game.server.model.enums.user;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 房间内用户状态
 *
 * @author guozheng.zhao
 * @date 2021/3/10
 */
@AllArgsConstructor
public enum UserStateEnum {
    // 用户在房间内的状态
    UNPREPARED(0, "未准备"),
    READY(1, "已准备"),
    ;
    /**
     * 状态码
     */
    @Getter
    private Integer stateCode;

    /**
     * 状态描述
     */
    @Getter
    private String stateDescription;
}
