package com.mgs.api.game.server.model.dto.room;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@ToString
@Data
@ApiModel("房间-用户 DTO")
public class RoomUserDTO implements Serializable {

    private static final long serialVersionUID = 1726962731710321295L;

    @ApiModelProperty("房间id")
    private Integer roomId;

    @ApiModelProperty("开放用户id")
    private String openId;

}
