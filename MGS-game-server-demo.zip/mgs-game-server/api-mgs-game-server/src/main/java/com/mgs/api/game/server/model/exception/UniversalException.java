package com.mgs.api.game.server.model.exception;

import com.mgs.api.game.server.model.enums.ErrorCodeDictBase;
import org.jetbrains.annotations.NotNull;

import java.text.MessageFormat;

/**
 * 通用异常
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
public class UniversalException extends RuntimeException {
    private final int code;

    /**
     * 根据ErrorCodeDictBase配置的code、msg构造
     *
     * @param dict code、msg配置
     */
    public UniversalException(@NotNull ErrorCodeDictBase dict) {
        super(dict.getMsg());
        this.code = dict.getCode();
    }

    /**
     * 根据ErrorCodeDictBase配置的code、msg构造
     *
     * @param dict code、msg配置
     * @param args mgs格式化
     */
    public UniversalException(@NotNull ErrorCodeDictBase dict, @NotNull Object... args) {
        super(dict.getMsg(args));
        this.code = dict.getCode();
    }

    /**
     * 根据code、message构造
     *
     * @param code    状态码
     * @param message 返回消息
     * @param e       触发的异常
     */
    public UniversalException(int code, @NotNull String message, @NotNull Throwable e) {
        super(message, e);
        this.code = code;
    }

    /**
     * 根据code、message构造
     *
     * @param code    状态码
     * @param message 返回消息
     * @param args    message格式化
     */
    public UniversalException(int code, @NotNull String message, @NotNull Object... args) {
        super(String.format(message, args));
        this.code = code;
    }

    /**
     * 根据message构造，code 500
     *
     * @param message 返回消息
     * @param args    message格式化
     */
    public UniversalException(String message, Object... args) {
        super(String.format(message, args));
        this.code = 500;
    }

    /**
     * 获取返回状态码
     *
     * @return code
     */
    public int getCode() {
        return this.code;
    }

    @Override
    public String toString() {
        return MessageFormat.format("{0}[{1}]", this.getCode(), this.getMessage());
    }

}
