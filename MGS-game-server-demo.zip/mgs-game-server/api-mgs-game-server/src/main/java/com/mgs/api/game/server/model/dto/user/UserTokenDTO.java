package com.mgs.api.game.server.model.dto.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@ToString
@Data
@ApiModel("用户Token DTO")
@Accessors(chain = true)
public class UserTokenDTO implements Serializable {

    private static final long serialVersionUID = 8577661618467891255L;

    @ApiModelProperty("用户ID")
    private String openId;

    @ApiModelProperty("token")
    private String token;

    @ApiModelProperty("token失效时间")
    private Date invalidTime;

}
