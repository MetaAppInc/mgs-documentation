package com.mgs.api.game.server.model.enums.mgs;

import com.mgs.api.game.server.model.qo.mgs.room.CreateMgsRoomQuery;
import com.mgs.api.game.server.model.qo.mgs.room.DestroyRoomQuery;
import com.mgs.api.game.server.model.qo.mgs.room.SyncInfoQuery;
import com.mgs.api.game.server.model.qo.mgs.team.CreateMgsTeamQuery;
import com.mgs.api.game.server.model.qo.mgs.team.SyncMemberQuery;
import com.mgs.api.game.server.model.qo.mgs.user.BatchCheckFriendQuery;
import com.mgs.api.game.server.model.qo.mgs.user.QueryOpenUserQuery;
import com.mgs.api.game.server.model.qo.mgs.user.RemoveUserQuery;
import com.mgs.api.game.server.model.vo.mgs.room.CreateRoomVO;
import com.mgs.api.game.server.model.vo.mgs.team.CreateMgsRoomVO;
import com.mgs.api.game.server.model.vo.mgs.user.QueryOpenUserVO;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 请求MGS服务端的url、request、response配置
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@AllArgsConstructor
public enum MgsHttpConfig {
    /**
     * 包含请求的url，请求参数、返回值的Class类型
     * <p>
     * 如果新增加对mgs的http调用，可以实现在此类新增配置后通过IMgsHttpService.sendPostJsonRequest调用
     */
    /*
    ROOM相关接口配置
     */
    USER_QUERY("/api/cp/mgsCp/openUser/query", "查询用户信息", QueryOpenUserQuery.class, QueryOpenUserVO.class),
    ROOM_SYNC_INFO("/api/cp/mgsCp/room/syncInfo", "同步房间信息", SyncInfoQuery.class, Boolean.class),
    ROOM_DESTROY("/api/cp/mgsCp/room/destroy", "销毁房间", DestroyRoomQuery.class, Boolean.class),
    ROOM_CREATE("/api/cp/mgsCp/room/create", "创建房间", CreateMgsRoomQuery.class, CreateRoomVO.class),
    ROOM_REMOVE("/api/cp/mgsCp/room/removeMember", "删除房间用户", RemoveUserQuery.class, Boolean.class),
    ROOM_SYNC("/api/cp/mgsCp/room/syncMember", "同步房间成员", SyncMemberQuery.class, Boolean.class),

    /*
    TEAM相关接口配置
     */
    TEAM_CREATE("/api/cp/mgsCp/team/create", "创建队伍", CreateMgsTeamQuery.class, CreateMgsRoomVO.class),
    TEAM_DESTROY("/api/cp/mgsCp/team/destroy", "销毁队伍", DestroyRoomQuery.class, Boolean.class),
    TEAM_SYNC_INFO("/api/cp/mgsCp/team/syncInfo", "同步队伍信息", SyncInfoQuery.class, Boolean.class),
    TEAM_REMOVE("/api/cp/mgsCp/team/removeMember", "删除队伍用户", RemoveUserQuery.class, Boolean.class),
    TEAM_SYNC("/api/cp/mgsCp/team/syncMember", "同步Team成员", SyncMemberQuery.class, Boolean.class),

    FRIEND_CHECK("/api/cp/mgsCp/friend/isFriendByBatch", "批量检查好友关系", BatchCheckFriendQuery.class, Map.class),
    ;

    /**
     * value
     */
    @Getter
    private String url;

    /**
     * 备注
     */
    @Getter
    private String node;

    /**
     * 请求参数的request的类型
     */
    @Getter
    private Class<?> requestClazz;

    /**
     * 返回的response的类型
     */
    @Getter
    private Class<?> responseClazz;
}
