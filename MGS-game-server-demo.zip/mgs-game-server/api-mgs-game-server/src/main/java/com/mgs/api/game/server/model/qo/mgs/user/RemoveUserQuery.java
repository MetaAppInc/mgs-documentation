package com.mgs.api.game.server.model.qo.mgs.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/3/19
 */
@Data
@ToString
@ApiModel("移除房间用户")
@NoArgsConstructor
@AllArgsConstructor
public class RemoveUserQuery implements Serializable {

    private static final long serialVersionUID = 6748116547037170467L;

    @ApiModelProperty("用户id")
    private String openId;

    @ApiModelProperty("房间id")
    private String roomIdFromCp;

}
