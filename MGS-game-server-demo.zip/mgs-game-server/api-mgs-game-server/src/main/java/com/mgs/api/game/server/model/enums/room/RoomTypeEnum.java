package com.mgs.api.game.server.model.enums.room;

import com.mgs.api.game.server.model.enums.team.TeamConfigEnum;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;
import lombok.Getter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 房间类型
 * <p>
 * roomType用于和客户端交互
 * roomLimit表示该房间的人员容量配置
 * teamConfig表示房间的Team模式配置信息
 * teamLimit表示队伍的规模，集合size表示队伍总数，每个元素代表每个队伍的成员数量，所有元素总和应等于roomLimit
 *
 * @author guozheng.zhao
 * @date 2021/2/7
 */
public enum RoomTypeEnum {
    /**
     * 1 V 7
     */
    ONE_VS_SEVEN(3, 8, 1, 7),
    /**
     * 5 V 5 TEAM模式，游戏开始前进行组队
     */
    TEAM_FIVE_VS_FIVE(101, TeamConfigEnum.JOIN_BEFORE_GAME_START, 10, 5, 5),
    /**
     * 捉迷藏模式 TEAM模式，游戏开始时随机组队
     */
    TEAM_HIDE_AND_SEEK(102, TeamConfigEnum.JOIN_WHEN_GAME_START, 10, 2, 8),
    ;

    /**
     * 房间类型
     */
    @Getter
    private Integer roomType;

    /**
     * Team模式的配置
     */
    @Getter
    private TeamConfigEnum teamConfig;

    /**
     * 房间成员容量
     */
    @Getter
    private Integer roomLimit;

    /**
     * 房间内的队伍规模
     */
    @Getter
    private List<Integer> teamLimit;

    /**
     * 构造
     *
     * @param roomType   房间类型
     * @param teamConfig Team模式配置
     * @param roomLimit  预期房间成员容量
     * @param teamLimit  房间内队伍的规模
     */
    RoomTypeEnum(@NotNull Integer roomType, @NotNull TeamConfigEnum teamConfig, @Nullable Integer roomLimit, @NotNull Integer... teamLimit) {
        this(roomType, roomLimit, teamLimit);
        this.teamConfig = teamConfig;
    }

    /**
     * 构造
     *
     * @param roomType  房间类型
     * @param roomLimit 预期房间成员容量
     * @param teamLimit 房间内队伍的规模
     */
    RoomTypeEnum(@NotNull Integer roomType, @Nullable Integer roomLimit, @NotNull Integer... teamLimit) {
        List<Integer> list;
        if (teamLimit.length == 0) {
            // 不配置房间类型报错
            throw new UniversalException(UniversalErrorCode.ROOM_CONFIG_ERROR);
        }
        list = Arrays.asList(teamLimit);
        Integer actualRoomLimit = list.stream().mapToInt(x -> x).sum();
        if (roomLimit != null && !actualRoomLimit.equals(roomLimit)) {
            // 校验预期房间容量和实际配置房间容量是否一致
            throw new UniversalException(UniversalErrorCode.ROOM_CONFIG_ERROR);
        }
        this.roomType = roomType;
        this.roomLimit = actualRoomLimit;
        this.teamLimit = list;
    }

    /**
     * roomType : RoomTypeEnum的不可变Map
     */
    private static final Map<Integer, RoomTypeEnum> ENUM_CODE_MAPPER = Collections.unmodifiableMap(
            Arrays.stream(RoomTypeEnum.values()).collect(Collectors.toMap(e -> e.roomType, v -> v)));

    /**
     * 根据房间类型获取配置
     *
     * @param roomType 房间类型
     * @return 房间配置
     */
    public static RoomTypeEnum getEnumTypeByCode(@NotNull Integer roomType) {
        return ENUM_CODE_MAPPER.get(roomType);
    }

    /**
     * 获取是否有team配置
     *
     * @return 是否有team配置
     */
    public Boolean getHasTeam() {
        return !Objects.isNull(teamConfig);
    }
}
