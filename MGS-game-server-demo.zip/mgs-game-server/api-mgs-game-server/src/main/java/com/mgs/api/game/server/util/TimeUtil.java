package com.mgs.api.game.server.util;

import java.util.concurrent.TimeUnit;

/**
 * 获取当前时间的工具类，统一使用此类获取当前系统时间
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
public final class TimeUtil {

    /**
     * 当前系统时间毫秒数，只被一个线程修改且是线程间可见的
     */
    private static volatile long currentTimeMillis = System.currentTimeMillis();

    public TimeUtil() {
    }

    /**
     * 需要获取当前系统时间，统一使用这个方法获取
     *
     * @return currentTimeMillis
     */
    public static long currentTimeMillis() {
        return currentTimeMillis;
    }

    static {
        Thread daemon = new Thread(() -> {
            while (true) {
                // 每毫秒更新currentTimeMillis
                TimeUtil.currentTimeMillis = System.currentTimeMillis();

                try {
                    TimeUnit.MILLISECONDS.sleep(1L);
                } catch (Throwable ignored) {
                }
            }
        });
        daemon.setDaemon(true);
        daemon.setName("api-time-tick-thread");
        daemon.start();
    }

}
