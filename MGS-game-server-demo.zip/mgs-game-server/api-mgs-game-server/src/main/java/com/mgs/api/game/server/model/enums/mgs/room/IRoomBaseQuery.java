package com.mgs.api.game.server.model.enums.mgs.room;

import java.io.Serializable;

/**
 * 房间相关接口QO Base
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
public interface IRoomBaseQuery extends Serializable {

    /**
     * 来自cp的房间ID
     *
     * @return String
     */
    String getRoomIdFromCp();

}
