package com.mgs.api.game.server.model.vo.user;

import com.mgs.api.game.server.model.dto.user.UserInfoDTO;
import com.mgs.api.game.server.model.dto.user.UserTokenDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@ToString
@Data
@ApiModel("用户登录返回VO")
@AllArgsConstructor
@NoArgsConstructor
public class UserLoginVO implements Serializable {

    private static final long serialVersionUID = -126832572134681240L;

    @ApiModelProperty("用户信息")
    private UserInfoDTO userInfo;

    @ApiModelProperty("token信息")
    private UserTokenDTO tokenInfo;

}
