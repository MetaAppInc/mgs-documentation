package com.mgs.api.game.server.model.qo.team;

import com.mgs.api.game.server.model.enums.team.TeamConfigEnum;
import com.mgs.api.game.server.model.qo.room.CreateRoomQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;

/**
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@EqualsAndHashCode(callSuper = true)
@ToString
@Data
@ApiModel("创建队伍请求参数")
@Accessors(chain = true)
public class CreateTeamQuery extends CreateRoomQuery {

    private static final long serialVersionUID = -4818123241424263515L;

    @NotNull(message = "聊天室范围不能为空")
    @ApiModelProperty("聊天室能力范围: 0无,1Room,2Team")
    private Integer chatScope;

    @NotNull(message = "开麦范围不能为空")
    @ApiModelProperty("开麦能力范围: 0无,1Room,2Team")
    private Integer voiceScope;

    @NotNull(message = "房间id不能为空")
    @ApiModelProperty("房间的id，表示该team在哪个房间下")
    private Integer parentId;

    /**
     * 初始化
     *
     * @param teamConfig team模式的配置
     * @param parentId   父房间id
     * @return this
     */
    public CreateTeamQuery init(@NotNull TeamConfigEnum teamConfig, @NotNull Integer parentId) {
        return this.setChatScope(teamConfig.getChatScope())
                .setVoiceScope(teamConfig.getVoiceScope())
                .setParentId(parentId);
    }

}
