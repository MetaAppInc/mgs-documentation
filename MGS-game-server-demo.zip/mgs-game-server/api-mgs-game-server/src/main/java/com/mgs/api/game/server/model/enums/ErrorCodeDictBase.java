package com.mgs.api.game.server.model.enums;

/**
 * 返回错误码Base
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
public interface ErrorCodeDictBase {

    /**
     * 获取code状态码
     *
     * @return code
     */
    Integer getCode();

    /**
     * 获取返回的message
     *
     * @return msg
     */
    String getMsg();

    /**
     * 获取格式化的message
     *
     * @param var1 format
     * @return String.format(this.msg, var1)
     */
    String getMsg(Object... var1);

}
