package com.mgs.api.game.server.model.dto.user;

import com.mgs.api.game.server.model.vo.mgs.user.QueryOpenUserVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@ToString
@Data
@ApiModel("用户信息DTO")
@Accessors(chain = true)
public class UserInfoDTO implements Serializable {

    private static final long serialVersionUID = -3514662660957176961L;

    @ApiModelProperty("用户ID")
    private String openId;

    @ApiModelProperty("开放用户CODE")
    private String openCode;

    @ApiModelProperty("用户头像")
    private String avatar;

    @ApiModelProperty("用户昵称")
    private String nickname;

    /**
     * 初始化
     *
     * @param vo       VO数据
     * @param openCode 开放用户CODE
     * @return this
     */
    public UserInfoDTO init(@NotNull QueryOpenUserVO vo, @NotNull String openCode) {
        return this
                .setOpenId(vo.getOpenId())
                .setOpenCode(openCode)
                .setAvatar(vo.getAvatar())
                .setNickname(vo.getNickname());
    }
}
