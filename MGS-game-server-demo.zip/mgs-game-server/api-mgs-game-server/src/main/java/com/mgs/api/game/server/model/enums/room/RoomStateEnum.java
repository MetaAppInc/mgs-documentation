package com.mgs.api.game.server.model.enums.room;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 房间状态码
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@AllArgsConstructor
public enum RoomStateEnum {
    // 房间状态码和状态对应关系，和mgs房间状态一致
    READYING(0, "准备中"),
    GAMING(1, "游戏中"),
    END(2, "游戏结束");

    /**
     * 房间状态码
     */
    @Getter
    private Integer stateCode;

    /**
     * 房间状态描述
     */
    @Getter
    private String stateDescription;
}
