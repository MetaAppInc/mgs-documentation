package com.mgs.api.game.server.model.qo.room;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@ToString
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel("加入房间请求参数")
public class RoomIdQuery implements Serializable {

    private static final long serialVersionUID = 3995410863683551340L;

    @ApiModelProperty("房间id")
    @NotNull(message = "房间id不能为空")
    private Integer roomId;

}
