package com.mgs.api.game.server.model.vo.mgs.team;

import com.mgs.api.game.server.model.vo.mgs.room.CreateRoomVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author guozheng.zhao
 * @date 2021/3/16
 */
@EqualsAndHashCode(callSuper = true)
@ToString
@Data
@ApiModel("创建队伍返回数据VO")
public class CreateMgsRoomVO extends CreateRoomVO {

    private static final long serialVersionUID = 3860563946584458348L;

    @ApiModelProperty("开麦能力范围: 0无,1Room,2Team")
    private Integer voiceScope;

    @ApiModelProperty("聊天室能力范围: 0无,1Room,2Team")
    private Integer roomChatScope;

    @ApiModelProperty("父房间ID")
    private String parentIdFromCp;

}
