package com.mgs.api.game.server.api;

import com.mgs.api.game.server.model.qo.mgs.user.QueryOpenUserQuery;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.api.game.server.model.vo.user.UserLoginVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@RequestMapping("/game/server/user")
@Api(tags = "游戏服务端API接口 -- 用户相关")
public interface UserApi {

    /**
     * 用户登录，检查用户信息更新并生成gameToken返回
     *
     * @param qo openCode、openId
     * @return 用户信息、token信息
     */
    @ApiOperation("用户登录")
    @PostMapping("/login")
    Response<UserLoginVO> login(@RequestBody QueryOpenUserQuery qo);

}
