package com.mgs.api.game.server.model.vo.mgs.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@ToString
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel("查询用户信息VO")
public class QueryOpenUserVO {

    @ApiModelProperty("用户头像")
    private String avatar;

    @ApiModelProperty("用户昵称")
    private String nickname;

    @ApiModelProperty("用户ID")
    private String openId;

}
