package com.mgs.api.game.server.model.vo.mgs.room;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/24
 */
@ToString
@Data
@ApiModel("房间详细信息")
@NoArgsConstructor
@AllArgsConstructor
public class QueryRoomInfoVO implements Serializable {

    private static final long serialVersionUID = 9069438457507625335L;

    @ApiModelProperty("玩家列表")
    private List<QueryRoomUserVO> playerList;

    @ApiModelProperty("房间信息")
    private RoomDTO roomInfo;

}
