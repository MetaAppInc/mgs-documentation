package com.mgs.api.game.server.model.dto.team;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.qo.mgs.team.CreateMgsTeamQuery;
import com.mgs.api.game.server.model.qo.team.CreateTeamQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@EqualsAndHashCode(callSuper = true)
@ToString
@Data
@ApiModel("队伍DTO")
@Accessors(chain = true)
public class TeamDTO extends RoomDTO implements Serializable {

    private static final long serialVersionUID = -7608862083141783536L;

    @ApiModelProperty("聊天室能力范围: 0无,1Room,2Team")
    private Integer chatScope;

    @ApiModelProperty("开麦能力范围: 0无,1Room,2Team")
    private Integer voiceScope;

    @ApiModelProperty("房间的id，表示该team在哪个房间下")
    private Integer parentId;

    @ApiModelProperty("队伍id")
    private Integer teamId;

    /**
     * 初始化
     *
     * @param create 创建队伍请求入参
     * @return this
     */
    public TeamDTO init(@NotNull CreateTeamQuery create) {
        return this.setChatScope(create.getChatScope())
                .setVoiceScope(create.getVoiceScope())
                .setParentId(create.getParentId());
    }

    /**
     * 初始化
     *
     * @param room 房间信息
     * @return this
     */
    public TeamDTO init(@NotNull RoomDTO room) {
        BeanUtils.copyProperties(room, this);
        return this.setTeamId(room.getRoomId());
    }

    /**
     * 封装成CreateMgsTeamQO返回
     *
     * @return CreateMgsTeamQO
     */
    public CreateMgsTeamQuery toCreateMgsTeamQuery() {
        CreateMgsTeamQuery result = new CreateMgsTeamQuery();
        result.setRoomIdFromCp(this.getTeamId().toString())
                .setRoomLimit(this.getRoomLimit())
                .setRoomState(this.getRoomState())
                .setRoomName(this.getRoomName());

        return result.setParentIdFromCp(this.getParentId().toString())
                .setRoomChatScope(this.getChatScope())
                .setVoiceScope(this.getVoiceScope());
    }
}
