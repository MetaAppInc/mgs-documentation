package com.mgs.api.game.server.model.qo.team;

import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/3/15
 */
@ToString
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel("加入队伍请求参数")
public class TeamIdQuery implements Serializable {

    private static final long serialVersionUID = -5751126442179458370L;

    @NotNull(message = "队伍id不能为空")
    @ApiModelProperty("队伍id")
    private Integer teamId;

    /**
     * TeamId -> RoomId
     *
     * @return RoomIdQO
     */
    public RoomIdQuery toRoomIdQuery() {
        return new RoomIdQuery(teamId);
    }

}
