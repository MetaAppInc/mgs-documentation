package com.mgs.api.game.server.model.qo.room;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@ToString
@Data
@ApiModel("同步房间状态请求参数")
@AllArgsConstructor
@NoArgsConstructor
public class SyncRoomStateQuery implements Serializable {

    private static final long serialVersionUID = -2732720454265435993L;

    @NotNull(message = "房间号不能为空")
    @ApiModelProperty("房间号")
    private Integer roomId;

    /**
     * 房间状态码：
     *
     * @see com.mgs.api.game.server.model.enums.room.RoomStateEnum
     */
    @NotNull(message = "房间状态不能为空")
    @ApiModelProperty("房间状态码: 0准备中, 1游戏中, 2游戏结束")
    private Integer state;

}
