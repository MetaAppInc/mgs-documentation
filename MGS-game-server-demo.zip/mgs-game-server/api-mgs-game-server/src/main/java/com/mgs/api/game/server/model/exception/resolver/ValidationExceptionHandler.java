package com.mgs.api.game.server.model.exception.resolver;

import com.mgs.api.game.server.model.vo.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Objects;

/**
 * 使用@valid或@Validated校验参数异常统一处理的handler
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@RestControllerAdvice
@ControllerAdvice
@Slf4j
public class ValidationExceptionHandler {

    public ValidationExceptionHandler() {
    }

    /**
     * 处理@valid或@Validated自动绑定的校验结果
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Response<?> validationBodyException(MethodArgumentNotValidException exception) {
        BindingResult validResult = exception.getBindingResult();
        if (validResult.hasErrors()) {
            // 获取默认第一条错误信息
            String defaultMessage = Objects.requireNonNull(validResult.getFieldError()).getDefaultMessage();
            log.warn("MethodArgumentNotValidException throws , message [{}]", defaultMessage);
            return Response.transformByHttpStatus(HttpStatus.BAD_REQUEST, defaultMessage);
        }
        return Response.transformByHttpStatus(HttpStatus.BAD_REQUEST);
    }
}
