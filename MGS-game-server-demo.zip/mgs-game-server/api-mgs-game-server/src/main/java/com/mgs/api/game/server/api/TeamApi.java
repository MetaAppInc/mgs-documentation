package com.mgs.api.game.server.api;

import com.mgs.api.game.server.model.dto.team.TeamDTO;
import com.mgs.api.game.server.model.qo.team.CreateTeamQuery;
import com.mgs.api.game.server.model.qo.team.JoinTeamQuery;
import com.mgs.api.game.server.model.qo.team.TeamIdQuery;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.api.game.server.model.vo.team.QueryTeamInfoVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@RequestMapping("/game/server/team")
@Api(tags = "游戏服务端API接口 -- TEAM相关")
public interface TeamApi {

    /**
     * 创建小队
     * <p>
     * 创建出父房间配置的team规模对应数量的team
     *
     * @param create 房间参数、队伍参数
     * @return 创建的小队列表
     */
    @ApiOperation("创建小队")
    @PostMapping("/create")
    Response<List<TeamDTO>> createTeam(@RequestBody @Valid CreateTeamQuery create);

    /**
     * 加入小队
     *
     * @param join 队伍id、队伍密码
     * @return 队伍配置信息
     */
    @ApiOperation("加入小队")
    @PostMapping("/join")
    Response<TeamDTO> joinTeam(@RequestBody JoinTeamQuery join);

    /**
     * 离开小队
     * <p>
     * 小队内的最后一人离开，会触发销毁小队的逻辑
     *
     * @param leave 离开的小队id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    @ApiOperation("离开小队")
    @PostMapping("/leave")
    Response<Boolean> leaveTeam(@RequestBody TeamIdQuery leave);

    /**
     * 同上，额外多了一个广播给房间内长连接的操作
     *
     * @param leave 离开的小队id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    @ApiOperation("离开小队，并广播给其他用户")
    @PostMapping("/leaveTeamAndFanout")
    Response<Boolean> leaveTeamAndFanout(@RequestBody TeamIdQuery leave);

    /**
     * 销毁小队
     *
     * @param destroy 销毁的小队id
     * @return 销毁成功 return {@code true}, 销毁失败 return {@code false}
     */
    @ApiOperation("销毁小队")
    @PostMapping("/destroy")
    Response<Boolean> destroyTeam(@RequestBody TeamIdQuery destroy);

    /**
     * 获取小队的详细信息：小队内的玩家列表、队伍的配置信息
     *
     * @param query 查询的小队id
     * @return 小队内玩家列表、队伍的配置信息
     */
    @ApiOperation("获取队伍详细信息：玩家列表、队伍信息")
    @PostMapping("/query")
    Response<QueryTeamInfoVO> queryTeam(@RequestBody TeamIdQuery query);

    /**
     * 修改队伍config设置
     *
     * @param chatScope  聊天室能力范围: 0无,1Room,2Team
     * @param voiceScope 开麦能力范围: 0无,1Room,2Team
     * @return 修改后的配置String
     */
    @PostMapping("/teamConfig")
    Response<String> teamConfig(@RequestParam("chatScope") Integer chatScope, @RequestParam("voiceScope") Integer voiceScope);
}
