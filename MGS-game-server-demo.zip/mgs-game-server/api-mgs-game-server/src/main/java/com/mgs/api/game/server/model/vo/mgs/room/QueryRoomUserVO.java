package com.mgs.api.game.server.model.vo.mgs.room;

import com.mgs.api.game.server.model.vo.user.UserInfoVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@ToString
@Data
@ApiModel("房间内的玩家信息")
@Accessors(chain = true)
public class QueryRoomUserVO implements Serializable {

    private static final long serialVersionUID = 494981568132201421L;

    @ApiModelProperty("用户信息")
    private UserInfoVO userInfo;

    /**
     * 玩家状态
     *
     * @see com.mgs.api.game.server.model.enums.user.UserStateEnum
     */
    @ApiModelProperty("玩家状态: 0 未准备, 1 准备；默认准备")
    private Integer userState;
}
