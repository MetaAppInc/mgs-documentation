package com.mgs.api.game.server.model.dto.room;

import com.google.common.base.Strings;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * roomTags房间标签List和String转换
 * <p>
 * 实现RoomTags接口：
 * getListByRoomTag方法将roomTags String转换成List；
 * setRoomTagsByList方法会将List转换成String并调用setRoomTags；
 *
 * @author guozheng.zhao
 * @date 2021/2/24
 */
public interface RoomTags<T extends RoomTags> extends Serializable {

    /**
     * 获取房间标签字符串
     *
     * @return roomTags
     */
    String getRoomTags();

    /**
     * 修改房间标签字符串
     *
     * @param roomTagStr 房间标签字符串
     * @return this
     */
    T setRoomTags(@Nullable String roomTagStr);

    /**
     * String标签转List
     *
     * @return list
     */
    default List<String> getListByRoomTag() {
        if (Strings.isNullOrEmpty(getRoomTags())) {
            return null;
        }
        return new ArrayList<>(Arrays.asList(getRoomTags().split(",")));
    }

    /**
     * List标签转String
     *
     * @param tagList 标签List
     * @return 标签str
     */
    default T setRoomTagsByList(@NotNull List<String> tagList) {
        if (CollectionUtils.isEmpty(tagList)) {
            return setRoomTags(null);
        }
        return setRoomTags(String.join(",", tagList));
    }
}
