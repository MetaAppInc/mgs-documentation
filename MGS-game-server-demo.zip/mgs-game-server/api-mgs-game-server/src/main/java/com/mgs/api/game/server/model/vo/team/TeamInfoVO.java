package com.mgs.api.game.server.model.vo.team;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/18
 */
@Data
@ToString
@ApiModel("小队和玩家列表VO")
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
public class TeamInfoVO implements Serializable {

    private static final long serialVersionUID = -8397899135961788861L;

    @ApiModelProperty("队伍id")
    private Integer teamId;

    @ApiModelProperty("该小队内的玩家id")
    private List<String> playerList;

}
