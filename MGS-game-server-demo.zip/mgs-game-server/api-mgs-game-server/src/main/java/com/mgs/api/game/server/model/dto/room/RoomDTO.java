package com.mgs.api.game.server.model.dto.room;

import com.mgs.api.game.server.model.qo.mgs.room.CreateMgsRoomQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@ToString
@Data
@ApiModel("房间DTO")
@Accessors(chain = true)
public class RoomDTO implements RoomTags<RoomDTO> {

    private static final long serialVersionUID = -8759244524319410615L;

    @ApiModelProperty("房间号")
    private Integer roomId;

    @ApiModelProperty("房间成员容量")
    private Integer roomLimit;

    @ApiModelProperty("房间名称")
    private String roomName;

    /**
     * 状态码详见：
     *
     * @see com.mgs.api.game.server.model.enums.room.RoomStateEnum
     */
    @ApiModelProperty("房间状态码")
    private Integer roomState;

    /**
     * 类型码详见：
     *
     * @see com.mgs.api.game.server.model.enums.room.RoomTypeEnum
     */
    @ApiModelProperty("房间类型码")
    private Integer roomType;

    @ApiModelProperty("房间是否满员")
    private Boolean full;

    @ApiModelProperty("房间标签, 自定义")
    private String roomTags;

    @ApiModelProperty("房间标签List")
    private List<String> roomTagList;

    @ApiModelProperty("房主openId")
    private String roomOwner;

    @ApiModelProperty("true表示该房间类型为TEAM，默认false")
    private Boolean hasParent;

    /**
     * roomTags填充roomTagList
     *
     * @return this
     */
    public RoomDTO initRoomTagList() {
        return this.setRoomTagList(getListByRoomTag());
    }

    /**
     * 封装成CreateMgsRoomQO返回
     *
     * @return CreateMgsRoomQO
     */
    public CreateMgsRoomQuery toCreateMgsRoomQuery() {
        return new CreateMgsRoomQuery()
                .setRoomIdFromCp(this.getRoomId().toString())
                .setRoomLimit(this.getRoomLimit())
                .setRoomState(this.getRoomState())
                .setRoomName(this.getRoomName());
    }
}
