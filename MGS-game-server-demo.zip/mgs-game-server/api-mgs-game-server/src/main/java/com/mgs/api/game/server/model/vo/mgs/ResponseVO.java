package com.mgs.api.game.server.model.vo.mgs;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@ToString
@Data
@ApiModel("MGS接口请求Response VO")
public class ResponseVO<T> implements Serializable {

    private static final long serialVersionUID = 5824221743857469504L;

    @ApiModelProperty("请求状态码")
    private Integer code;

    @ApiModelProperty("返回数据")
    private T data;

    @ApiModelProperty("消息描述")
    private String message;
}
