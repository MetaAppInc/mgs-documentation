package com.mgs.api.game.server.model.qo.mgs.team;

import com.mgs.api.game.server.model.qo.mgs.room.CreateMgsRoomQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.Accessors;

/**
 * @author guozheng.zhao
 * @date 2021/3/16
 */
@EqualsAndHashCode(callSuper = true)
@ToString
@Data
@Accessors(chain = true)
@ApiModel("创建队伍请求入参QO")
public class CreateMgsTeamQuery extends CreateMgsRoomQuery {

    private static final long serialVersionUID = -5882504844870113230L;

    @ApiModelProperty("父房间ID")
    private String parentIdFromCp;

    @ApiModelProperty("聊天室能力范围: 0无,1Room,2Team")
    private Integer roomChatScope;

    @ApiModelProperty("开麦能力范围: 0无,1Room,2Team")
    private Integer voiceScope;
}
