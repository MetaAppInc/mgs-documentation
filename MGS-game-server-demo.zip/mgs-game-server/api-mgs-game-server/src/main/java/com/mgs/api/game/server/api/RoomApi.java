package com.mgs.api.game.server.api;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.qo.room.CreateRoomQuery;
import com.mgs.api.game.server.model.qo.room.JoinRoomQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import com.mgs.api.game.server.model.vo.Response;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomInfoVO;
import com.mgs.api.game.server.model.vo.mgs.room.QueryRoomUserVO;
import com.mgs.api.game.server.model.vo.room.RoomVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/7
 */
@RequestMapping("/game/server/room")
@Api(tags = "游戏服务端API接口 -- 房间相关")
public interface RoomApi {

    /**
     * 创建房间
     *
     * @param createRoomQuery 房间参数
     * @return 房间信息、队伍信息、当前用户所在队伍
     */
    @ApiOperation("创建房间")
    @PostMapping("/create")
    Response<RoomVO> createRoom(@RequestBody @Valid CreateRoomQuery createRoomQuery);

    /**
     * 加入房间
     * <p>
     * 房间id为空表示为快速加入，不为空表示正常加入
     *
     * @param joinRoomQuery 要加入的房间id、房间类型
     * @return 房间信息、队伍信息、当前用户所在队伍
     */
    @ApiOperation("加入房间")
    @PostMapping("/join")
    Response<RoomVO> joinRoom(@RequestBody JoinRoomQuery joinRoomQuery);

    /**
     * 离开房间
     * <p>
     * 如果房间包含team模式，则会离开team
     * 如果是最后一个用户离开，则会销毁房间
     *
     * @param leaveRoomQuery 要离开的房间id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    @ApiOperation("离开房间")
    @PostMapping("/leave")
    Response<Boolean> leaveRoom(@RequestBody RoomIdQuery leaveRoomQuery);

    /**
     * 同上，额外多了一个广播给房间内长连接的操作
     *
     * @param leaveRoomQuery 要离开的房间id
     * @return 离开成功 return {@code true}, 离开失败 return {@code false}
     */
    @ApiOperation("离开房间，并广播给房间内其他用户")
    @PostMapping("/leaveRoomAndFanout")
    Response<Boolean> leaveRoomAndFanout(@RequestBody RoomIdQuery leaveRoomQuery);

    /**
     * 同步房间状态
     * <p>
     * 如果是开始游戏，需要房间内用户必须全部准备
     * 如果包含team模式，则会同步team的状态
     *
     * @param syncRoomStateQuery 房间id、状态
     * @return 同步成功 return {@code true}, 同步失败 return {@code false}
     */
    @ApiOperation("同步房间信息")
    @PostMapping("/syncInfo")
    Response<Boolean> syncRoomInfo(@RequestBody @Valid SyncRoomStateQuery syncRoomStateQuery);

    /**
     * 销毁房间
     * <p>
     * 不会同步销毁team
     *
     * @param destroyRoomQuery 销毁的房间id
     * @return 销毁成功 return {@code true}, 销毁失败 return {@code false}
     */
    @ApiOperation("销毁房间")
    @PostMapping("/destroy")
    Response<Boolean> destroyRoom(@RequestBody RoomIdQuery destroyRoomQuery);

    /**
     * 获取房间内的玩家列表
     *
     * @param queryUserQuery 房间id
     * @return 玩家信息列表
     */
    @ApiOperation("获取玩家列表")
    @PostMapping("/queryUserList")
    Response<List<QueryRoomUserVO>> queryUserList(@RequestBody RoomIdQuery queryUserQuery);

    /**
     * 获取房间内的详细信息：玩家列表、房间信息
     *
     * @param queryUserQuery 查询的房间id
     * @return 玩家列表、房间信息
     */
    @ApiOperation("获取房间详细信息：玩家列表、房间信息")
    @PostMapping("/query")
    Response<QueryRoomInfoVO> queryRoom(@RequestBody RoomIdQuery queryUserQuery);

    /**
     * 创建房间，不对请求头的gameToken鉴权
     *
     * @param createRoomQuery 房间参数
     * @return 房间信息
     */
    @ApiOperation("创建房间 - 不鉴权，属于服务端主动创建房间")
    @PostMapping("/createMgsRoom")
    Response<RoomVO> createMgsRoom(@RequestBody @Valid CreateRoomQuery createRoomQuery);

    /**
     * 查询房间信息，只查询房间的参数信息
     *
     * @param queryRoomQuery 查询的房间id
     * @return 房间参数信息
     */
    @ApiOperation("查询房间信息")
    @PostMapping("/queryRoomInfo")
    Response<RoomDTO> queryRoomInfo(@RequestBody RoomIdQuery queryRoomQuery);

    /**
     * 查询好友关系
     *
     * @param roomId 房间id
     * @return 200
     */
    @ApiOperation("查询好友关系")
    @PostMapping("/batchCheckFriend")
    Response batchCheckFriend(@RequestBody Integer roomId);
}
