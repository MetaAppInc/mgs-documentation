package com.mgs.api.game.server.model.vo.mgs.room;

import com.mgs.api.game.server.model.enums.mgs.room.IRoomBaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/3
 */
@ToString
@Data
@ApiModel("创建房间返回数据VO")
public class CreateRoomVO implements IRoomBaseVO {

    private static final long serialVersionUID = 2024204653466476739L;

    @ApiModelProperty("房间成员列表")
    private List<String> memberList;

    @ApiModelProperty("来自cp的房间ID")
    private String roomIdFromCp;

    @ApiModelProperty("房间成员容量")
    private Integer roomLimit;

    @ApiModelProperty("房间名称")
    private String roomName;

    @ApiModelProperty("房间状态:0准备中,1游戏中,2游戏结束")
    private Integer roomState;

    @ApiModelProperty("是否使用聊天室")
    private Boolean canRoomChat;

    @ApiModelProperty("是否使用开麦")
    private Boolean canVoice;

    @ApiModelProperty("房间显示号")
    private String roomShowNum;

    @ApiModelProperty("房间标签")
    private List<String> roomTags;

}
