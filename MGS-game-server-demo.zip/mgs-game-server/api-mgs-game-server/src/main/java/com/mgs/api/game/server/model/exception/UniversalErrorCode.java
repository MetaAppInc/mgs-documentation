package com.mgs.api.game.server.model.exception;

import com.mgs.api.game.server.model.enums.ErrorCodeDictBase;
import lombok.AllArgsConstructor;

/**
 * 通用异常返回码
 * <p>
 * 实现ErrorCodeDictBase接口: UniversalException(ErrorCodeDictBase dict)
 *
 * @author guozheng.zhao
 * @date 2021/2/4 19:44
 */
@AllArgsConstructor
public enum UniversalErrorCode implements ErrorCodeDictBase {
    // Response返回code、msg
    OK(200, "成功"),
    BAD_REQUEST(400, "传入参数错误"),
    UNAUTHORIZED(401, "身份验证错误"),
    SERVER_ERROR(500, "服务器异常，请稍后再试"),
    HTTP_ERROR(500, "网络异常，请稍后再试"),
    CLASS_ERROR(1001, "类型错误"),
    APP_KEY_ERROR(1002, "appKey验证失败"),
    // 房间操作失败提示
    ROOM_CONFIG_ERROR(2001, "房间类型配置错误"),
    ROOM_NOT_FOUND(2002, "房间不存在"),
    FREE_ROOM_NOT_FOUND(2003, "无空闲房间"),
    ROOM_GAMING(2004, "房间状态为不可加入"),
    ROOM_UPDATE_ERROR(2005, "房间信息修改失败"),
    ROOM_FULL(2006, "房间已满员"),
    UPDATE_ROOM_ERROR_NOT_IN(2007, "未在该房间中，操作失败"),
    CREATE_ROOM_ERROR(2008, "创建房间失败"),
    JOIN_ROOM_ERROR(2009, "加入房间失败"),
    ROOM_SYNC_UNAUTHORIZED(2010, "无权限修改房间状态"),
    ROOM_SYNC_STATE_ERROR(2011, "还有用户未准备"),
    ROOM_SYNC_MEMBER_ERROR(2012, "同步房间成员失败"),
    ROOM_DESTROYED(2013, "房间已被销毁"),
    ROOM_LEAVED(2014, "已自动退出房间"),

    // mgs操作失败提示
    MGS_ROOM_UPDATE_ERROR(3005, "修改房间信息失败"),
    // team操作失败提示
    TEAM_CREATE_ERROR(4001, "创建队伍失败"),
    TEAM_CONT_CREATE(4002, "不支持创建队伍"),
    TEAM_DESTROY_ERROR(4003, "销毁队伍失败"),
    TEAM_LEAVE_ERROR(4004, "离开队伍失败"),
    TEAM_QUERY_ERROR(4005, "队伍不存在"),
    TEAM_FULL_ERROR(4006, "队伍已满，加入失败"),
    TEAM_SYNC_MEMBER_ERROR(4007, "同步队伍成员失败"),
    TEAM_GROUP_UNREASONABLE(4008, "每个队伍至少有一名玩家后才能开始游戏"),
    TEAM_SWITCH_ERROR(4009, "切换队伍失败，无可切换队伍"),
    ;

    /**
     * 返回码
     */
    private int code;

    /**
     * 返回消息
     */
    private String msg;

    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getMsg() {
        return msg;
    }

    @Override
    public String getMsg(Object... args) {
        return String.format(this.msg, args);
    }
}
