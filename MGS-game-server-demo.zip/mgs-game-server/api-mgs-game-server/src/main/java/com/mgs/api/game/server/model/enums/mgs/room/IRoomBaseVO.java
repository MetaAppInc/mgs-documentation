package com.mgs.api.game.server.model.enums.mgs.room;

import java.io.Serializable;
import java.util.List;

/**
 * 房间相关接口VO Base
 *
 * @author guozheng.zhao
 * @date 2021/2/4
 */
public interface IRoomBaseVO extends Serializable {

    /**
     * 获取 房间成员列表
     *
     * @return 房间成员列表
     */
    List<String> getMemberList();

    /**
     * 设置 房间成员列表
     *
     * @param memberList 房间成员列表
     */
    void setMemberList(List<String> memberList);

    /**
     * 获取 来自cp的房间ID
     *
     * @return 来自cp的房间ID
     */
    String getRoomIdFromCp();

    /**
     * 设置 来自cp的房间ID
     *
     * @param roomIdFromCp 来自cp的房间ID
     */
    void setRoomIdFromCp(String roomIdFromCp);

    /**
     * 获取 房间成员容量
     *
     * @return 房间成员容量
     */
    Integer getRoomLimit();

    /**
     * 设置 房间成员容量
     *
     * @param roomLimit 房间成员容量
     */
    void setRoomLimit(Integer roomLimit);

    /**
     * 获取 房间名称
     *
     * @return 房间名称
     */
    String getRoomName();

    /**
     * 设置 房间名称
     *
     * @param roomName 房间名称
     */
    void setRoomName(String roomName);

    /**
     * 获取 房间状态
     *
     * @return 房间状态
     * @see com.mgs.api.game.server.model.enums.room.RoomStateEnum
     */
    Integer getRoomState();

    /**
     * 设置 房间状态
     *
     * @param roomState 房间状态
     * @see com.mgs.api.game.server.model.enums.room.RoomStateEnum
     */
    void setRoomState(Integer roomState);
}
