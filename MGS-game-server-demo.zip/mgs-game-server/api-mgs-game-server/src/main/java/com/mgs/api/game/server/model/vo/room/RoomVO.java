package com.mgs.api.game.server.model.vo.room;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.vo.team.TeamInfoVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/17
 */
@ToString
@Data
@ApiModel("房间展示VO")
@Accessors(chain = true)
public class RoomVO implements Serializable {

    private static final long serialVersionUID = -667598461346563355L;

    @ApiModelProperty("房间信息")
    private RoomDTO roomInfo;

    @ApiModelProperty("房间下的队伍列表")
    private List<TeamInfoVO> teamInfo;

    @ApiModelProperty("当前用户所在teamId")
    private Integer currentTeamId;

    @ApiModelProperty("房间显示号")
    private String roomShowNumber;

}
