package com.mgs.api.game.server.model.qo.mgs.room;

import com.mgs.api.game.server.model.dto.room.RoomDTO;
import com.mgs.api.game.server.model.qo.room.SyncRoomStateQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/22
 */
@ToString
@Data
@Accessors(chain = true)
@ApiModel("同步房间信息QO")
public class SyncInfoQuery implements Serializable {

    private static final long serialVersionUID = 8735193111176748248L;

    @ApiModelProperty("来自cp的房间ID")
    private String roomIdFromCp;

    @ApiModelProperty("房间成员容量")
    private Integer roomLimit;

    @ApiModelProperty("房间状态:0准备中,1游戏中,2游戏结束")
    private Integer roomState;

    /**
     * 初始化
     *
     * @param syncRoomStateQuery 房间id、房间状态
     * @return this
     */
    public SyncInfoQuery init(@NotNull SyncRoomStateQuery syncRoomStateQuery) {
        return this.setRoomIdFromCp(syncRoomStateQuery.getRoomId().toString())
                .setRoomState(syncRoomStateQuery.getState());
    }

    /**
     * 初始化
     *
     * @param roomDTO 房间信息
     * @return this
     */
    public SyncInfoQuery init(@NotNull RoomDTO roomDTO) {
        return this
                .setRoomLimit(roomDTO.getRoomLimit())
                .setRoomState(roomDTO.getRoomState())
                .setRoomIdFromCp(roomDTO.getRoomId().toString());
    }
}
