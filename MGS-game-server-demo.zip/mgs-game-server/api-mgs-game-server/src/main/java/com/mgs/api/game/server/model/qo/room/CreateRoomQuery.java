package com.mgs.api.game.server.model.qo.room;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/8
 */
@ToString
@Data
@ApiModel("创建房间请求参数")
@Accessors(chain = true)
public class CreateRoomQuery implements Serializable {

    private static final long serialVersionUID = -3958350315213684479L;

    /**
     * 房间类型码：
     *
     * @see com.mgs.api.game.server.model.enums.room.RoomTypeEnum
     */
    @NotNull(message = "房间类型不能为空")
    @ApiModelProperty("房间类型码")
    private Integer roomType;

}
