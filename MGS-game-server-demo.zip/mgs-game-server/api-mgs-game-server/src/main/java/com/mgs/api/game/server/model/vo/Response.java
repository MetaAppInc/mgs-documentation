package com.mgs.api.game.server.model.vo;

import com.google.common.base.Strings;
import com.mgs.api.game.server.model.exception.UniversalErrorCode;
import com.mgs.api.game.server.model.exception.UniversalException;
import com.mgs.api.game.server.util.TimeUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.io.Serializable;
import java.util.function.Consumer;

/**
 * @author guozheng.zhao
 * @date 2021/2/4
 */
@ToString
@ApiModel("统一返回的Response实体")
@Slf4j
public class Response<T> implements Serializable {

    private static final long serialVersionUID = 4158610353649778024L;

    @ApiModelProperty("code")
    @Getter
    private Integer code;

    @Getter
    @ApiModelProperty("消息描述")
    private String message;

    @Getter
    @ApiModelProperty("返回对象")
    private T data;

    private Response<T> setCode(Integer code) {
        this.code = code;
        return this;
    }

    private Response<T> setMessage(String message) {
        this.message = message;
        return this;
    }

    public Response<T> setData(T data) {
        this.data = data;
        return this;
    }

    private Response() {
    }

    private Response(Integer code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    /**
     * 获取Response的builder
     *
     * @param <T> Response<T>
     * @return Response.Builder<T>
     */
    public static <T> Response.Builder<T> builder() {
        return new Response.Builder<>();
    }

    /**
     * 根据UniversalException返回Response
     *
     * @param exception 提供code、message初始化
     * @return Response
     */
    public static Response<?> transformByException(UniversalException exception) {
        return builder().code(exception.getCode()).message(exception.getMessage()).build();
    }

    /**
     * 根据UniversalErrorCode返回Response
     *
     * @param errorCode 提供code、message初始化
     * @return Response
     */
    public static Response<?> transformByErrorCode(UniversalErrorCode errorCode) {
        return builder().code(errorCode.getCode()).message(errorCode.getMsg()).build();
    }

    /**
     * 根据HttpStatus返回Response
     *
     * @param httpStatus 提供code
     * @param message    返回的message
     * @return Response
     */
    public static Response<?> transformByHttpStatus(HttpStatus httpStatus, String message) {
        return builder().code(httpStatus.value()).message(message).build();
    }

    /**
     * 根据HttpStatus返回Response
     *
     * @param httpStatus 提供code、message初始化
     * @return Response
     */
    public static Response<?> transformByHttpStatus(HttpStatus httpStatus) {
        return builder().code(httpStatus.value()).message(httpStatus.getReasonPhrase()).build();
    }

    /**
     * 执行方法，自动封装返回Response
     *
     * @param consumer 要执行的方法
     * @param <T>      Response.data的类型
     * @return Response
     */
    public static <T> Response<T> execute(Consumer<Response<T>> consumer) {
        long start = TimeUtil.currentTimeMillis();
        Response<T> response = new Builder<T>().code(UniversalErrorCode.OK.getCode()).build();

        try {
            consumer.accept(response);
            long delta = TimeUtil.currentTimeMillis() - start;

            if (Strings.isNullOrEmpty(response.getMessage())) {
                response.setMessage("succeeded with " + delta + " ms");
            }
            return response;
        } catch (UniversalException universalException) {
            log.warn("UniversalException throws , message [{}].", universalException.getMessage());
            return response.setCode(universalException.getCode()).setMessage(universalException.getMessage());
        } catch (IllegalArgumentException illegalArgumentException) {
            log.warn("Illegal Argument has found, message [{}].", illegalArgumentException.getMessage(), illegalArgumentException);
            return response.setCode(UniversalErrorCode.BAD_REQUEST.getCode()).setMessage(Strings.isNullOrEmpty(illegalArgumentException.getMessage()) ? "please check input param" : illegalArgumentException.getMessage());
        } catch (Exception exception) {
            log.error("Unexpected exception [{}] throw.", exception.getMessage(), exception);
            long delta = TimeUtil.currentTimeMillis() - start;
            return response.setCode(UniversalErrorCode.SERVER_ERROR.getCode()).setMessage("failed with " + delta + " ms.");
        }
    }

    /**
     * Response的Builder
     */
    public static class Builder<T> {
        private Integer code;

        private String message;

        private T data;

        private Builder() {
        }

        public Response.Builder<T> code(Integer code) {
            this.code = code;
            return this;
        }

        public Response.Builder<T> message(String message) {
            this.message = message;
            return this;
        }

        public Response.Builder<T> data(T data) {
            this.data = data;
            return this;
        }

        public Response<T> build() {
            return new Response<>(this.code, this.message, this.data);
        }

        @Override
        public String toString() {
            return "Response.ResponseEntityBuilder(code=" + this.code + ", message=" + this.message + ", data=" + this.data + ")";
        }
    }

}
