package com.mgs.api.game.server.model.vo.team;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/3/18
 */
@ToString
@Data
@Accessors(chain = true)
@ApiModel("队伍-用户 VO")
@NoArgsConstructor
@AllArgsConstructor
public class TeamUserVO implements Serializable {

    private static final long serialVersionUID = -1021597621955563368L;

    @ApiModelProperty("队伍id")
    private Integer teamId;

    @ApiModelProperty("用户开放id")
    private String openId;
}
