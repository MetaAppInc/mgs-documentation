package com.mgs.api.game.server.model.qo.mgs.team;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/3/23
 */
@Data
@ToString
@ApiModel("同步Room/Team成员请求入参")
@NoArgsConstructor
@AllArgsConstructor
public class SyncMemberQuery {

    @ApiModelProperty("成员列表")
    private List<String> openIdList;

    @ApiModelProperty("teamId")
    private String roomIdFromCp;
}
