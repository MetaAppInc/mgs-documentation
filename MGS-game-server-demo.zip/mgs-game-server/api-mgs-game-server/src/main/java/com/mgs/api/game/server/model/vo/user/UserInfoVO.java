package com.mgs.api.game.server.model.vo.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/2/23
 */
@ToString
@Data
@ApiModel("用户信息VO")
@Accessors(chain = true)
public class UserInfoVO implements Serializable {

    private static final long serialVersionUID = 7864486987227365435L;

    @ApiModelProperty("用户ID")
    private String openId;

    @ApiModelProperty("用户头像")
    private String avatar;

    @ApiModelProperty("用户昵称")
    private String nickname;

}