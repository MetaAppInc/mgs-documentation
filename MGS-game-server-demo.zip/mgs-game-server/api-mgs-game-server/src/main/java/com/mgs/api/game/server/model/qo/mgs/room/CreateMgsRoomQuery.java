package com.mgs.api.game.server.model.qo.mgs.room;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * @author guozheng.zhao
 * @date 2021/2/22
 */
@ToString
@Data
@Accessors(chain = true)
@ApiModel("创建房间信息QO")
public class CreateMgsRoomQuery implements Serializable {

    private static final long serialVersionUID = 8064604755384880482L;

    @ApiModelProperty("来自cp的房间ID")
    private String roomIdFromCp;

    @ApiModelProperty("房间成员容量")
    private Integer roomLimit;

    @ApiModelProperty("房间状态(可选,默认值为0):0准备中,1游戏中,2游戏结束")
    private Integer roomState;

    @ApiModelProperty("房间名称")
    private String roomName;

    @ApiModelProperty("房间标签")
    private List<String> roomTags;

}
