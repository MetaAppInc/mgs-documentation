package com.mgs.api.game.server.model.qo.mgs.room;

import com.mgs.api.game.server.model.enums.mgs.room.IRoomBaseQuery;
import com.mgs.api.game.server.model.qo.room.RoomIdQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.jetbrains.annotations.NotNull;

/**
 * @author guozheng.zhao
 * @date 2021/2/22
 */
@ToString
@Data
@Accessors(chain = true)
@ApiModel("销毁房间请求参数QO")
public class DestroyRoomQuery implements IRoomBaseQuery {

    private static final long serialVersionUID = 8211358725816419081L;

    @ApiModelProperty("房间id")
    private String roomIdFromCp;

    /**
     * 初始化
     *
     * @param roomIdQuery 房间ID
     * @return this
     */
    public DestroyRoomQuery init(@NotNull RoomIdQuery roomIdQuery) {
        return this.setRoomIdFromCp(roomIdQuery.getRoomId().toString());
    }
}
