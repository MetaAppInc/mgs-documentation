package com.mgs.api.game.server.model.qo.team;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author guozheng.zhao
 * @date 2021/3/14
 */
@ToString
@Data
@ApiModel("加入队伍请求参数")
@AllArgsConstructor
@NoArgsConstructor
public class JoinTeamQuery implements Serializable {

    private static final long serialVersionUID = 117269330917875707L;

    @ApiModelProperty("队伍id")
    @NotNull(message = "队伍id不能为空")
    private Integer teamId;

}
