===
## 维护管理
### 版本管理：
`mvn versions:set -DprocessAllModules=true -DnewVersion=1.0.0-SNAPSHOT`